<?php
declare(strict_types=1);

require_once __DIR__ . '/../auth.php';
require_once __DIR__ . '/../layout.php';

if (!isMunicipalityAdmin()) {
    http_response_code(403);
    exit('Access denied.');
}

municipalityHeader('Create Announcement', 'announcements');
?>

<div class="page-header">
    <div>
        <h2>Create Announcement</h2>
        <p>Publish municipal notices, job vacancies, events and opportunities.</p>
    </div>
</div>

<div class="card">
    <form action="store.php" method="POST" enctype="multipart/form-data">
        
    <?php
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }

        if (empty($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        ?>

<input type="hidden" name="csrf_token"
       value="<?= htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8') ?>">

        <div class="form-grid">
            <div>
                <label for="title">Announcement title</label>
                <input type="text" id="title" name="title"
                       maxlength="255" required>
            </div>

            <div>
                <label for="category">Category</label>
                <select id="category" name="category" required>
                    <option value="General announcement">General announcement</option>
                    <option value="Job opportunity">Job opportunity</option>
                    <option value="Public notice">Public notice</option>
                    <option value="Meeting">Meeting</option>
                    <option value="Event">Event</option>
                    <option value="Community programme">Community programme</option>
                    <option value="Other">Other</option>
                </select>
            </div>
        </div>

        <p>
            <label for="content">Full announcement</label>
            <textarea id="content" name="content" rows="10"
                      maxlength="60000" required></textarea>
        </p>

        <div class="form-grid">
            <div>
                <label for="publish_at">Publish date</label>
                <input type="datetime-local" id="publish_at"
                       name="publish_at">
                <small>Leave blank to use the current time.</small>
            </div>

            <div>
                <label for="expires_at">Expiry date</label>
                <input type="datetime-local" id="expires_at"
                       name="expires_at">
                <small>Leave blank if the announcement does not expire.</small>
            </div>
        </div>

        <p>
            <label for="attachments">Images and documents</label>
            <input type="file" id="attachments" name="attachments[]"
                   multiple
                   accept=".jpg,.jpeg,.png,.webp,.gif,.pdf,.doc,.docx,.xls,.xlsx,.txt">
            <small>
                Maximum 10 files, 5 MB per file. Allowed types:
                JPG, PNG, WEBP, GIF, PDF, DOC, DOCX, XLS, XLSX and TXT.
            </small>
        </p>

        <div class="form-grid">
            <div>
                <label for="status">Publication status</label>
                <select id="status" name="status" required>
                    <option value="draft">Save as draft</option>
                    <option value="published">Publish</option>
                    <option value="archived">Archive</option>
                </select>
            </div>
        </div>

        <p>
            <button type="submit" class="button">Save Announcement</button>
            <a href="index.php" class="button secondary">Cancel</a>
        </p>
    </form>
</div>

<?php municipalityFooter(); ?>