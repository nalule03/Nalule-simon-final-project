<?php

declare(strict_types=1);

function municipalityHeader(
    string $title,
    string $active = ''
): void {

    global $currentMunicipality;
    global $currentUser;

    $baseUrl = '/TownLink/municipality/';

?>
<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        <?= e($title) ?> | TownLink
    </title>

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >

</head>

<body class="bg-light">

<nav class="navbar navbar-expand-lg navbar-dark bg-primary">

    <div class="container-fluid">

        <a
            class="navbar-brand fw-bold"
            href="<?= $baseUrl ?>dashboard.php"
        >
            TownLink
        </a>

        <button
            class="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#municipalityNavbar"
            aria-controls="municipalityNavbar"
            aria-expanded="false"
            aria-label="Toggle navigation"
        >
            <span class="navbar-toggler-icon"></span>
        </button>

        <div
            class="collapse navbar-collapse"
            id="municipalityNavbar"
        >

            <ul class="navbar-nav me-auto mb-2 mb-lg-0">

                <li class="nav-item">

                    <a
                        class="nav-link <?= $active === 'dashboard' ? 'active' : '' ?>"
                        href="<?= $baseUrl ?>dashboard.php"
                    >
                        Dashboard
                    </a>

                </li>

                <li class="nav-item">

                    <a
                        class="nav-link <?= $active === 'departments' ? 'active' : '' ?>"
                        href="<?= $baseUrl ?>departments/index.php"
                    >
                        Departments
                    </a>

                </li>

                <li class="nav-item">

                    <a
                        class="nav-link <?= $active === 'categories' ? 'active' : '' ?>"
                        href="<?= $baseUrl ?>categories/index.php"
                    >
                        Categories
                    </a>

                </li>

                <li class="nav-item">

                    <a
                        class="nav-link <?= $active === 'services' ? 'active' : '' ?>"
                        href="<?= $baseUrl ?>services/index.php"
                    >
                        Services
                    </a>

                </li>

                <li class="nav-item">

                    <a
                        class="nav-link <?= $active === 'requests' ? 'active' : '' ?>"
                        href="<?= $baseUrl ?>requests/index.php"
                    >
                        Requests
                    </a>

                </li>

                <li class="nav-item">

                    <a
                        class="nav-link <?= $active === 'profile' ? 'active' : '' ?>"
                        href="<?= $baseUrl ?>profile/index.php"
                    >
                        Profile
                    </a>

                </li>

            </ul>

            <div class="d-flex align-items-center gap-3">

                <span class="text-white">

                    <?= e(
                        $currentUser['first_name']
                        . ' '
                        . $currentUser['last_name']
                    ) ?>

                </span>

                <a
                    class="btn btn-outline-light btn-sm"
                    href="/TownLink/public/logout.php"
                >
                    Logout
                </a>

            </div>

        </div>

    </div>

</nav>

<header class="bg-white border-bottom">

    <div class="container-fluid py-3">

        <h1 class="h4 mb-1">

            <?= e(
                $currentMunicipality['name']
            ) ?>

        </h1>

        <p class="text-muted mb-0">

            Municipality Administration

        </p>

    </div>

</header>

<main class="container-fluid py-4">

<?php
}

function municipalityFooter(): void
{
?>

</main>

<footer class="border-top bg-white py-3 mt-4">

    <div class="container-fluid">

        <p class="text-muted small mb-0 text-center">

            &copy;
            <?= date('Y') ?>
            TownLink

        </p>

    </div>

</footer>

<script
    src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
></script>

</body>

</html>

<?php
}