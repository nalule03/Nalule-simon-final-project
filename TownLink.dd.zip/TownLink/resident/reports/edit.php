<?php

declare(strict_types=1);

require_once __DIR__ . '/../_auth.php';
require_once __DIR__ . '/../_layout.php';

if (!isMunicipalityAdmin()) {
    http_response_code(403);
    exit('Access denied.');
}

$id = filter_input(
    INPUT_GET,
    'id',
    FILTER_VALIDATE_INT
);

if (!$id) {
    http_response_code(400);
    exit('Invalid report ID.');
}

$sql = "
    SELECT
        id,
        title,
        description,
        status,
        priority,
        resolved_at

    FROM reports

    WHERE
        id = :id
        AND municipality_id = :municipality_id

    LIMIT 1
";

$stmt = $pdo->prepare($sql);

$stmt->execute([
    ':id' => $id,
    ':municipality_id' => $municipalityId
]);

$report = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$report) {
    http_response_code(404);
    exit('Report not found.');
}

$statuses = [
    'draft',
    'submitted',
    'in_progress',
    'resolved',
    'rejected',
    'archived'
];

$priorities = [
    'low',
    'medium',
    'high',
    'urgent'
];

municipalityHeader(
    'Edit Report',
    'reports'
);

?>

<div class="page-header">

    <div>

        <h2>Edit Report</h2>

        <p>
            Update this report.
        </p>

    </div>

</div>

<div class="card">

    <form
        method="POST"
        action="update.php"
    >

        <input
            type="hidden"
            name="id"
            value="<?= (int) $report['id'] ?>"
        >

        <div class="form-grid">

            <div>

                <label for="title">
                    Title
                </label>

                <input
                    type="text"
                    id="title"
                    name="title"
                    maxlength="255"
                    required
                    value="<?= e(
                        $report['title']
                    ) ?>"
                >

            </div>

            <div>

                <label for="priority">
                    Priority
                </label>

                <select
                    id="priority"
                    name="priority"
                    required
                >

                    <?php foreach ($priorities as $priority): ?>

                        <option
                            value="<?= e($priority) ?>"
                            <?= $report['priority'] === $priority
                                ? 'selected'
                                : '' ?>
                        >
                            <?= e(
                                ucfirst($priority)
                            ) ?>
                        </option>

                    <?php endforeach; ?>

                </select>

            </div>

        </div>

        <br>

        <label for="status">
            Status
        </label>

        <select
            id="status"
            name="status"
            required
        >

            <?php foreach ($statuses as $status): ?>

                <option
                    value="<?= e($status) ?>"
                    <?= $report['status'] === $status
                        ? 'selected'
                        : '' ?>
                >
                    <?= e(
                        ucwords(
                            str_replace(
                                '_',
                                ' ',
                                $status
                            )
                        )
                    ) ?>
                </option>

            <?php endforeach; ?>

        </select>

        <br><br>

        <label for="description">
            Description
        </label>

        <textarea
            id="description"
            name="description"
            rows="12"
            required
        ><?= e(
            $report['description']
        ) ?></textarea>

        <br><br>

        <button
            type="submit"
            class="button"
        >
            Update Report
        </button>

        <a
            class="button secondary"
            href="view.php?id=<?= (int) $report['id'] ?>"
        >
            Cancel
        </a>

    </form>

</div>

<?php

municipalityFooter();