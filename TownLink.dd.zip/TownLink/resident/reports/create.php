<?php
declare(strict_types=1);

require_once __DIR__ . '/_common.php';

report_require_login();


if (report_role() !== 'resident') {
    http_response_code(403);
    exit('Only residents can submit reports.');
}

if (empty($_SESSION['municipality_id'])) {
    exit('Your account is not assigned to a municipality.');
}

report_header('Report a Community Issue');
?>

<style>
.report-page {
    max-width: 850px;
    margin: 0 auto;
}

.report-intro {
    background: #e8f5ef;
    border: 1px solid #d4e9de;
    border-radius: 16px;
    padding: 24px;
    margin-bottom: 24px;
}

.report-intro h1 {
    color: #123b32;
    font-weight: 800;
}

.report-form-card {
    background: #fff;
    border: 1px solid #e1e9e5;
    border-radius: 16px;
    padding: 28px;
    box-shadow: 0 5px 22px rgba(20,55,43,.05);
}

.report-label {
    color: #123b32;
    font-weight: 700;
    margin-bottom: 8px;
}

.report-help {
    color: #718078;
    font-size: .9rem;
}

.report-form-card .form-control,
.report-form-card .form-select {
    min-height: 48px;
    border-radius: 10px;
    border-color: #dce6e0;
}

.report-form-card textarea.form-control {
    min-height: 150px;
}

.report-form-card .form-control:focus,
.report-form-card .form-select:focus {
    border-color: #176b52;
    box-shadow: 0 0 0 3px rgba(23,107,82,.12);
}

.photo-upload {
    display: block;
    padding: 25px 16px;
    text-align: center;
    background: #f8faf9;
    border: 2px dashed #b9d6c8;
    border-radius: 12px;
    cursor: pointer;
    transition: .2s;
}

.photo-upload:hover {
    background: #e8f5ef;
    border-color: #176b52;
}

.photo-upload i {
    font-size: 2rem;
    color: #176b52;
}

.photo-preview {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(110px, 1fr));
    gap: 12px;
    margin-top: 15px;
}

.photo-preview img {
    width: 100%;
    height: 110px;
    object-fit: cover;
    border-radius: 10px;
    border: 1px solid #e1e9e5;
}

.report-submit {
    min-height: 48px;
    padding: 12px 22px;
    background: #176b52;
    border: 1px solid #176b52;
    color: white;
    font-weight: 700;
    border-radius: 10px;
}

.report-submit:hover {
    background: #123b32;
    color: white;
}

@media(max-width:576px) {
    .report-form-card {
        padding: 20px 16px;
    }

    .report-intro {
        padding: 20px;
    }

    .report-actions .btn {
        width: 100%;
        margin: 0 0 10px !important;
    }
}
</style>

    <a href="index.php" class="text-decoration-none">
        <i class="bi bi-arrow-left"></i> Back to my reports
    </a>

<div class="report-page">

    <div class="report-intro mt-3">
        <div class="d-flex align-items-start gap-3">
            <div class="fs-2 text-success">
                <i class="bi bi-megaphone"></i>
            </div>

            <div>
                <h1 class="h3 mb-2">Report a Community Issue</h1>

                <p class="mb-2">
                    Is something broken or wrong in your community?
                    Tell your municipality about it.
                </p>

                <small class="text-secondary">
                    <i class="bi bi-info-circle me-1"></i>
                    Fill in the details you know. A photo helps, but
                    you can submit a report without one.
                </small>
            </div>
        </div>
    </div>

    <div class="report-form-card">

        <form action="store.php"
              method="POST"
              enctype="multipart/form-data">

            <input type="hidden"
                   name="csrf_token"
                   value="<?= report_escape(report_csrf_token()) ?>">

                    <div class="mb-4">
                        <label for="full_name" class="form-label report-label">
                            Your full name <span class="text-danger">*</span>
                        </label>

                        <input
                            type="text"
                            id="full_name"
                            name="full_name"
                            class="form-control"
                            maxlength="201"
                            autocomplete="name"
                            placeholder="Enter your first and last name"
                            required
                        >

                        <div class="report-help mt-1">
                            Enter the name of the person submitting this report.
                        </div>
                    </div>
                                        <!-- ERF number -->
                    <div class="mb-4">
                        <label for="erf_number" class="form-label report-label">
                            ERF / Plot number <span class="text-danger">*</span>
                        </label>

                        <input
                            type="text"
                            id="erf_number"
                            name="erf_number"
                            class="form-control"
                            maxlength="50"
                            placeholder="e.g. Erf 1234"
                            required
                        >

                        <div class="report-help mt-1">
                            Enter the erf or plot number for the affected property,
                            if applicable. If the problem is on a public road,
                            enter the nearest relevant erf or plot number.
                        </div>
                    </div>

                    <div class="mb-4">
                        <label for="category" class="form-label report-label">
                            What kind of problem is it?
                            <span class="text-danger">*</span>
                        </label>

                        <select id="category" name="category" class="form-select" required>
                            <option value="">Choose the problem you are reporting</option>

                            <option value="Roads">Road damage and potholes</option>
                            <option value="Water">Water leaks and water shortages</option>
                            <option value="Sewerage">Blocked drains and sewerage leaks</option>
                            <option value="Waste">Uncollected rubbish and illegal dumping</option>
                            <option value="Streetlights">Broken streetlights</option>
                            <option value="Stormwater">Blocked stormwater drains and flooding</option>
                            <option value="Public Safety">Unsafe public spaces and hazards</option>
                            <option value="Public Facilities">Damaged public buildings and facilities</option>
                            <option value="Parks">Damaged parks and playgrounds</option>
                            <option value="Animals">Stray animals and animal-related concerns</option>
                            <option value="Electricity">Street-level electrical infrastructure hazards</option>
                            <option value="Other">Other municipal problem</option>
                        </select>
                    </div>

            <div class="mb-4">
                <!-- Resident full name -->
                    <!-- Street name -->
                    <div class="mb-4">
                        <label for="street_name" class="form-label report-label">
                            Street name <span class="text-danger">*</span>
                        </label>

                        <input
                            type="text"
                            id="street_name"
                            name="street_name"
                            class="form-control"
                            maxlength="150"
                            autocomplete="street-address"
                            placeholder="e.g. Independence Avenue"
                            required
                        >
                    </div>

                <input type="text"
                       id="location"
                       name="location"
                       class="form-control"
                       maxlength="255"
                       placeholder="e.g. Katutura, near the clinic">

                <div class="report-help mt-1">
                    Add a street name, neighbourhood or nearby landmark.
                </div>
            </div>

            <div class="mb-4">
                <label for="description" class="form-label report-label">
                    Tell us more
                    <span class="text-danger">*</span>
                </label>

                <textarea
                            id="description"
                            name="description"
                            class="form-control"
                            rows="6"
                            minlength="20"
                            maxlength="10000"
                            placeholder="Please explain:
                        1. What is the problem?
                        2. Where exactly is it?
                        3. When did you notice it?
                        4. How does it affect residents?
                        5. Is there any immediate danger?"
                            required></textarea>

                <div class="d-flex justify-content-between gap-2 mt-1">
                    <small class="report-help">
                        Please provide at least 20 characters and enough detail
                        for the municipality to investigate.
                    </small>

                    <small class="report-help text-nowrap">
                        <span id="characterCount">0</span>/10000
                    </small>
                </div>
                <div class="d-flex justify-content-between gap-2 mt-1">
                
</div>
            </div>

            <div class="mb-4">
                <label class="form-label report-label">
                    Add pictures
                    <span class="text-secondary fw-normal">(optional)</span>
                </label>

                <label for="photos" class="photo-upload">
                    <i class="bi bi-camera d-block mb-2"></i>

                    <strong>Take a photo or choose pictures</strong>

                    <span class="d-block report-help mt-1">
                        You can attach up to 3 pictures, 5 MB each.
                    </span>
                </label>

                <input type="file"
                       id="photos"
                       name="photos[]"
                       class="form-control d-none"
                       accept="image/jpeg,image/png,image/webp"
                       multiple>

                <div id="photoPreview" class="photo-preview"></div>

                <small id="photoMessage"
                       class="report-help d-block mt-2"
                       aria-live="polite">
                    Pictures make it easier for the municipality to
                    understand the issue. Please avoid photographing
                    people's faces unnecessarily.
                </small>
            </div>

            <div class="alert alert-light border small">
                <i class="bi bi-shield-check text-success me-1"></i>
                Your report will be sent to the municipality associated
                with your account.
            </div>

            <div class="report-actions d-flex flex-wrap gap-2 mt-4">
                <button type="submit" class="btn report-submit">
                    <i class="bi bi-send me-2"></i>
                    Submit Report
                </button>

                <a href="index.php" class="btn btn-light px-4">
                    Cancel
                </a>
            </div>

        </form>
    </div>
</div>

<script>
const description = document.getElementById('description');
const characterCount = document.getElementById('characterCount');
const photosInput = document.getElementById('photos');
const photoPreview = document.getElementById('photoPreview');
const photoMessage = document.getElementById('photoMessage');

description.addEventListener('input', function () {
    characterCount.textContent = this.value.length;
});

photosInput.addEventListener('change', function () {
    photoPreview.replaceChildren();

    const files = Array.from(this.files || []);
    const maxFiles = 3;
    const maxSize = 5 * 1024 * 1024;
    const allowedTypes = [
        'image/jpeg',
        'image/png',
        'image/webp'
    ];

    if (files.length > maxFiles) {
        this.value = '';
        photoMessage.textContent =
            'Please choose no more than 3 pictures.';
        return;
    }

    const invalidFile = files.find(file =>
        !allowedTypes.includes(file.type) ||
        file.size > maxSize ||
        file.size === 0
    );

    if (invalidFile) {
        this.value = '';
        photoMessage.textContent =
            'Each picture must be a JPG, PNG or WebP image no larger than 5 MB.';
        return;
    }

    photoMessage.textContent = files.length
        ? files.length + ' picture(s) selected. Check the previews below.'
        : 'No pictures selected. You can still submit your report.';

    files.forEach(file => {
        const image = document.createElement('img');
        const objectUrl = URL.createObjectURL(file);

        image.src = objectUrl;
        image.alt = 'Preview of ' + file.name;

        image.onload = () => URL.revokeObjectURL(objectUrl);

        photoPreview.appendChild(image);
    });
});
</script>

<?php report_footer(); ?>