<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| TownLink - System Administrator Audit Dashboard
|--------------------------------------------------------------------------
*/

require_once __DIR__ . '/includes/_auth.php';
require_once __DIR__ . '/../app/helpers/audit.php';

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

/*
|--------------------------------------------------------------------------
| Configuration
|--------------------------------------------------------------------------
*/

if (!isset($pdo) || !$pdo instanceof PDO) {
    http_response_code(500);
    exit('Database connection unavailable.');
}

if (function_exists('requireSystemAdmin')) {
    requireSystemAdmin();
}

function auditEscape(mixed $value): string
{
    return htmlspecialchars(
        (string) ($value ?? ''),
        ENT_QUOTES | ENT_SUBSTITUTE,
        'UTF-8'
    );
}

function auditNumber(mixed $value): string
{
    return number_format((int) $value);
}

$powerBiUrl = trim(
    (string) (getenv('TOWNLINK_POWERBI_REPORT_URL') ?: '')
);

$powerBiHost = strtolower(
    (string) parse_url($powerBiUrl, PHP_URL_HOST)
);

$powerBiUrlValid =
    strtolower((string) parse_url($powerBiUrl, PHP_URL_SCHEME)) === 'https'
    && in_array(
        $powerBiHost,
        ['app.powerbi.com', 'app.powerbigov.us'],
        true
    );

/*
|--------------------------------------------------------------------------
| Filters
|--------------------------------------------------------------------------
*/

$search = trim((string) ($_GET['search'] ?? ''));
$action = trim((string) ($_GET['action'] ?? ''));
$entityType = trim((string) ($_GET['entity_type'] ?? ''));
$ipAddress = trim((string) ($_GET['ip_address'] ?? ''));
$dateFrom = trim((string) ($_GET['date_from'] ?? ''));
$dateTo = trim((string) ($_GET['date_to'] ?? ''));

$allowedActions = [
    'login',
    'logout',
    'login_failed',
    'failed_login',
    'registration',
    'create',
    'update',
    'delete',
    'toggle',
    'audit_test',
];

$allowedEntityTypes = [
    'user',
    'municipality',
    'request',
    'service',
    'category',
    'department',
];

if (!in_array($action, $allowedActions, true)) {
    $action = '';
}

if (!in_array($entityType, $allowedEntityTypes, true)) {
    $entityType = '';
}

$validDate = static function (string $date): bool {
    $parsed = DateTimeImmutable::createFromFormat('!Y-m-d', $date);

    return $parsed !== false
        && $parsed->format('Y-m-d') === $date;
};

if ($dateFrom !== '' && !$validDate($dateFrom)) {
    $dateFrom = '';
}

if ($dateTo !== '' && !$validDate($dateTo)) {
    $dateTo = '';
}

if (
    $dateFrom !== ''
    && $dateTo !== ''
    && $dateFrom > $dateTo
) {
    [$dateFrom, $dateTo] = [$dateTo, $dateFrom];
}

/*
|--------------------------------------------------------------------------
| Pagination
|--------------------------------------------------------------------------
*/

$page = filter_input(INPUT_GET, 'page', FILTER_VALIDATE_INT);

$page = ($page !== false && $page !== null && $page > 0)
    ? min($page, 1000000)
    : 1;

$perPage = 20;
$offset = ($page - 1) * $perPage;

/*
|--------------------------------------------------------------------------
| Shared Query Filters
|--------------------------------------------------------------------------
*/

$where = [];
$params = [];

if ($search !== '') {
    $where[] = "(
        CAST(a.id AS CHAR) LIKE :search_id
        OR a.description LIKE :search_description
        OR a.action LIKE :search_action
        OR a.entity_type LIKE :search_entity
        OR CAST(a.entity_id AS CHAR) LIKE :search_entity_id
        OR CAST(a.user_id AS CHAR) LIKE :search_user_id
        OR u.first_name LIKE :search_first
        OR u.last_name LIKE :search_last
        OR u.email LIKE :search_email
        OR m.name LIKE :search_municipality
        OR a.ip_address LIKE :search_ip
    )";

    $term = '%' . $search . '%';

    foreach ([
        ':search_id',
        ':search_description',
        ':search_action',
        ':search_entity',
        ':search_entity_id',
        ':search_user_id',
        ':search_first',
        ':search_last',
        ':search_email',
        ':search_municipality',
        ':search_ip',
    ] as $key) {
        $params[$key] = $term;
    }
}

if ($action !== '') {
    $where[] = 'a.action = :action';
    $params[':action'] = $action;
}

if ($entityType !== '') {
    $where[] = 'a.entity_type = :entity_type';
    $params[':entity_type'] = $entityType;
}

if ($ipAddress !== '') {
    $where[] = 'a.ip_address LIKE :ip_address';
    $params[':ip_address'] = '%' . $ipAddress . '%';
}

if ($dateFrom !== '') {
    $where[] = 'a.created_at >= :date_from';
    $params[':date_from'] = $dateFrom . ' 00:00:00';
}

if ($dateTo !== '') {
    $endExclusive = (
        new DateTimeImmutable($dateTo)
    )->modify('+1 day')->format('Y-m-d');

    $where[] = 'a.created_at < :date_to';
    $params[':date_to'] = $endExclusive . ' 00:00:00';
}

$whereSql = $where
    ? 'WHERE ' . implode(' AND ', $where)
    : '';

/*
|--------------------------------------------------------------------------
| Dashboard Data
|--------------------------------------------------------------------------
*/

$summary = [
    'total' => 0,
    'today' => 0,
    'logins' => 0,
    'failed' => 0,
    'users' => 0,
];

$dailyLabels = [];
$dailyValues = [];
$actionLabels = [];
$actionValues = [];

$logs = [];
$totalLogs = 0;
$totalPages = 1;
$errorMessage = '';

try {
    /*
     * Summary: last 30 days.
     */
    $summaryStmt = $pdo->query("
        SELECT
            COUNT(*) AS total,
            COALESCE(SUM(
                CASE WHEN created_at >= CURRENT_DATE
                THEN 1 ELSE 0 END
            ), 0) AS today,
            COALESCE(SUM(
                CASE WHEN LOWER(action) = 'login'
                THEN 1 ELSE 0 END
            ), 0) AS logins,
            COALESCE(SUM(
                CASE WHEN LOWER(action) IN
                    ('login_failed', 'failed_login')
                THEN 1 ELSE 0 END
            ), 0) AS failed,
            COUNT(DISTINCT user_id) AS users
        FROM audit_logs
        WHERE created_at >= CURRENT_DATE - INTERVAL 29 DAY
    ");

    $summaryRow = $summaryStmt->fetch(PDO::FETCH_ASSOC);

    if ($summaryRow) {
        foreach ($summary as $key => $_) {
            $summary[$key] = (int) ($summaryRow[$key] ?? 0);
        }
    }

    /*
     * Daily activity: last seven days.
     */
    $activityStmt = $pdo->query("
        SELECT DATE(created_at) AS activity_date,
               COUNT(*) AS total
        FROM audit_logs
        WHERE created_at >= CURRENT_DATE - INTERVAL 6 DAY
        GROUP BY DATE(created_at)
        ORDER BY activity_date
    ");

    $activityMap = [];

    foreach ($activityStmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
        $activityMap[$row['activity_date']] = (int) $row['total'];
    }

    for ($i = 6; $i >= 0; $i--) {
        $day = (new DateTimeImmutable('today'))
            ->modify("-$i days")
            ->format('Y-m-d');

        $dailyLabels[] = $day;
        $dailyValues[] = $activityMap[$day] ?? 0;
    }

    /*
     * Action breakdown: last 30 days.
     */
    $actionStmt = $pdo->query("
        SELECT action, COUNT(*) AS total
        FROM audit_logs
        WHERE created_at >= CURRENT_DATE - INTERVAL 29 DAY
        GROUP BY action
        ORDER BY total DESC
        LIMIT 10
    ");

    foreach ($actionStmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
        $actionLabels[] = (string) $row['action'];
        $actionValues[] = (int) $row['total'];
    }

    /*
     * Filtered table count.
     */
    $countStmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM audit_logs a
        LEFT JOIN users u ON u.id = a.user_id
        LEFT JOIN municipalities m ON m.id = a.municipality_id
        $whereSql
    ");

    $countStmt->execute($params);
    $totalLogs = (int) $countStmt->fetchColumn();

    $totalPages = max(1, (int) ceil($totalLogs / $perPage));

    if ($page > $totalPages) {
        $page = $totalPages;
        $offset = ($page - 1) * $perPage;
    }

    /*
     * Audit records.
     * LIMIT and OFFSET are validated integers.
     */
    $stmt = $pdo->prepare("
        SELECT
            a.id,
            a.municipality_id,
            a.user_id,
            a.action,
            a.entity_type,
            a.entity_id,
            a.description,
            a.ip_address,
            a.user_agent,
            a.created_at,
            u.first_name,
            u.last_name,
            u.email,
            u.role,
            m.name AS municipality_name
        FROM audit_logs a
        LEFT JOIN users u ON u.id = a.user_id
        LEFT JOIN municipalities m ON m.id = a.municipality_id
        $whereSql
        ORDER BY a.created_at DESC, a.id DESC
        LIMIT $perPage OFFSET $offset
    ");

    $stmt->execute($params);
    $logs = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (Throwable $e) {
    error_log('TownLink audit dashboard error: ' . $e->getMessage());

    $errorMessage =
        'Some dashboard data could not be loaded. Check the application error log.';
}

/*
|--------------------------------------------------------------------------
| Layout
|--------------------------------------------------------------------------
*/

require_once __DIR__ . '/includes/_layout.php';

$queryFilters = [
    'search' => $search,
    'action' => $action,
    'entity_type' => $entityType,
    'ip_address' => $ipAddress,
    'date_from' => $dateFrom,
    'date_to' => $dateTo,
];

$baseUrl = 'audit-logs.php';

function auditActionClass(string $action): string
{
    $value = strtolower($action);

    if (in_array($value, ['login_failed', 'failed_login', 'delete'], true)) {
        return 'danger';
    }

    if (in_array($value, ['create', 'registration', 'login'], true)) {
        return 'success';
    }

    if (in_array($value, ['update', 'toggle'], true)) {
        return 'warning';
    }

    if ($value === 'logout') {
        return 'info';
    }

    return 'neutral';
}
?>

<style>
.audit-page {
    --ink: #172b25;
    --muted: #64756e;
    --line: #dfe8e2;
    --green: #176b52;
    --green-dark: #10523f;
    max-width: 1600px;
    margin: 0 auto;
    padding: 24px;
    color: var(--ink);
}

.audit-page * { box-sizing: border-box; }

.audit-header, .section-heading {
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 14px;
}

.audit-header { margin-bottom: 24px; }

.audit-header h1 {
    margin: 0 0 6px;
    font-size: clamp(25px, 3vw, 32px);
}

.audit-header p, .section-heading p {
    margin: 0;
    color: var(--muted);
    font-size: 14px;
}

.section-heading { margin: 26px 0 15px; }

.section-heading h2 {
    margin: 0 0 5px;
    font-size: 20px;
}

.audit-cards {
    display: grid;
    grid-template-columns: repeat(5, minmax(0, 1fr));
    gap: 15px;
    margin-bottom: 24px;
}

.audit-card, .audit-panel {
    min-width: 0;
    background: #fff;
    border: 1px solid var(--line);
    border-radius: 13px;
    box-shadow: 0 4px 16px rgb(15 40 28 / 4%);
}

.audit-card { padding: 19px; }

.audit-card-label {
    display: block;
    color: var(--muted);
    font-size: 13px;
}

.audit-card-value {
    display: block;
    margin: 11px 0 7px;
    font-size: clamp(24px, 2.4vw, 32px);
    font-weight: 800;
    overflow-wrap: anywhere;
}

.audit-card-note {
    color: var(--muted);
    font-size: 12px;
}

.audit-card.danger { border-top: 4px solid #dc4444; }
.audit-card.success { border-top: 4px solid #23976b; }
.audit-card.primary { border-top: 4px solid var(--green); }

.audit-charts {
    display: grid;
    grid-template-columns: minmax(0, 1.5fr) minmax(0, 1fr);
    gap: 18px;
}

.audit-panel { padding: 20px; margin-bottom: 20px; }

.audit-panel h3 {
    margin: 0 0 5px;
    font-size: 17px;
}

.audit-panel > p {
    margin: 0 0 20px;
    color: var(--muted);
    font-size: 13px;
}

.chart-container {
    position: relative;
    width: 100%;
    height: 280px;
}

.powerbi-frame {
    height: 620px;
    overflow: hidden;
    border: 1px solid var(--line);
    border-radius: 9px;
    background: #f8faf9;
}

.powerbi-frame iframe {
    display: block;
    width: 100%;
    height: 100%;
    border: 0;
}

.powerbi-placeholder {
    display: grid;
    place-content: center;
    min-height: 300px;
    padding: 25px;
    text-align: center;
}

.powerbi-placeholder p {
    max-width: 580px;
    margin: 10px auto;
    color: var(--muted);
    line-height: 1.7;
}

.audit-filters {
    display: grid;
    grid-template-columns: repeat(4, minmax(0, 1fr));
    align-items: end;
    gap: 14px;
}

.audit-field { min-width: 0; }

.audit-field label {
    display: block;
    margin-bottom: 6px;
    font-size: 13px;
    font-weight: 700;
}

.audit-field input, .audit-field select {
    width: 100%;
    min-height: 42px;
    padding: 10px;
    border: 1px solid #cedbd3;
    border-radius: 7px;
    background: #fff;
    color: var(--ink);
    font: inherit;
}

.audit-field input:focus, .audit-field select:focus {
    outline: 3px solid rgb(23 107 82 / 14%);
    border-color: var(--green);
}

.audit-actions {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
    grid-column: 1 / -1;
}

.audit-button {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-height: 40px;
    padding: 9px 15px;
    border: 1px solid var(--green);
    border-radius: 7px;
    background: var(--green);
    color: #fff;
    text-decoration: none;
    cursor: pointer;
    font: inherit;
    font-size: 13px;
    font-weight: 700;
}

.audit-button:hover { background: var(--green-dark); color: #fff; }

.audit-button.secondary {
    background: #fff;
    color: var(--ink);
    border-color: var(--line);
}

.audit-button.secondary:hover { background: #f3f7f4; }

.audit-table-wrap {
    overflow: auto;
    border: 1px solid var(--line);
    border-radius: 10px;
    background: #fff;
}

.audit-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 13px;
}

.audit-table th, .audit-table td {
    padding: 13px;
    text-align: left;
    vertical-align: top;
    border-bottom: 1px solid #e9efeb;
}

.audit-table th {
    background: #f6f9f7;
    color: #41534a;
    white-space: nowrap;
}

.audit-table tbody tr:hover { background: #fbfdfb; }

.audit-table tbody tr:last-child td { border-bottom: 0; }

.audit-description {
    min-width: 230px;
    max-width: 380px;
    overflow-wrap: anywhere;
}

.audit-muted { color: var(--muted); }

.audit-tag {
    display: inline-block;
    padding: 4px 8px;
    border-radius: 5px;
    background: #edf0ee;
    color: #45554c;
    font-size: 11px;
    font-weight: 800;
    white-space: nowrap;
}

.audit-tag.success { background: #e2f5e9; color: #17653c; }
.audit-tag.danger { background: #fee8e7; color: #a32121; }
.audit-tag.warning { background: #fff1d5; color: #8a5700; }
.audit-tag.info { background: #e3efff; color: #214e91; }

.audit-error {
    padding: 15px;
    margin-bottom: 18px;
    border: 1px solid #f3bcbc;
    border-radius: 9px;
    background: #fff1f1;
    color: #8f2020;
}

.audit-empty {
    padding: 35px !important;
    text-align: center !important;
    color: var(--muted);
}

.audit-pagination {
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 14px;
    margin-top: 18px;
    font-size: 13px;
}

.audit-pagination-links {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    gap: 8px;
}

@media (max-width: 1100px) {
    .audit-cards { grid-template-columns: repeat(3, minmax(0, 1fr)); }
    .audit-filters { grid-template-columns: repeat(2, minmax(0, 1fr)); }
}

@media (max-width: 750px) {
    .audit-page { padding: 14px; }
    .audit-charts { grid-template-columns: 1fr; }
    .powerbi-frame { height: 500px; }
}

@media (max-width: 480px) {
    .audit-cards { grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 9px; }
    .audit-card { padding: 13px; }
    .audit-panel { padding: 14px; }
    .audit-filters { grid-template-columns: 1fr; }
    .audit-actions { flex-direction: column; }
    .audit-actions .audit-button { width: 100%; }
    .powerbi-frame { height: 430px; }
}
</style>

<div class="audit-page">

    <header class="audit-header">
        <div>
            <h1>System Administrator Dashboard</h1>
            <p>TownLink activity monitoring, audit records, and security analytics.</p>
        </div>
        <a class="audit-button secondary" href="<?= auditEscape($baseUrl) ?>">
            Refresh dashboard
        </a>
    </header>

    <?php if ($errorMessage !== ''): ?>
        <div class="audit-error"><?= auditEscape($errorMessage) ?></div>
    <?php endif; ?>

    <div class="section-heading">
        <div>
            <h2>Security overview</h2>
            <p>Recorded events over the last 30 days.</p>
        </div>
    </div>

    <section class="audit-cards">
        <article class="audit-card primary">
            <span class="audit-card-label">Total events</span>
            <strong class="audit-card-value"><?= auditNumber($summary['total']) ?></strong>
            <span class="audit-card-note">Last 30 days</span>
        </article>

        <article class="audit-card">
            <span class="audit-card-label">Today's activity</span>
            <strong class="audit-card-value"><?= auditNumber($summary['today']) ?></strong>
            <span class="audit-card-note">Since midnight</span>
        </article>

        <article class="audit-card success">
            <span class="audit-card-label">Recorded logins</span>
            <strong class="audit-card-value"><?= auditNumber($summary['logins']) ?></strong>
            <span class="audit-card-note">Last 30 days</span>
        </article>

        <article class="audit-card danger">
            <span class="audit-card-label">Failed logins</span>
            <strong class="audit-card-value"><?= auditNumber($summary['failed']) ?></strong>
            <span class="audit-card-note">Last 30 days</span>
        </article>

        <article class="audit-card">
            <span class="audit-card-label">Users with activity</span>
            <strong class="audit-card-value"><?= auditNumber($summary['users']) ?></strong>
            <span class="audit-card-note">Distinct recorded user IDs</span>
        </article>
    </section>

    <div class="section-heading">
        <div>
            <h2>Activity analytics</h2>
            <p>Trends and action distribution from your audit database.</p>
        </div>
    </div>

    <section class="audit-charts">
        <article class="audit-panel">
            <h3>Daily activity</h3>
            <p>Events recorded over the last seven calendar days.</p>
            <div class="chart-container">
                <canvas id="activityChart" aria-label="Daily activity chart"></canvas>
            </div>
        </article>

        <article class="audit-panel">
            <h3>Action distribution</h3>
            <p>Most frequently recorded actions in the last 30 days.</p>
            <div class="chart-container">
                <canvas id="actionChart" aria-label="Action distribution chart"></canvas>
            </div>
        </article>
    </section>

    <section class="audit-panel">
        <div class="section-heading">
            <div>
                <h2>Power BI analytics</h2>
                <p>Explore your published interactive report.</p>
            </div>
        </div>

        <div class="powerbi-frame">
            <?php if ($powerBiUrlValid): ?>
                <iframe
                    src="<?= auditEscape($powerBiUrl) ?>"
                    title="TownLink Power BI Audit Analytics"
                    loading="lazy"
                    allowfullscreen
                    referrerpolicy="strict-origin-when-cross-origin">
                </iframe>
            <?php else: ?>
                <div class="powerbi-placeholder">
                    <h3>Power BI report not configured</h3>
                    <p>
                        Set the server environment variable
                        <code>TOWNLINK_POWERBI_REPORT_URL</code>
                        to the secure embed URL for your published report.
                    </p>
                    <p>
                        Use Power BI's secure <strong>Embed report →
                        Website or portal</strong> option. Viewers must
                        have report permissions and the required license.
                    </p>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <div class="section-heading">
        <div>
            <h2>Audit records</h2>
            <p>Search and filter recorded system activity.</p>
        </div>
    </div>

    <section class="audit-panel">
        <form method="GET" class="audit-filters">
            <div class="audit-field">
                <label for="search">Search records</label>
                <input
                    type="search"
                    id="search"
                    name="search"
                    value="<?= auditEscape($search) ?>"
                    maxlength="200"
                    placeholder="User, description, IP, or ID">
            </div>

            <div class="audit-field">
                <label for="action">Action</label>
                <select id="action" name="action">
                    <option value="">All actions</option>
                    <?php foreach ($allowedActions as $item): ?>
                        <option value="<?= auditEscape($item) ?>"
                            <?= $action === $item ? 'selected' : '' ?>>
                            <?= auditEscape(ucfirst(str_replace('_', ' ', $item))) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="audit-field">
                <label for="entity_type">Entity type</label>
                <select id="entity_type" name="entity_type">
                    <option value="">All entities</option>
                    <?php foreach ($allowedEntityTypes as $item): ?>
                        <option value="<?= auditEscape($item) ?>"
                            <?= $entityType === $item ? 'selected' : '' ?>>
                            <?= auditEscape(ucfirst(str_replace('_', ' ', $item))) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="audit-field">
                <label for="ip_address">IP address</label>
                <input
                    type="text"
                    id="ip_address"
                    name="ip_address"
                    value="<?= auditEscape($ipAddress) ?>"
                    maxlength="45"
                    placeholder="Search IP address">
            </div>

            <div class="audit-field">
                <label for="date_from">From date</label>
                <input
                    type="date"
                    id="date_from"
                    name="date_from"
                    value="<?= auditEscape($dateFrom) ?>">
            </div>

            <div class="audit-field">
                <label for="date_to">To date</label>
                <input
                    type="date"
                    id="date_to"
                    name="date_to"
                    value="<?= auditEscape($dateTo) ?>">
            </div>

            <div class="audit-actions">
                <button type="submit" class="audit-button">Apply filters</button>
                <a href="<?= auditEscape($baseUrl) ?>"
                   class="audit-button secondary">Clear filters</a>
            </div>
        </form>
    </section>

    <div class="audit-table-wrap">
        <table class="audit-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Date and time</th>
                    <th>User</th>
                    <th>Municipality</th>
                    <th>Action</th>
                    <th>Entity</th>
                    <th>Description</th>
                    <th>IP address</th>
                </tr>
            </thead>
            <tbody>
            <?php if ($errorMessage !== ''): ?>
                <tr>
                    <td colspan="8" class="audit-empty">
                        Records could not be loaded.
                    </td>
                </tr>
            <?php elseif (!$logs): ?>
                <tr>
                    <td colspan="8" class="audit-empty">
                        No audit records match your filters.
                    </td>
                </tr>
            <?php else: ?>
                <?php foreach ($logs as $log): ?>
                    <?php
                    $fullName = trim(
                        (string) ($log['first_name'] ?? '') . ' ' .
                        (string) ($log['last_name'] ?? '')
                    );
                    $logAction = (string) ($log['action'] ?? '');
                    ?>
                    <tr>
                        <td><?= (int) $log['id'] ?></td>
                        <td><?= auditEscape($log['created_at']) ?></td>
                        <td>
                            <?php if ($fullName !== ''): ?>
                                <strong><?= auditEscape($fullName) ?></strong>
                            <?php else: ?>
                                <span class="audit-muted">Unknown or deleted user</span>
                            <?php endif; ?>

                            <?php if (!empty($log['email'])): ?>
                                <br><span class="audit-muted"><?= auditEscape($log['email']) ?></span>
                            <?php endif; ?>

                            <?php if (!empty($log['role'])): ?>
                                <br><span class="audit-muted"><?= auditEscape($log['role']) ?></span>
                            <?php endif; ?>

                            <?php if ($log['user_id'] !== null): ?>
                                <br><span class="audit-muted">ID: <?= (int) $log['user_id'] ?></span>
                            <?php endif; ?>
                        </td>
                        <td><?= auditEscape($log['municipality_name'] ?? 'System-wide / unavailable') ?></td>
                        <td>
                            <span class="audit-tag <?= auditEscape(auditActionClass($logAction)) ?>">
                                <?= auditEscape(ucfirst(str_replace('_', ' ', $logAction))) ?>
                            </span>
                        </td>
                        <td>
                            <?= auditEscape($log['entity_type'] ?? '—') ?>
                            <?php if ($log['entity_id'] !== null): ?>
                                <br><span class="audit-muted">ID: <?= (int) $log['entity_id'] ?></span>
                            <?php endif; ?>
                        </td>
                        <td class="audit-description">
                            <?= auditEscape($log['description'] ?? '—') ?>
                        </td>
                        <td><?= auditEscape($log['ip_address'] ?? '—') ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>

    <?php if ($errorMessage === ''): ?>
        <div class="audit-pagination">
            <div>
                Showing <?= $totalLogs === 0 ? 0 : $offset + 1 ?>
                – <?= min($offset + $perPage, $totalLogs) ?>
                of <?= auditNumber($totalLogs) ?> records
            </div>

            <div class="audit-pagination-links">
                <?php if ($page > 1): ?>
                    <a class="audit-button secondary"
                       href="?<?= auditEscape(http_build_query(
                           array_merge($queryFilters, ['page' => $page - 1])
                       )) ?>">Previous</a>
                <?php endif; ?>

                <span>Page <?= $page ?> of <?= $totalPages ?></span>

                <?php if ($page < $totalPages): ?>
                    <a class="audit-button"
                       href="?<?= auditEscape(http_build_query(
                           array_merge($queryFilters, ['page' => $page + 1])
                       )) ?>">Next</a>
                <?php endif; ?>
            </div>
        </div>
    <?php endif; ?>

</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
(function () {
    'use strict';

    const dailyLabels = <?= json_encode(
        $dailyLabels,
        JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP
    ) ?>;

    const dailyValues = <?= json_encode(
        $dailyValues,
        JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP
    ) ?>;

    const actionLabels = <?= json_encode(
        $actionLabels,
        JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP
    ) ?>;

    const actionValues = <?= json_encode(
        $actionValues,
        JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP
    ) ?>;

    if (typeof Chart === 'undefined') {
        document.querySelectorAll('.chart-container').forEach(function (container) {
            container.textContent = 'Charts are unavailable. Check your internet connection or Chart.js configuration.';
        });
        return;
    }

    const activityCanvas = document.getElementById('activityChart');

    if (activityCanvas) {
        new Chart(activityCanvas, {
            type: 'line',
            data: {
                labels: dailyLabels,
                datasets: [{
                    label: 'Audit events',
                    data: dailyValues,
                    borderColor: '#176b52',
                    backgroundColor: 'rgba(23, 107, 82, 0.12)',
                    fill: true,
                    tension: 0.3,
                    pointRadius: 3
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: { precision: 0 }
                    }
                }
            }
        });
    }

    const actionCanvas = document.getElementById('actionChart');

    if (actionCanvas) {
        new Chart(actionCanvas, {
            type: 'doughnut',
            data: {
                labels: actionLabels,
                datasets: [{
                    data: actionValues,
                    backgroundColor: [
                        '#176b52', '#3a8c70', '#77b79c',
                        '#e0ae50', '#df6a5e', '#638bd0',
                        '#8e79ba', '#9ba9a1', '#d88f47',
                        '#4d9da5'
                    ],
                    borderWidth: 2,
                    borderColor: '#ffffff'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });
    }
})();
</script>