<?php

declare(strict_types=1);

require_once __DIR__ . '/../auth.php';
require_once __DIR__ . '/../layout.php';

requireMunicipalityAdmin();

$id = filter_input(
    INPUT_GET,
    'id',
    FILTER_VALIDATE_INT
);

if (!$id) {
    http_response_code(400);
    exit('Invalid department.');
}

$stmt = $pdo->prepare("
    SELECT *
    FROM departments
    WHERE id = :id
    AND municipality_id = :municipality_id
    LIMIT 1
");

$stmt->execute([
    ':id' => $id,
    ':municipality_id' => $municipalityId
]);

$department =
    $stmt->fetch(PDO::FETCH_ASSOC);

if (!$department) {
    http_response_code(404);
    exit('Department not found.');
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    verifyCsrf();

    $name = trim($_POST['name'] ?? '');
    $code = strtoupper(trim($_POST['code'] ?? ''));
    $description = trim($_POST['description'] ?? '');
    $status = $_POST['status'] ?? 'active';

    if ($name === '' || $code === '') {

        $error =
            'Department name and code are required.';

    } elseif (
        !in_array(
            $status,
            ['active', 'inactive'],
            true
        )
    ) {

        $error = 'Invalid department status.';

    } else {

        try {

            $stmt = $pdo->prepare("
                SELECT id
                FROM departments
                WHERE municipality_id = :municipality_id
                AND code = :code
                AND id <> :id
                LIMIT 1
            ");

            $stmt->execute([
                ':municipality_id' => $municipalityId,
                ':code' => $code,
                ':id' => $id
            ]);

            if ($stmt->fetch()) {

                $error =
                    'That department code is already in use.';

            } else {

                $stmt = $pdo->prepare("
                    UPDATE departments
                    SET
                        name = :name,
                        code = :code,
                        description = :description,
                        status = :status
                    WHERE id = :id
                    AND municipality_id = :municipality_id
                ");

                $stmt->execute([
                    ':name' => $name,
                    ':code' => $code,
                    ':description' =>
                        $description !== ''
                        ? $description
                        : null,
                    ':status' => $status,
                    ':id' => $id,
                    ':municipality_id' => $municipalityId
                ]);

                auditLog(
                    $pdo,
                    $municipalityId,
                    $userId,
                    'update',
                    'department',
                    $id,
                    'Updated department: ' . $name
                );

                header(
                    'Location: view.php?id=' . $id
                );

                exit;
            }

        } catch (PDOException $e) {

            error_log(
                'Department update error: ' .
                $e->getMessage()
            );

            $error =
                'Unable to update the department.';
        }
    }
}

municipalityHeader(
    'Edit Department',
    'departments'
);

?>

<div class="page-header">

    <div>
        <h2>Edit Department</h2>
        <p>Update department information.</p>
    </div>

</div>

<?php if ($error !== ''): ?>

    <div class="alert error">
        <?= e($error) ?>
    </div>

<?php endif; ?>

<div class="card">

    <form method="POST">

        <input
            type="hidden"
            name="csrf_token"
            value="<?= e(csrfToken()) ?>"
        >

        <div class="form-grid">

            <div>

                <label for="name">
                    Department Name
                </label>

                <input
                    type="text"
                    id="name"
                    name="name"
                    maxlength="150"
                    required
                    value="<?= e(
                        $_POST['name']
                        ?? $department['name']
                    ) ?>"
                >

            </div>

            <div>

                <label for="code">
                    Department Code
                </label>

                <input
                    type="text"
                    id="code"
                    name="code"
                    maxlength="50"
                    required
                    value="<?= e(
                        $_POST['code']
                        ?? $department['code']
                    ) ?>"
                >

            </div>

            <div>

                <label for="status">
                    Status
                </label>

                <select
                    id="status"
                    name="status"
                >

                    <?php
                    $selectedStatus =
                        $_POST['status']
                        ?? $department['status'];
                    ?>

                    <option
                        value="active"
                        <?= $selectedStatus === 'active'
                            ? 'selected'
                            : '' ?>
                    >
                        Active
                    </option>

                    <option
                        value="inactive"
                        <?= $selectedStatus === 'inactive'
                            ? 'selected'
                            : '' ?>
                    >
                        Inactive
                    </option>

                </select>

            </div>

            <div class="full">

                <label for="description">
                    Description
                </label>

                <textarea
                    id="description"
                    name="description"
                ><?= e(
                    $_POST['description']
                    ?? $department['description']
                ) ?></textarea>

            </div>

        </div>

        <br>

        <button class="button">
            Save Changes
        </button>

        <a
            class="button secondary"
            href="view.php?id=<?= (int) $id ?>"
        >
            Cancel
        </a>

    </form>

</div>

<?php

municipalityFooter();
