<?php

declare(strict_types=1);

require_once __DIR__ . '/../auth.php';

if (!isMunicipalityAdmin()) {
    http_response_code(403);
    exit('Access denied.');
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.php');
    exit;
}

$id = filter_input(
    INPUT_POST,
    'id',
    FILTER_VALIDATE_INT
);

if (!$id) {
    http_response_code(400);
    exit('Invalid announcement ID.');
}

$title = trim($_POST['title'] ?? '');
$content = trim($_POST['content'] ?? '');
$status = trim($_POST['status'] ?? 'draft');

$publishAt = trim($_POST['publish_at'] ?? '');
$expiresAt = trim($_POST['expires_at'] ?? '');

$validStatuses = [
    'draft',
    'published',
    'archived'
];

if ($title === '') {
    exit('Title is required.');
}

if ($content === '') {
    exit('Content is required.');
}

if (!in_array($status, $validStatuses, true)) {
    exit('Invalid status.');
}

$publishAt = $publishAt !== ''
    ? date('Y-m-d H:i:s', strtotime($publishAt))
    : null;

$expiresAt = $expiresAt !== ''
    ? date('Y-m-d H:i:s', strtotime($expiresAt))
    : null;

$sql = "
    UPDATE announcements

    SET
        title = :title,
        content = :content,
        publish_at = :publish_at,
        expires_at = :expires_at,
        status = :status,
        updated_at = NOW()

    WHERE
        id = :id
        AND municipality_id = :municipality_id
";

$stmt = $pdo->prepare($sql);

$stmt->execute([
    ':title' => $title,
    ':content' => $content,
    ':publish_at' => $publishAt,
    ':expires_at' => $expiresAt,
    ':status' => $status,
    ':id' => $id,
    ':municipality_id' => $municipalityId
]);

header(
    'Location: view.php?id=' . $id
);

exit;