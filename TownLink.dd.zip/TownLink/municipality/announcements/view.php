<?php

declare(strict_types=1);

require_once __DIR__ . '/../auth.php';
require_once __DIR__ . '/../layout.php';

$id = filter_input(
    INPUT_GET,
    'id',
    FILTER_VALIDATE_INT
);

if (!$id) {
    http_response_code(400);
    exit('Invalid announcement ID.');
}

$sql = "
    SELECT
        a.id,
        a.title,
        a.content,
        a.publish_at,
        a.expires_at,
        a.status,
        a.created_at,
        a.updated_at,

        CASE
            WHEN u.id IS NOT NULL
            THEN CONCAT(
                u.first_name,
                ' ',
                u.last_name
            )
            ELSE 'System'
        END AS creator_name

    FROM announcements a

    LEFT JOIN users u
        ON u.id = a.created_by

    WHERE
        a.id = :id
        AND a.municipality_id = :municipality_id

    LIMIT 1
";

$stmt = $pdo->prepare($sql);

$stmt->execute([
    ':id' => $id,
    ':municipality_id' => $municipalityId
]);

$announcement = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$announcement) {
    http_response_code(404);
    exit('Announcement not found.');
}

municipalityHeader(
    'View Announcement',
    'announcements'
);

?>

<div class="page-header">

    <div>

        <h2>
            <?= e($announcement['title']) ?>
        </h2>

        <p>
            Announcement details
        </p>

    </div>

    <div>

        <?php if (isMunicipalityAdmin()): ?>

            <a
                class="button"
                href="edit.php?id=<?= (int) $announcement['id'] ?>"
            >
                Edit
            </a>

        <?php endif; ?>

        <a
            class="button secondary"
            href="index.php"
        >
            Back
        </a>

    </div>

</div>

<div class="card">

    <p>

        <strong>Status:</strong>

        <span
            class="badge <?= e(
                $announcement['status']
            ) ?>"
        >
            <?= e(
                ucfirst(
                    $announcement['status']
                )
            ) ?>
        </span>

    </p>

    <p>
        <strong>Created by:</strong>
        <?= e($announcement['creator_name']) ?>
    </p>

    <p>
        <strong>Created:</strong>
        <?= e($announcement['created_at']) ?>
    </p>

    <p>
        <strong>Last updated:</strong>
        <?= e($announcement['updated_at']) ?>
    </p>

    <hr>

    <h3>Announcement</h3>

    <div>
        <?= nl2br(e($announcement['content'])) ?>
    </div>

    <br>

    <div class="form-grid">

        <div>

            <strong>Publish Date</strong>

            <p>
                <?= e(
                    $announcement['publish_at']
                    ?? 'Not scheduled'
                ) ?>
            </p>

        </div>

        <div>

            <strong>Expiry Date</strong>

            <p>
                <?= e(
                    $announcement['expires_at']
                    ?? 'No expiry'
                ) ?>
            </p>

        </div>

    </div>

</div>

<?php

municipalityFooter();