<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| TownLink - Namibia Local Authority Service Directory
|--------------------------------------------------------------------------
| Purpose:
| - Inform residents about services offered by their local authority.
| - Support municipalities, town councils and village councils.
| - Display only services marked active by the local authority.
| - Allow residents to search and filter service information.
| - Do not submit service requests or reports from this page.
|
| Existing database tables:
| municipalities, users, services, departments,
| service_categories
|--------------------------------------------------------------------------
*/

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

require_once __DIR__ . '/../app/config/database.php';

/*
|--------------------------------------------------------------------------
| 1. AUTHENTICATION
|--------------------------------------------------------------------------
*/

if (empty($_SESSION['user_id'])) {
    header('Location: ../public/login.php');
    exit;
}

if (($_SESSION['role'] ?? '') !== 'resident') {
    http_response_code(403);
    exit('Access denied.');
}

$userId = (int) $_SESSION['user_id'];
$municipalityId = (int) ($_SESSION['municipality_id'] ?? 0);

$firstName = trim(
    (string) ($_SESSION['first_name'] ?? 'Resident')
);

if ($firstName === '') {
    $firstName = 'Resident';
}

/*
|--------------------------------------------------------------------------
| 2. HELPER FUNCTIONS
|--------------------------------------------------------------------------
*/

if (!function_exists('residentServicesEscape')) {
    function residentServicesEscape(mixed $value): string
    {
        return htmlspecialchars(
            (string) ($value ?? ''),
            ENT_QUOTES | ENT_SUBSTITUTE,
            'UTF-8'
        );
    }
}

function residentServiceIcon(string $category): string
{
    $category = strtolower($category);

    $icons = [
        'account'       => '💳',
        'utilit'        => '💧',
        'water'         => '🚰',
        'land'          => '🏡',
        'propert'       => '🏠',
        'planning'      => '📐',
        'waste'         => '♻️',
        'environment'   => '🌿',
        'road'          => '🛣️',
        'infrastructure'=> '🏗️',
        'communit'      => '🏘️',
        'facilit'       => '🏢',
        'business'      => '🏪',
        'market'        => '🛍️',
        'general'       => 'ℹ️',
        'customer'      => '🤝',
        'document'      => '📄',
    ];

    foreach ($icons as $keyword => $icon) {
        if (str_contains($category, $keyword)) {
            return $icon;
        }
    }

    return '🏛️';
}

/*
|--------------------------------------------------------------------------
| 3. INITIAL VALUES
|--------------------------------------------------------------------------
*/

$authorityName = '';
$authorityType = '';
$authorityRegion = '';

$services = [];
$categories = [];

$errorMessage = '';

/*
|--------------------------------------------------------------------------
| 4. LOAD RESIDENT'S LOCAL AUTHORITY
|--------------------------------------------------------------------------
*/

try {
    /*
    | Always verify the resident's authority against the database.
    */

    $stmt = $pdo->prepare("
        SELECT
            u.municipality_id,
            m.name AS authority_name,
            m.type AS authority_type,
            m.region AS authority_region
        FROM users u
        LEFT JOIN municipalities m
            ON m.id = u.municipality_id
           AND m.status = 'active'
        WHERE u.id = :user_id
          AND u.role = 'resident'
          AND u.status = 'active'
        LIMIT 1
    ");

    $stmt->execute([
        ':user_id' => $userId,
    ]);

    $resident = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$resident) {
        throw new RuntimeException(
            'Your resident account could not be verified. Please contact your administrator.'
        );
    }

    /*
    | Use the database relationship as the source of truth.
    */

    $databaseMunicipalityId = (int) (
        $resident['municipality_id'] ?? 0
    );

    if ($databaseMunicipalityId <= 0) {
        throw new RuntimeException(
            'Your account is not linked to a local authority. Please contact your administrator.'
        );
    }

    $municipalityId = $databaseMunicipalityId;

    if (empty($resident['authority_name'])) {
        throw new RuntimeException(
            'Your local authority is inactive or could not be found.'
        );
    }

    $authorityName = (string) $resident['authority_name'];

    $authorityRegion = (string) (
        $resident['authority_region'] ?? ''
    );

    $authorityTypes = [
        'municipality' => 'Municipality',
        'town'         => 'Town Council',
        'village'      => 'Village Council',
    ];

    $authorityType = $authorityTypes[
        (string) ($resident['authority_type'] ?? '')
    ] ?? 'Local Authority';

    /*
    |--------------------------------------------------------------------------
    | 5. LOAD PUBLISHED SERVICE INFORMATION
    |--------------------------------------------------------------------------
    |
    | Only active services belonging to this resident's authority
    | and an active department are displayed.
    |
    | An inactive category is treated as General Services.
    | Inactive services remain hidden.
    |--------------------------------------------------------------------------
    */

    $stmt = $pdo->prepare("
        SELECT
            s.id,
            s.name,
            s.description,
            s.instructions,
            s.estimated_days,
            s.category_id,

            d.name AS department_name,

            CASE
                WHEN c.id IS NOT NULL THEN c.name
                ELSE 'General Services'
            END AS category_name

        FROM services s

        INNER JOIN departments d
            ON d.id = s.department_id
           AND d.municipality_id = s.municipality_id
           AND d.status = 'active'

        LEFT JOIN service_categories c
            ON c.id = s.category_id
           AND c.municipality_id = s.municipality_id
           AND c.status = 'active'

        WHERE s.municipality_id = :municipality_id
          AND s.status = 'active'

        ORDER BY
            category_name ASC,
            s.name ASC
    ");

    $stmt->execute([
        ':municipality_id' => $municipalityId,
    ]);

    $services = $stmt->fetchAll(PDO::FETCH_ASSOC);

    /*
    | Build filters from categories that have published services.
    */

    foreach ($services as $service) {
        $categoryId = (
            $service['category_name'] === 'General Services'
        )
            ? 0
            : (int) $service['category_id'];

        $categoryName = (string) $service['category_name'];

        $categories[$categoryId] = [
            'id'   => $categoryId,
            'name' => $categoryName,
        ];
    }

    uasort(
        $categories,
        static fn(array $a, array $b): int =>
            strcasecmp($a['name'], $b['name'])
    );

} catch (RuntimeException $e) {
    $errorMessage = $e->getMessage();

} catch (Throwable $e) {
    error_log(
        'TownLink service directory error: ' .
        $e->getMessage()
    );

    $errorMessage =
        'We could not load the service directory. Please try again later.';
}

$totalServices = count($services);
$totalCategories = count($categories);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1"
    >

    <meta
        name="description"
        content="Explore services, application information and local authority procedures through TownLink Namibia."
    >

    <title>Local Services | TownLink</title>
      <link rel="stylesheet" href="../assets/vendor/bootstrap-icons/bootstrap-icons.css">

    <style>
        :root {
            --primary: #176b52;
            --primary-dark: #10523f;
            --primary-soft: #e8f5ef;

            --page: #f4f7f6;
            --surface: #ffffff;

            --text: #20332b;
            --muted: #687970;
            --border: #e0e9e4;

            --danger: #991b1b;

            --radius: 15px;
        }

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            background: var(--page);
            color: var(--text);
            font-family: Arial, Helvetica, sans-serif;
            line-height: 1.65;
        }

        input,
        select,
        button {
            font: inherit;
        }

        [hidden] {
            display: none !important;
        }

        a {
            color: var(--primary);
        }

        .container {
            width: min(1200px, 100%);
            margin: 0 auto;
            padding: 28px 22px 45px;
        }

        /* Welcome section */

        .welcome {
            margin-bottom: 25px;
            padding: 32px;
            border-radius: 18px;
            background: linear-gradient(
                120deg,
                #103d32,
                #176b52 65%,
                #299577
            );
            color: white;
        }

        .welcome h1 {
            margin: 0 0 10px;
            font-size: clamp(27px, 4vw, 36px);
            line-height: 1.25;
        }

        .welcome p {
            margin: 8px 0;
        }

        .welcome-description {
            max-width: 760px;
            color: #e0f5eb;
        }

        .authority-badge {
            display: inline-flex;
            flex-wrap: wrap;
            align-items: center;
            gap: 5px;
            margin-top: 13px;
            padding: 7px 12px;
            border: 1px solid rgb(255 255 255 / 25%);
            border-radius: 30px;
            background: rgb(255 255 255 / 10%);
            color: white;
            font-size: 12px;
            font-weight: 700;
        }

        /* Information notice */

        .information-note {
            display: flex;
            gap: 13px;
            align-items: flex-start;
            margin-bottom: 30px;
            padding: 17px 19px;
            border: 1px solid #cce5d8;
            border-radius: 12px;
            background: #f0faf4;
        }

        .information-note-icon {
            flex-shrink: 0;
            font-size: 22px;
        }

        .information-note strong {
            display: block;
            margin-bottom: 3px;
        }

        .information-note p {
            margin: 0;
            color: #526b5d;
            font-size: 14px;
        }

        /* Summary */

        .summary {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 16px;
            margin-bottom: 34px;
        }

        .summary-card {
            min-width: 0;
            padding: 20px;
            border: 1px solid var(--border);
            border-radius: var(--radius);
            background: var(--surface);
        }

        .summary-card span {
            display: block;
            color: var(--muted);
            font-size: 13px;
        }

        .summary-card strong {
            display: block;
            margin-top: 5px;
            font-size: 24px;
            overflow-wrap: anywhere;
        }

        .summary-card .small-value {
            font-size: 18px;
        }

        /* Directory heading */

        .section-heading {
            margin-bottom: 20px;
        }

        .section-heading h2 {
            margin: 0 0 5px;
            font-size: 25px;
        }

        .section-heading p {
            margin: 0;
            color: var(--muted);
        }

        /* Search */

        .filters {
            display: grid;
            grid-template-columns: minmax(0, 2fr) minmax(210px, 1fr);
            gap: 12px;
            margin-bottom: 15px;
        }

        .filters input,
        .filters select {
            width: 100%;
            min-height: 49px;
            padding: 11px 14px;
            border: 1px solid var(--border);
            border-radius: 10px;
            background: white;
            color: var(--text);
        }

        .filters input:focus,
        .filters select:focus,
        .reset-button:focus-visible {
            outline: 3px solid #8bd0b7;
            outline-offset: 2px;
        }

        .results-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 10px;
            margin-bottom: 18px;
        }

        .results-count {
            margin: 0;
            color: var(--muted);
            font-size: 13px;
        }

        .reset-button {
            padding: 7px 11px;
            border: 1px solid var(--border);
            border-radius: 8px;
            background: white;
            color: var(--primary);
            font-size: 13px;
            font-weight: 700;
            cursor: pointer;
        }

        .reset-button:hover {
            background: var(--primary-soft);
        }

        /* Service directory cards */

        .service-grid {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            align-items: stretch;
            gap: 19px;
        }

        .service-card {
            display: flex;
            min-width: 0;
            flex-direction: column;
            padding: 22px;
            border: 1px solid var(--border);
            border-radius: var(--radius);
            background: var(--surface);
            box-shadow: 0 4px 14px rgb(20 50 40 / 3%);
            transition: border-color .2s, box-shadow .2s;
        }

        .service-card:hover {
            border-color: #b5d9c9;
            box-shadow: 0 7px 22px rgb(20 50 40 / 7%);
        }

        .service-icon {
            display: grid;
            width: 47px;
            height: 47px;
            place-items: center;
            margin-bottom: 14px;
            border-radius: 12px;
            background: var(--primary-soft);
            font-size: 23px;
        }

        .category {
            align-self: flex-start;
            margin-bottom: 8px;
            padding: 4px 9px;
            border-radius: 20px;
            background: #edf5f1;
            color: var(--primary-dark);
            font-size: 11px;
            font-weight: 700;
        }

        .service-card h3 {
            margin: 4px 0 10px;
            font-size: 18px;
            line-height: 1.4;
            overflow-wrap: anywhere;
        }

        .description {
            margin: 0 0 15px;
            color: #5f7068;
            font-size: 14px;
            overflow-wrap: anywhere;
            white-space: pre-line;
        }

        .service-information {
            margin-top: auto;
            padding-top: 13px;
            border-top: 1px solid var(--border);
        }

        .service-information h4 {
            margin: 0 0 7px;
            font-size: 13px;
        }

        .service-information p {
            margin: 0;
            color: var(--muted);
            font-size: 13px;
            overflow-wrap: anywhere;
            white-space: pre-line;
        }

        .department {
            margin-top: 14px;
            padding-top: 12px;
            border-top: 1px solid var(--border);
            color: var(--muted);
            font-size: 12px;
        }

        .department strong {
            color: var(--text);
        }

        .processing {
            margin-top: 5px;
            color: var(--muted);
            font-size: 12px;
        }

        .processing strong {
            color: var(--text);
        }

        .availability-note {
            margin-top: 14px;
            padding: 10px 12px;
            border-radius: 8px;
            background: #f5f8f6;
            color: #586a61;
            font-size: 12px;
        }

        /* Empty and error states */

        .empty-state,
        .error-state {
            grid-column: 1 / -1;
            padding: 36px 22px;
            border: 1px dashed #c7d8ce;
            border-radius: var(--radius);
            background: white;
            text-align: center;
        }

        .empty-icon {
            margin-bottom: 10px;
            font-size: 35px;
        }

        .empty-state h3,
        .error-state h3 {
            margin: 0 0 8px;
        }

        .empty-state p,
        .error-state p {
            max-width: 620px;
            margin: 0 auto;
            color: var(--muted);
        }

        .error-state {
            border-style: solid;
            border-color: #f1caca;
            background: #fff5f5;
            color: var(--danger);
        }

        /* Footer */

        .footer {
            padding: 23px;
            color: var(--muted);
            text-align: center;
            font-size: 12px;
        }

        /* Responsive layout */

        @media (max-width: 950px) {
            .service-grid {
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }
        }

        @media (max-width: 620px) {
            .container {
                padding: 20px 14px 35px;
            }

            .welcome {
                padding: 24px 19px;
            }

            .summary {
                grid-template-columns: 1fr;
                gap: 10px;
                margin-bottom: 28px;
            }

            .summary-card {
                padding: 15px;
            }

            .filters,
            .service-grid {
                grid-template-columns: 1fr;
            }

            .service-card {
                padding: 19px;
            }

            .section-heading h2 {
                font-size: 22px;
            }
        }

        @media (prefers-reduced-motion: reduce) {
            *,
            *::before,
            *::after {
                transition: none !important;
            }
        }
    </style>
</head>

<body>

<?php require_once __DIR__ . '/_navbar.php'; ?>

<main class="container">

    <!-- Welcome -->

    <section class="welcome">

        <h1>Local Government Services</h1>

        <p>
            Welcome, <?= residentServicesEscape($firstName) ?>.
        </p>

        <p class="welcome-description">
            Discover the services your local authority offers.
            Learn about municipal accounts, land and property,
            community facilities, application procedures and more.
            Everything displayed here is intended to help you
            understand the services available in your community.
        </p>

        <div class="authority-badge">
            <?= residentServicesEscape($authorityType) ?>

            <span aria-hidden="true">·</span>

            <?= residentServicesEscape($authorityName) ?>

            <?php if ($authorityRegion !== ''): ?>
                <span aria-hidden="true">·</span>
                <?= residentServicesEscape($authorityRegion) ?> Region
            <?php endif; ?>
        </div>

    </section>

    <aside class="information-note">

        <div class="information-note-icon" aria-hidden="true">
            ℹ️
        </div>

        <div>
            <strong>Your local authority service guide</strong>

            <p>
                Browse information about services offered by
                <?= residentServicesEscape($authorityName) ?>.
                Requirements, fees, availability and processing
                times may vary. Contact the responsible department
                to confirm the latest information before making
                arrangements.
            </p>
        </div>

    </aside>

    <?php if ($errorMessage !== ''): ?>

        <section class="error-state" role="alert">
            <h3>Service information is unavailable</h3>

            <p>
                <?= residentServicesEscape($errorMessage) ?>
            </p>
        </section>

    <?php else: ?>

        <!-- Summary -->

        <section class="summary" aria-label="Service directory overview">

            <div class="summary-card">
                <span>Published services</span>

                <strong>
                    <?= number_format($totalServices) ?>
                </strong>
            </div>

            <div class="summary-card">
                <span>Service categories</span>

                <strong>
                    <?= number_format($totalCategories) ?>
                </strong>
            </div>

            <div class="summary-card">
                <span>Your local authority</span>

                <strong class="small-value">
                    <?= residentServicesEscape($authorityName) ?>
                </strong>
            </div>

        </section>

        <!-- Directory -->

        <section aria-labelledby="servicesHeading">

            <div class="section-heading">

                <h2 id="servicesHeading">
                    Explore Available Services
                </h2>

                <p>
                    Find out what your council offers, which
                    department is responsible and what you may
                    need to know before contacting the council.
                </p>

            </div>

            <?php if ($totalServices > 0): ?>

                <!-- Search and category filters -->

                <div class="filters">

                    <input
                        type="search"
                        id="serviceSearch"
                        placeholder="Find a service, topic or department..."
                        aria-label="Search service information"
                        autocomplete="off"
                    >

                    <select
                        id="categoryFilter"
                        aria-label="Filter by service category"
                    >
                        <option value="">
                            All service categories
                        </option>

                        <?php foreach ($categories as $category): ?>

                            <option value="<?= (int) $category['id'] ?>">
                                <?= residentServicesEscape(
                                    $category['name']
                                ) ?>
                            </option>

                        <?php endforeach; ?>

                    </select>

                </div>

                <div class="results-bar">

                    <p class="results-count" aria-live="polite">
                        Showing
                        <strong id="visibleCount">
                            <?= $totalServices ?>
                        </strong>
                        of <?= $totalServices ?> published services
                    </p>

                    <button
                        type="button"
                        class="reset-button"
                        id="resetFilters"
                    >
                        Clear filters
                    </button>

                </div>

                <div class="service-grid" id="serviceGrid">

                    <?php foreach ($services as $service): ?>

                        <?php
                        $serviceName = (string) $service['name'];

                        $description = trim(
                            (string) ($service['description'] ?? '')
                        );

                        $instructions = trim(
                            (string) ($service['instructions'] ?? '')
                        );

                        $categoryName = (string) (
                            $service['category_name']
                            ?? 'General Services'
                        );

                        $categoryId = $categoryName === 'General Services'
                            ? 0
                            : (int) $service['category_id'];

                        $departmentName = (string) (
                            $service['department_name']
                            ?? 'Local Authority'
                        );

                        $estimatedDays = $service['estimated_days'];

                        $searchText = strtolower(
                            $serviceName . ' ' .
                            $description . ' ' .
                            $instructions . ' ' .
                            $categoryName . ' ' .
                            $departmentName
                        );
                        ?>

                        <article
                            class="service-card"
                            data-category="<?= $categoryId ?>"
                            data-search="<?= residentServicesEscape(
                                $searchText
                            ) ?>"
                        >

                            <div
                                class="service-icon"
                                aria-hidden="true"
                            >
                                <?= residentServiceIcon($categoryName) ?>
                            </div>

                            <span class="category">
                                <?= residentServicesEscape(
                                    $categoryName
                                ) ?>
                            </span>

                            <h3>
                                <?= residentServicesEscape(
                                    $serviceName
                                ) ?>
                            </h3>

                            <p class="description">
                                <?= residentServicesEscape(
                                    $description !== ''
                                        ? $description
                                        : 'Contact the responsible department for more information about this service.'
                                ) ?>
                            </p>

                            <?php if ($instructions !== ''): ?>

                                <div class="service-information">

                                    <h4>
                                        Requirements and guidance
                                    </h4>

                                    <p>
                                        <?= residentServicesEscape(
                                            $instructions
                                        ) ?>
                                    </p>

                                </div>

                            <?php endif; ?>

                            <div class="department">

                                <strong>
                                    Responsible department:
                                </strong>

                                <?= residentServicesEscape(
                                    $departmentName
                                ) ?>

                            </div>

                            <div class="processing">

                                <strong>
                                    Indicative processing time:
                                </strong>

                                <?php if (
                                    $estimatedDays !== null &&
                                    $estimatedDays !== ''
                                ): ?>

                                    <?= (int) $estimatedDays ?>
                                    day(s)

                                <?php else: ?>

                                    Not specified

                                <?php endif; ?>

                            </div>

                            <div class="availability-note">
                                Information relates to
                                <?= residentServicesEscape(
                                    $authorityName
                                ) ?>.
                                Confirm current requirements,
                                applicable fees and availability
                                with the responsible department.
                            </div>

                        </article>

                    <?php endforeach; ?>

                    <div
                        class="empty-state"
                        id="noSearchResults"
                        hidden
                    >

                        <div class="empty-icon" aria-hidden="true">
                            🔎
                        </div>

                        <h3>No matching services</h3>

                        <p>
                            Try another search term or select
                            a different service category.
                        </p>

                    </div>

                </div>

            <?php else: ?>

                <div class="empty-state">

                    <div class="empty-icon" aria-hidden="true">
                        🏛️
                    </div>

                    <h3>
                        Service information is being prepared
                    </h3>

                    <p>
                        There are currently no published services
                        for <?= residentServicesEscape(
                            $authorityName
                        ) ?>.

                        The local authority administrator can add
                        and activate verified service information
                        when it is ready.
                    </p>

                </div>

            <?php endif; ?>

        </section>

    <?php endif; ?>

</main>

<footer class="footer">
    &copy; <?= date('Y') ?> TownLink.
    Helping Namibia's communities understand local government services.
</footer>

<script>
(function () {
    'use strict';

    const searchInput = document.getElementById('serviceSearch');

    const categoryFilter = document.getElementById('categoryFilter');

    const resetButton = document.getElementById('resetFilters');

    const cards = Array.from(
        document.querySelectorAll('.service-card')
    );

    const visibleCount = document.getElementById('visibleCount');

    const noResults = document.getElementById('noSearchResults');

    function filterServices() {
        if (!searchInput || !categoryFilter) {
            return;
        }

        const query = searchInput.value.trim().toLowerCase();

        const selectedCategory = categoryFilter.value;

        let visible = 0;

        cards.forEach(function (card) {
            const text = card.dataset.search || '';

            const category = card.dataset.category || '0';

            const matchesSearch = text.includes(query);

            const matchesCategory =
                selectedCategory === '' ||
                category === selectedCategory;

            const matches = matchesSearch && matchesCategory;

            card.hidden = !matches;

            if (matches) {
                visible++;
            }
        });

        if (visibleCount) {
            visibleCount.textContent = String(visible);
        }

        if (noResults) {
            noResults.hidden = visible !== 0;
        }
    }

    if (searchInput) {
        searchInput.addEventListener('input', filterServices);
    }

    if (categoryFilter) {
        categoryFilter.addEventListener('change', filterServices);
    }

    if (resetButton) {
        resetButton.addEventListener('click', function () {
            if (searchInput) {
                searchInput.value = '';
            }

            if (categoryFilter) {
                categoryFilter.value = '';
            }

            filterServices();

            if (searchInput) {
                searchInput.focus();
            }
        });
    }
})();
</script>

</body>
</html>