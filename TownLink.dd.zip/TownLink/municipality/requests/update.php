<?php

declare(strict_types=1);

require_once __DIR__ . '/../auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {

    http_response_code(405);

    exit('Method not allowed.');
}

verifyCsrf();

$requestId = filter_input(
    INPUT_POST,
    'request_id',
    FILTER_VALIDATE_INT
);

if (!$requestId) {

    http_response_code(400);

    exit('Invalid request.');
}

$newStatus = trim(
    $_POST['status'] ?? ''
);

$departmentId = filter_input(
    INPUT_POST,
    'department_id',
    FILTER_VALIDATE_INT
);

$assignedTo = filter_input(
    INPUT_POST,
    'assigned_to',
    FILTER_VALIDATE_INT
);

$note = trim(
    $_POST['note'] ?? ''
);

$validStatuses = [
    'submitted',
    'under_review',
    'assigned',
    'in_progress',
    'pending_resident',
    'resolved',
    'closed',
    'rejected',
    'cancelled'
];

if (!in_array($newStatus, $validStatuses, true)) {

    http_response_code(400);

    exit('Invalid status.');
}

try {

    /*
    |--------------------------------------------------------------------------
    | Load Request
    |--------------------------------------------------------------------------
    */

    $sql = "
        SELECT
            sr.*,
            s.department_id
        FROM service_requests sr

        INNER JOIN services s
            ON s.id = sr.service_id

        WHERE sr.id = :id
        AND sr.municipality_id = :municipality_id
    ";

    $params = [
        ':id' => $requestId,
        ':municipality_id' => $municipalityId
    ];

    /*
    |--------------------------------------------------------------------------
    | Department Staff Can Only Access Their Department
    |--------------------------------------------------------------------------
    */

    if (!isMunicipalityAdmin()) {

        if ($currentUser['department_id'] === null) {

            http_response_code(403);

            exit(
                'No department is assigned to your account.'
            );
        }

        $sql .= "
            AND s.department_id = :current_department_id
        ";

        $params[':current_department_id'] =
            (int) $currentUser['department_id'];
    }

    $sql .= "
        LIMIT 1
    ";

    $stmt = $pdo->prepare($sql);

    $stmt->execute($params);

    $request = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$request) {

        http_response_code(404);

        exit('Request not found.');
    }

    $oldStatus = $request['status'];

    /*
    |--------------------------------------------------------------------------
    | Validate Department
    |--------------------------------------------------------------------------
    */

    if ($departmentId) {

        $stmt = $pdo->prepare("
            SELECT id
            FROM departments
            WHERE id = :id
            AND municipality_id = :municipality_id
            AND status = 'active'
            LIMIT 1
        ");

        $stmt->execute([
            ':id' => $departmentId,
            ':municipality_id' => $municipalityId
        ]);

        if (!$stmt->fetch()) {

            http_response_code(400);

            exit(
                'Invalid assignment department.'
            );
        }

    } elseif (
        $newStatus === 'assigned'
        && !empty($request['department_id'])
    ) {

        $departmentId =
            (int) $request['department_id'];
    }

    /*
    |--------------------------------------------------------------------------
    | Validate Assigned Staff
    |--------------------------------------------------------------------------
    */

    if ($assignedTo) {

        $stmt = $pdo->prepare("
            SELECT id
            FROM users
            WHERE id = :id
            AND municipality_id = :municipality_id
            AND role = 'department_staff'
            AND status = 'active'
            LIMIT 1
        ");

        $stmt->execute([
            ':id' => $assignedTo,
            ':municipality_id' => $municipalityId
        ]);

        if (!$stmt->fetch()) {

            http_response_code(400);

            exit(
                'Invalid staff member.'
            );
        }
    }

    /*
    |--------------------------------------------------------------------------
    | Transaction
    |--------------------------------------------------------------------------
    */

    $pdo->beginTransaction();

    /*
    |--------------------------------------------------------------------------
    | Resolution / Closure Dates
    |--------------------------------------------------------------------------
    */

    $resolvedAt = $request['resolved_at'];
    $closedAt = $request['closed_at'];

    if ($newStatus === 'resolved') {

        $resolvedAt = date(
            'Y-m-d H:i:s'
        );
    }

    if ($newStatus === 'closed') {

        $closedAt = date(
            'Y-m-d H:i:s'
        );

        if ($resolvedAt === null) {

            $resolvedAt = date(
                'Y-m-d H:i:s'
            );
        }
    }

    /*
    |--------------------------------------------------------------------------
    | Update Request
    |--------------------------------------------------------------------------
    */

    $stmt = $pdo->prepare("
        UPDATE service_requests

        SET
            status = :status,
            resolved_at = :resolved_at,
            closed_at = :closed_at

        WHERE id = :id
        AND municipality_id = :municipality_id
    ");

    $stmt->execute([
        ':status' => $newStatus,
        ':resolved_at' => $resolvedAt,
        ':closed_at' => $closedAt,
        ':id' => $requestId,
        ':municipality_id' => $municipalityId
    ]);

    /*
    |--------------------------------------------------------------------------
    | Status History
    |--------------------------------------------------------------------------
    */

    if ($oldStatus !== $newStatus) {

        $stmt = $pdo->prepare("
            INSERT INTO request_status_history
            (
                request_id,
                changed_by,
                old_status,
                new_status,
                comment
            )
            VALUES
            (
                :request_id,
                :changed_by,
                :old_status,
                :new_status,
                :comment
            )
        ");

        $stmt->execute([
            ':request_id' => $requestId,
            ':changed_by' => $userId,
            ':old_status' => $oldStatus,
            ':new_status' => $newStatus,
            ':comment' =>
                $note !== ''
                    ? $note
                    : null
        ]);
    }

    /*
    |--------------------------------------------------------------------------
    | Assignment
    |--------------------------------------------------------------------------
    */

    if ($departmentId || $assignedTo) {

        $stmt = $pdo->prepare("
            UPDATE request_assignments

            SET unassigned_at = CURRENT_TIMESTAMP

            WHERE request_id = :request_id
            AND unassigned_at IS NULL
        ");

        $stmt->execute([
            ':request_id' => $requestId
        ]);

        if ($departmentId) {

            $stmt = $pdo->prepare("
                INSERT INTO request_assignments
                (
                    request_id,
                    department_id,
                    assigned_to,
                    notes
                )
                VALUES
                (
                    :request_id,
                    :department_id,
                    :assigned_to,
                    :notes
                )
            ");

            $stmt->execute([
                ':request_id' => $requestId,
                ':department_id' => $departmentId,
                ':assigned_to' =>
                    $assignedTo ?: null,
                ':notes' =>
                    $note !== ''
                        ? $note
                        : null
            ]);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | Commit
    |--------------------------------------------------------------------------
    */

    $pdo->commit();

    /*
    |--------------------------------------------------------------------------
    | Audit
    |--------------------------------------------------------------------------
    */

    auditLog(
        $pdo,
        $municipalityId,
        $userId,
        'update',
        'service_request',
        $requestId,
        'Updated service request ' .
        $request['reference_number'] .
        ' to status ' .
        $newStatus
    );

    /*
    |--------------------------------------------------------------------------
    | Return
    |--------------------------------------------------------------------------
    */

    header(
        'Location: view.php?id=' . $requestId
    );

    exit;

} catch (PDOException $e) {

    if ($pdo->inTransaction()) {

        $pdo->rollBack();
    }

    error_log(
        'TownLink request update error: ' .
        $e->getMessage()
    );

    http_response_code(500);

    exit(
        'Unable to update request.'
    );
}