<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| TownLink - Resident My Requests
|--------------------------------------------------------------------------
*/

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

require_once __DIR__ . '/../app/config/database.php';

/*
|--------------------------------------------------------------------------
| Authentication
|--------------------------------------------------------------------------
*/

if (empty($_SESSION['user_id'])) {
    header('Location: ../public/login.php');
    exit;
}

if (($_SESSION['role'] ?? '') !== 'resident') {
    http_response_code(403);
    exit('Access denied.');
}

$userId = (int) $_SESSION['user_id'];
$municipalityId = (int) ($_SESSION['municipality_id'] ?? 0);
$firstName = trim((string) ($_SESSION['first_name'] ?? 'Resident'));

if ($municipalityId <= 0) {
    http_response_code(403);
    exit('Your account is not linked to a local authority.');
}

/*
|--------------------------------------------------------------------------
| Helpers
|--------------------------------------------------------------------------
*/

if (!function_exists('residentRequestsEscape')) {
    function residentRequestsEscape(mixed $value): string
    {
        return htmlspecialchars(
            (string) ($value ?? ''),
            ENT_QUOTES | ENT_SUBSTITUTE,
            'UTF-8'
        );
    }
}

if (!function_exists('residentRequestStatusLabel')) {
    function residentRequestStatusLabel(mixed $status): string
    {
        return match (strtolower(trim((string) $status))) {
            'submitted'       => 'Submitted',
            'under_review'    => 'Under Review',
            'assigned'        => 'Assigned',
            'in_progress'     => 'In Progress',
            'pending_resident'=> 'Action Required',
            'resolved'        => 'Resolved',
            'closed'          => 'Closed',
            'rejected'        => 'Rejected',
            'cancelled'       => 'Cancelled',
            default           => 'Unknown',
        };
    }
}

if (!function_exists('residentRequestStatusClass')) {
    function residentRequestStatusClass(mixed $status): string
    {
        return match (strtolower(trim((string) $status))) {
            'submitted'        => 'status-submitted',
            'under_review'     => 'status-review',
            'assigned'         => 'status-assigned',
            'in_progress'      => 'status-progress',
            'pending_resident' => 'status-action',
            'resolved'         => 'status-resolved',
            'closed'           => 'status-closed',
            'rejected'         => 'status-rejected',
            'cancelled'        => 'status-cancelled',
            default            => 'status-submitted',
        };
    }
}

/*
|--------------------------------------------------------------------------
| Load Local Authority
|--------------------------------------------------------------------------
*/

$municipalityName = 'Your Local Authority';
$authorityType = 'municipality';
$requests = [];
$errorMessage = '';

try {
    $stmt = $pdo->prepare("
        SELECT name, type
        FROM municipalities
        WHERE id = :municipality_id
          AND status = 'active'
        LIMIT 1
    ");

    $stmt->execute([
        ':municipality_id' => $municipalityId,
    ]);

    $municipality = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$municipality) {
        http_response_code(403);
        exit('Your local authority could not be found or is inactive.');
    }

    $municipalityName = (string) $municipality['name'];
    $authorityType = (string) $municipality['type'];

    /*
    |--------------------------------------------------------------------------
    | Load Requests Belonging to This Resident
    |--------------------------------------------------------------------------
    |
    | Actual table: service_requests
    | Resident column: resident_id
    | Service table: services
    |
    */

    $stmt = $pdo->prepare("
        SELECT
            sr.id,
            sr.reference_number,
            sr.subject,
            sr.description,
            sr.status,
            sr.priority,
            sr.submitted_at,
            sr.updated_at,
            sr.resolved_at,
            sr.closed_at,
            s.name AS service_name
        FROM service_requests sr
        LEFT JOIN services s
            ON s.id = sr.service_id
           AND s.municipality_id = sr.municipality_id
        WHERE sr.resident_id = :resident_id
          AND sr.municipality_id = :municipality_id
        ORDER BY sr.submitted_at DESC, sr.id DESC
    ");

    $stmt->execute([
        ':resident_id' => $userId,
        ':municipality_id' => $municipalityId,
    ]);

    $requests = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    error_log(
        'TownLink resident requests error: ' . $e->getMessage()
    );

    $errorMessage =
        'We could not load your requests. Please try again later.';
}

/*
|--------------------------------------------------------------------------
| Request Statistics
|--------------------------------------------------------------------------
*/

$totalRequests = count($requests);
$activeRequests = 0;
$actionRequired = 0;
$resolvedRequests = 0;
$closedRequests = 0;

foreach ($requests as $request) {
    $status = strtolower(
        trim((string) ($request['status'] ?? ''))
    );

    if (in_array($status, [
        'submitted',
        'under_review',
        'assigned',
        'in_progress',
    ], true)) {
        $activeRequests++;
    }

    if ($status === 'pending_resident') {
        $actionRequired++;
    }

    if ($status === 'resolved') {
        $resolvedRequests++;
    }

    if ($status === 'closed') {
        $closedRequests++;
    }
}

$authorityLabel = match ($authorityType) {
    'town' => 'Town Council',
    'village' => 'Village Council',
    default => 'Municipality',
};
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta
        name="description"
        content="View and track your municipal service requests on TownLink."
    >

    <title>My Requests | TownLink</title>
     <link rel="stylesheet" href="../assets/vendor/bootstrap-icons/bootstrap-icons.css">

    <style>
        :root {
            --primary: #176b57;
            --primary-dark: #105343;
            --page: #f4f7f6;
            --surface: #ffffff;
            --text: #172b26;
            --muted: #65756f;
            --border: #dfe8e4;
            --radius: 14px;
        }

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            background: var(--page);
            color: var(--text);
            font-family: Arial, Helvetica, sans-serif;
            line-height: 1.6;
        }

        a {
            color: var(--primary);
        }

        .container {
            width: 100%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 28px 24px 45px;
        }

        .welcome {
            padding: 30px;
            margin-bottom: 24px;
            border-radius: 18px;
            background: linear-gradient(
                120deg,
                #176b57,
                #239477
            );
            color: #fff;
        }

        .welcome h1 {
            margin: 0 0 8px;
            font-size: clamp(25px, 4vw, 34px);
        }

        .welcome p {
            margin: 5px 0;
        }

        .welcome .subtitle {
            color: #e0f6ed;
        }

        .summary {
            display: grid;
            grid-template-columns: repeat(4, minmax(0, 1fr));
            gap: 16px;
            margin-bottom: 28px;
        }

        .summary-card {
            min-width: 0;
            padding: 20px;
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: var(--radius);
        }

        .summary-card span {
            display: block;
            color: var(--muted);
            font-size: 13px;
        }

        .summary-card strong {
            display: block;
            margin-top: 5px;
            font-size: 28px;
        }

        .section-heading {
            margin-bottom: 18px;
        }

        .section-heading h2 {
            margin: 0 0 4px;
            font-size: 23px;
        }

        .section-heading p {
            margin: 0;
            color: var(--muted);
        }

        .panel {
            overflow: hidden;
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: var(--radius);
        }

        .toolbar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 12px;
            padding: 18px 20px;
            border-bottom: 1px solid var(--border);
        }

        .toolbar input,
        .toolbar select {
            min-height: 44px;
            padding: 10px 12px;
            border: 1px solid var(--border);
            border-radius: 8px;
            background: #fff;
            color: var(--text);
            font: inherit;
        }

        .toolbar input {
            flex: 1;
            min-width: 200px;
        }

        .toolbar select {
            min-width: 180px;
        }

        .toolbar input:focus,
        .toolbar select:focus {
            outline: 2px solid #80cbb7;
            outline-offset: 2px;
        }

        .table-wrapper {
            width: 100%;
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            text-align: left;
        }

        th,
        td {
            padding: 16px 20px;
            border-bottom: 1px solid var(--border);
            vertical-align: middle;
        }

        th {
            background: #f8fbf9;
            color: var(--muted);
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: .4px;
            white-space: nowrap;
        }

        td {
            font-size: 14px;
        }

        tbody tr:last-child td {
            border-bottom: 0;
        }

        tbody tr:hover {
            background: #fbfdfc;
        }

        .reference {
            color: var(--primary);
            font-weight: 700;
            overflow-wrap: anywhere;
        }

        .request-subject {
            font-weight: 700;
            margin-bottom: 3px;
        }

        .request-service {
            color: var(--muted);
            font-size: 12px;
        }

        .status {
            display: inline-block;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 700;
            white-space: nowrap;
        }

        .status-submitted {
            background: #fff4d6;
            color: #865b00;
        }

        .status-review {
            background: #e8edff;
            color: #354eaa;
        }

        .status-assigned {
            background: #e9e4ff;
            color: #5b35a5;
        }

        .status-progress {
            background: #e2f2ff;
            color: #075985;
        }

        .status-action {
            background: #fff0d9;
            color: #8b5a14;
        }

        .status-resolved {
            background: #d9f5e5;
            color: #11633d;
        }

        .status-closed {
            background: #e5f2e9;
            color: #245c3b;
        }

        .status-rejected {
            background: #ffe5e5;
            color: #a32323;
        }

        .status-cancelled {
            background: #edf0ee;
            color: #58645e;
        }

        .priority {
            font-size: 12px;
            font-weight: 700;
        }

        .priority-low {
            color: #65756f;
        }

        .priority-normal {
            color: #52645b;
        }

        .priority-high {
            color: #a15c00;
        }

        .priority-urgent {
            color: #b42318;
        }

        .button {
            display: inline-flex;
            justify-content: center;
            align-items: center;
            min-height: 39px;
            padding: 8px 13px;
            border: 0;
            border-radius: 8px;
            background: var(--primary);
            color: white;
            text-decoration: none;
            font-size: 13px;
            font-weight: 700;
            white-space: nowrap;
        }

        .button:hover {
            background: var(--primary-dark);
            color: white;
        }

        .button-secondary {
            border: 1px solid var(--border);
            background: white;
            color: var(--primary);
        }

        .button-secondary:hover {
            background: #edf5f1;
            color: var(--primary-dark);
        }

        .empty-state {
            padding: 45px 20px;
            text-align: center;
        }

        .empty-state h3 {
            margin: 0 0 8px;
        }

        .empty-state p {
            max-width: 500px;
            margin: 0 auto 18px;
            color: var(--muted);
        }

        .empty-icon {
            display: grid;
            place-items: center;
            width: 58px;
            height: 58px;
            margin: 0 auto 15px;
            border-radius: 16px;
            background: #e4f4ed;
            font-size: 27px;
        }

        .message {
            padding: 16px;
            margin-bottom: 22px;
            border: 1px solid #f0caca;
            border-radius: 10px;
            background: #fff0f0;
            color: #a32323;
        }

        .message p {
            margin: 5px 0 0;
        }

        .results-count {
            padding: 13px 20px;
            border-top: 1px solid var(--border);
            color: var(--muted);
            font-size: 12px;
        }

        .footer {
            padding: 22px;
            text-align: center;
            color: var(--muted);
            font-size: 13px;
        }

        [hidden] {
            display: none !important;
        }

        @media (max-width: 950px) {
            .summary {
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }
        }

        @media (max-width: 650px) {
            .container {
                padding: 20px 14px 35px;
            }

            .welcome {
                padding: 23px;
            }

            .summary {
                gap: 10px;
            }

            .summary-card {
                padding: 15px;
            }

            .summary-card strong {
                font-size: 24px;
            }

            .toolbar {
                align-items: stretch;
            }

            .toolbar input,
            .toolbar select {
                width: 100%;
                min-width: 0;
            }

            th,
            td {
                padding: 13px 14px;
            }
        }

        @media (prefers-reduced-motion: reduce) {
            *,
            *::before,
            *::after {
                scroll-behavior: auto !important;
                animation-duration: .01ms !important;
                transition-duration: .01ms !important;
            }
        }
    </style>
</head>

<body>

<?php
/*
|--------------------------------------------------------------------------
| Shared Resident Navigation
|--------------------------------------------------------------------------
|
| Keep _navbar.php separate.
| Do not paste its contents into this file.
|
*/

require_once __DIR__ . '/_navbar.php';
?>

<main class="container">

    <section class="welcome">
        <h1>My Requests</h1>

        <p>
            Welcome, <?= residentRequestsEscape($firstName) ?>.
            Track the progress of your service requests.
        </p>

        <p class="subtitle">
            <?= residentRequestsEscape($municipalityName) ?>
            &mdash;
            <?= residentRequestsEscape($authorityLabel) ?>
        </p>
    </section>

    <?php if ($errorMessage !== ''): ?>

        <div class="message" role="alert">
            <strong>Unable to load your requests</strong>
            <p><?= residentRequestsEscape($errorMessage) ?></p>
        </div>

        <p>
            If this problem continues, contact your local authority's
            administrator.
        </p>

    <?php else: ?>

        <section
            class="summary"
            aria-label="Your request statistics"
        >

            <div class="summary-card">
                <span>Total Requests</span>
                <strong><?= number_format($totalRequests) ?></strong>
            </div>

            <div class="summary-card">
                <span>Active Requests</span>
                <strong><?= number_format($activeRequests) ?></strong>
            </div>

            <div class="summary-card">
                <span>Action Required</span>
                <strong><?= number_format($actionRequired) ?></strong>
            </div>

            <div class="summary-card">
                <span>Resolved / Closed</span>
                <strong>
                    <?= number_format($resolvedRequests + $closedRequests) ?>
                </strong>
            </div>

        </section>

        <section>

            <div class="section-heading">
                <h2>Your Service Requests</h2>

                <p>
                    Search by reference, subject or service, or filter
                    requests by their current status.
                </p>
            </div>

            <div class="panel">

                <?php if (!$requests): ?>

                    <div class="empty-state">

                        <div class="empty-icon" aria-hidden="true">
                            📋
                        </div>

                        <h3>You haven't submitted any requests yet</h3>

                        <p>
                            Explore the services offered by your local
                            authority and submit a request when you need help.
                        </p>

                        <a href="services.php" class="button">
                            Explore Services
                        </a>

                    </div>

                <?php else: ?>

                    <div class="toolbar">

                        <input
                            type="search"
                            id="requestSearch"
                            placeholder="Search your requests..."
                            aria-label="Search requests"
                        >

                        <select
                            id="statusFilter"
                            aria-label="Filter requests by status"
                        >
                            <option value="">All statuses</option>
                            <option value="submitted">Submitted</option>
                            <option value="under_review">Under Review</option>
                            <option value="assigned">Assigned</option>
                            <option value="in_progress">In Progress</option>
                            <option value="pending_resident">Action Required</option>
                            <option value="resolved">Resolved</option>
                            <option value="closed">Closed</option>
                            <option value="rejected">Rejected</option>
                            <option value="cancelled">Cancelled</option>
                        </select>

                    </div>

                    <div class="table-wrapper">

                        <table>
                            <thead>
                                <tr>
                                    <th>Reference</th>
                                    <th>Request</th>
                                    <th>Date Submitted</th>
                                    <th>Priority</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>

                            <tbody id="requestTableBody">

                            <?php foreach ($requests as $request): ?>

                                <?php
                                $status = strtolower(trim(
                                    (string) ($request['status'] ?? '')
                                ));

                                $reference = (string) (
                                    $request['reference_number'] ?? ''
                                );

                                $subject = trim((string) (
                                    $request['subject'] ?? ''
                                ));

                                $serviceName = trim((string) (
                                    $request['service_name'] ?? ''
                                ));

                                $priority = strtolower(trim((string) (
                                    $request['priority'] ?? 'normal'
                                )));

                                $submittedAt = 'Not available';

                                if (!empty($request['submitted_at'])) {
                                    try {
                                        $submittedAt = (
                                            new DateTimeImmutable(
                                                (string) $request['submitted_at']
                                            )
                                        )->format('d M Y');
                                    } catch (Exception $e) {
                                        $submittedAt = 'Not available';
                                    }
                                }

                                $searchText = strtolower(implode(' ', [
                                    $reference,
                                    $subject,
                                    $serviceName,
                                    $status,
                                    $priority,
                                ]));
                                ?>

                                <tr
                                    class="request-row"
                                    data-search="<?= residentRequestsEscape($searchText) ?>"
                                    data-status="<?= residentRequestsEscape($status) ?>"
                                >

                                    <td>
                                        <span class="reference">
                                            <?= residentRequestsEscape($reference) ?>
                                        </span>
                                    </td>

                                    <td>
                                        <div class="request-subject">
                                            <?= residentRequestsEscape(
                                                $subject !== ''
                                                    ? $subject
                                                    : 'Service request'
                                            ) ?>
                                        </div>

                                        <div class="request-service">
                                            <?= residentRequestsEscape(
                                                $serviceName !== ''
                                                    ? $serviceName
                                                    : 'Service information unavailable'
                                            ) ?>
                                        </div>
                                    </td>

                                    <td>
                                        <?= residentRequestsEscape($submittedAt) ?>
                                    </td>

                                    <td>
                                        <span class="priority priority-<?= residentRequestsEscape(
                                            in_array(
                                                $priority,
                                                ['low', 'normal', 'high', 'urgent'],
                                                true
                                            ) ? $priority : 'normal'
                                        ) ?>">
                                            <?= residentRequestsEscape(
                                                ucfirst($priority)
                                            ) ?>
                                        </span>
                                    </td>

                                    <td>
                                        <span class="status <?= residentRequestStatusClass($status) ?>">
                                            <?= residentRequestsEscape(
                                                residentRequestStatusLabel($status)
                                            ) ?>
                                        </span>
                                    </td>

                                    <td>
                                        <a
                                            class="button button-secondary"
                                            href="request.php?id=<?= (int) $request['id'] ?>"
                                        >
                                            View Details
                                        </a>
                                    </td>

                                </tr>

                            <?php endforeach; ?>

                            </tbody>
                        </table>

                    </div>

                    <div
                        class="empty-state"
                        id="noRequestResults"
                        hidden
                    >
                        <h3>No matching requests</h3>

                        <p>
                            Try another search term or select a different status.
                        </p>

                    </div>

                    <div class="results-count">
                        Showing
                        <strong id="visibleRequestCount">
                            <?= number_format($totalRequests) ?>
                        </strong>
                        of
                        <?= number_format($totalRequests) ?>
                        request(s)
                    </div>

                <?php endif; ?>

            </div>

        </section>

    <?php endif; ?>

</main>

<footer class="footer">
    TownLink Resident Portal &copy; <?= date('Y') ?>
</footer>

<script>
(function () {
    'use strict';

    const searchInput = document.getElementById('requestSearch');
    const statusFilter = document.getElementById('statusFilter');

    const rows = Array.from(
        document.querySelectorAll('.request-row')
    );

    const noResults = document.getElementById('noRequestResults');
    const visibleCount = document.getElementById('visibleRequestCount');

    function filterRequests() {
        if (!searchInput || !statusFilter) {
            return;
        }

        const query = searchInput.value.trim().toLowerCase();
        const selectedStatus = statusFilter.value.toLowerCase();

        let count = 0;

        rows.forEach(function (row) {
            const searchText = row.dataset.search || '';
            const status = row.dataset.status || '';

            const matchesSearch = searchText.includes(query);

            const matchesStatus =
                selectedStatus === '' ||
                status === selectedStatus;

            const visible = matchesSearch && matchesStatus;

            row.hidden = !visible;

            if (visible) {
                count++;
            }
        });

        if (noResults) {
            noResults.hidden = count !== 0;
        }

        if (visibleCount) {
            visibleCount.textContent = count.toLocaleString();
        }
    }

    if (searchInput && statusFilter) {
        searchInput.addEventListener('input', filterRequests);
        statusFilter.addEventListener('change', filterRequests);
    }
})();
</script>

</body>
</html>