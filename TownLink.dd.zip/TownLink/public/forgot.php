<?php
declare(strict_types=1);

session_start();

require_once __DIR__ . '/app/config/database.php';
require_once __DIR__ . '/app/config/mail.php';
require_once __DIR__ . '/vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;

function e($value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim((string)($_POST['email'] ?? ''));
    $csrf = (string)($_POST['csrf_token'] ?? '');

    if (!hash_equals($_SESSION['csrf_token'], $csrf)) {
        $error = 'Your session expired. Please refresh and try again.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } else {
        // Always use a generic response to avoid revealing registered emails.
        $message = 'If an account matches that email, a password reset link will be sent shortly. Check your inbox and spam folder.';

        try {
            $stmt = $pdo->prepare(
                "SELECT id, first_name, email
                 FROM users
                 WHERE email = :email
                   AND status = 'active'
                 LIMIT 1"
            );

            $stmt->execute([':email' => $email]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($user) {
                // Invalidate older reset links for this account.
                $delete = $pdo->prepare(
                    'DELETE FROM password_resets WHERE user_id = :user_id'
                );
                $delete->execute([':user_id' => $user['id']]);

                // The raw token is emailed; only its SHA-256 hash is stored.
                $token = bin2hex(random_bytes(32));
                $tokenHash = hash('sha256', $token);

                $insert = $pdo->prepare(
                    'INSERT INTO password_resets
                        (user_id, token_hash, expires_at)
                     VALUES
                        (:user_id, :token_hash, DATE_ADD(NOW(), INTERVAL 15 MINUTE))'
                );

                $insert->execute([
                    ':user_id' => $user['id'],
                    ':token_hash' => $tokenHash
                ]);

                $resetUrl = TOWNLINK_BASE_URL
                    . '/reset-password.php?token='
                    . urlencode($token);

                try {
                    $mail = new PHPMailer(true);
                    $mail->isSMTP();
                    $mail->Host = TOWNLINK_SMTP_HOST;
                    $mail->SMTPAuth = true;
                    $mail->Username = TOWNLINK_SMTP_USERNAME;
                    $mail->Password = TOWNLINK_SMTP_PASSWORD;
                    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                    $mail->Port = TOWNLINK_SMTP_PORT;

                    $mail->CharSet = 'UTF-8';
                    $mail->setFrom(
                        TOWNLINK_MAIL_FROM,
                        TOWNLINK_MAIL_FROM_NAME
                    );
                    $mail->addAddress($user['email'], $user['first_name']);
                    $mail->isHTML(true);
                    $mail->Subject = 'Reset your TownLink password';

                    $safeName = e($user['first_name']);
                    $safeUrl = e($resetUrl);

                    $mail->Body = "
                        <div style='font-family:Arial,sans-serif;max-width:560px;margin:auto;padding:28px;color:#183b30'>
                            <h2 style='color:#176b52'>TownLink Namibia</h2>
                            <h3>Password reset request</h3>
                            <p>Hello {$safeName},</p>
                            <p>We received a request to reset your TownLink password.</p>
                            <p style='margin:28px 0'>
                                <a href='{$safeUrl}'
                                   style='background:#176b52;color:#fff;padding:14px 22px;text-decoration:none;border-radius:8px;display:inline-block'>
                                    Reset my password
                                </a>
                            </p>
                            <p>This link expires in 15 minutes and can only be used once.</p>
                            <p>If you did not request this, you can ignore this email.</p>
                            <hr>
                            <small>TownLink Namibia — Municipal services, connected.</small>
                        </div>
                    ";

                    $mail->AltBody =
                        "Hello {$user['first_name']},\n\n"
                        . "Reset your TownLink password using this link:\n"
                        . $resetUrl . "\n\n"
                        . "This link expires in 15 minutes and can only be used once.";

                    $mail->send();
                } catch (Throwable $mailError) {
                    // Do not expose SMTP credentials or details to users.
                    error_log('TownLink reset email error: ' . $mailError->getMessage());

                    // Remove the unusable token if delivery failed.
                    $delete = $pdo->prepare(
                        'DELETE FROM password_resets WHERE token_hash = :token_hash'
                    );
                    $delete->execute([':token_hash' => $tokenHash]);
                }
            }
        } catch (PDOException $exception) {
            error_log('TownLink forgot-password error: ' . $exception->getMessage());

            // Keep the public response generic.
            $message = 'If an account matches that email, a password reset link will be sent shortly. Check your inbox and spam folder.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Forgot Password | TownLink</title>
<style>
:root{--green:#176b52;--dark:#123b32;--muted:#718078;--line:#e1e9e5}
*{box-sizing:border-box}
body{margin:0;background:#f3f7f5;color:#20332b;font-family:Segoe UI,Arial,sans-serif;min-height:100vh;display:grid;place-items:center;padding:22px}
.card{width:100%;max-width:440px;background:#fff;border:1px solid var(--line);border-radius:20px;padding:36px;box-shadow:0 16px 50px #123b3210}
.brand{font-size:23px;font-weight:800;color:var(--dark);margin-bottom:30px}
.brand span{color:var(--green)}
.icon{width:56px;height:56px;border-radius:16px;background:#e8f5ef;color:var(--green);display:grid;place-items:center;font-size:27px;margin-bottom:22px}
h1{font-size:28px;margin:0 0 10px;color:var(--dark)}
p{color:var(--muted);line-height:1.65}
label{display:block;font-weight:700;font-size:14px;margin:22px 0 8px}
input{width:100%;height:48px;border:1px solid #d5dfd9;border-radius:9px;padding:0 13px;font-size:15px}
input:focus{outline:3px solid #176b5220;border-color:var(--green)}
button{width:100%;height:49px;border:0;border-radius:9px;background:var(--green);color:#fff;font-weight:700;font-size:15px;margin-top:18px;cursor:pointer}
button:hover{background:var(--dark)}
.notice{padding:13px;border-radius:9px;background:#eaf6ef;color:#176b52;line-height:1.6;font-size:14px}
.error{background:#fff0ef;color:#a62f29}
.back{display:block;text-align:center;margin-top:24px;color:var(--green);font-weight:700;text-decoration:none}
small{display:block;text-align:center;color:var(--muted);margin-top:28px}
</style>
</head>
<body>
<main class="card">
    <div class="brand">Town<span>Link</span></div>
    <div class="icon" aria-hidden="true">&#9993;</div>
    <h1>Forgot password?</h1>
    <p>It happens. Enter the email address linked to your TownLink account and we'll send you a reset link.</p>

    <?php if ($message !== ''): ?>
        <div class="notice" role="status"><?= e($message) ?></div>
    <?php endif; ?>

    <?php if ($error !== ''): ?>
        <div class="notice error" role="alert"><?= e($error) ?></div>
    <?php endif; ?>

    <form method="post">
        <input type="hidden" name="csrf_token" value="<?= e($_SESSION['csrf_token']) ?>">

        <label for="email">Email address</label>
        <input type="email" id="email" name="email"
               placeholder="you@example.com" maxlength="150"
               autocomplete="email" required>

        <button type="submit">Send reset link</button>
    </form>

    <a class="back" href="login.php">← Back to login</a>
    <small>&copy; <?= date('Y') ?> TownLink Namibia</small>
</main>
</body>
</html>