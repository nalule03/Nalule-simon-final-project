TownLink Request Evidence Storage

This folder stores pictures uploaded by residents as evidence for municipal service requests.

Supported uploads should be validated by the PHP application before being saved.

Security requirements:

Accept only approved image formats.
Verify file types and file sizes.
Generate unique filenames for uploaded files.
Do not allow executable PHP files.
Store file paths and attachment details in the request_attachments database table.

Uploaded evidence is associated with a service request and its resident.