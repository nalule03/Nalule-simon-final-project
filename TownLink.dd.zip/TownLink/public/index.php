<?php
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

require_once __DIR__ . '/../app/config/database.php';

/*
|--------------------------------------------------------------------------
| TownLink Public Homepage
|--------------------------------------------------------------------------
| Public users can browse:
| - Municipalities
| - Services
| - Departments
| - Announcements
|
| Login is only required when the user wants to communicate
| with a municipality or submit a private request.
|--------------------------------------------------------------------------
*/

$municipalities = [];
$services = [];
$announcements = [];
$departments = [];

try {
    /*
    |--------------------------------------------------------------------------
    | Municipalities
    |--------------------------------------------------------------------------
    */
    $stmt = $pdo->query("
        SELECT id, municipality_name
        FROM municipalities
        WHERE status = 'active'
        ORDER BY municipality_name ASC
    ");

    $municipalities = $stmt->fetchAll(PDO::FETCH_ASSOC);

    /*
    |--------------------------------------------------------------------------
    | Public Services
    |--------------------------------------------------------------------------
    |
    | Adjust column names later if your current services table differs.
    |--------------------------------------------------------------------------
    */
    $stmt = $pdo->query("
        SELECT
            s.id,
            s.service_name,
            s.description,
            s.municipality_id,
            m.municipality_name
        FROM services s
        INNER JOIN municipalities m
            ON m.id = s.municipality_id
        WHERE m.status = 'active'
        AND (s.status = 'active' OR s.status = 'published')
        ORDER BY s.service_name ASC
        LIMIT 8
    ");

    $services = $stmt->fetchAll(PDO::FETCH_ASSOC);

    /*
    |--------------------------------------------------------------------------
    | Public Announcements
    |--------------------------------------------------------------------------
    */
    $stmt = $pdo->query("
        SELECT
            a.id,
            a.title,
            a.content,
            a.created_at,
            a.municipality_id,
            m.municipality_name
        FROM announcements a
        LEFT JOIN municipalities m
            ON m.id = a.municipality_id
        WHERE a.status = 'published'
        ORDER BY a.created_at DESC
        LIMIT 3
    ");

    $announcements = $stmt->fetchAll(PDO::FETCH_ASSOC);

    /*
    |--------------------------------------------------------------------------
    | Departments
    |--------------------------------------------------------------------------
    */
    $stmt = $pdo->query("
        SELECT
            d.id,
            d.department_name,
            d.description,
            d.municipality_id,
            m.municipality_name
        FROM departments d
        INNER JOIN municipalities m
            ON m.id = d.municipality_id
        WHERE m.status = 'active'
        AND (d.status = 'active' OR d.status = 'published')
        ORDER BY d.department_name ASC
        LIMIT 6
    ");

    $departments = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    /*
    |--------------------------------------------------------------------------
    | Do not expose database errors to public users.
    |--------------------------------------------------------------------------
    */
    $municipalities = [];
    $services = [];
    $announcements = [];
    $departments = [];
}

$isLoggedIn = isset($_SESSION['user_id']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <meta
        name="description"
        content="TownLink Namibia connects residents with municipalities, local services, departments and official community information."
    >

    <title>TownLink Namibia | Connect With Your Municipality</title>

    <!-- Bootstrap -->
    <link
        rel="stylesheet"
        href="../assets/vendor/bootstrap/css/bootstrap.min.css"
    >

    <!-- Bootstrap Icons -->
    <link
        rel="stylesheet"
        href="../assets/vendor/bootstrap-icons/bootstrap-icons.css"
    >

   
<style>
    :root {
        --townlink-primary: #176b52;
        --townlink-dark: #123b32;
        --townlink-light: #e8f5ef;
        --townlink-green: #176b52;
        --townlink-text: #182b25;

        --townlink-background: #f4f7f6;
        --townlink-surface: #ffffff;
        --townlink-muted: #718078;
        --townlink-border: #e1e9e5;

        --townlink-radius: 16px;
        --townlink-shadow: 0 5px 22px rgba(20, 55, 43, 0.055);
    }

    * {
        box-sizing: border-box;
    }

    body {
        margin: 0;
        font-family: "Segoe UI", Arial, Helvetica, sans-serif;
        color: var(--townlink-text);
        background: #ffffff;
        font-size: 15px;
        line-height: 1.6;
    }

    a {
        color: inherit;
        text-decoration: none;
    }

    button,
    input,
    select,
    textarea {
        font: inherit;
    }

    /*
    |--------------------------------------------------------------------------
    | Navbar
    |--------------------------------------------------------------------------
    */
    /* Professional TownLink navigation */

.townlink-navbar {
    min-height: 78px;
    background: #ffffff;
    border-bottom: 1px solid #e1e9e5;
    box-shadow: 0 3px 16px rgba(18, 59, 50, 0.045);
}

.townlink-brand {
    display: inline-flex;
    align-items: center;
    gap: 10px;
    margin-right: 24px;
}

.brand-icon {
    width: 42px;
    height: 42px;
    display: grid;
    place-items: center;
    border-radius: 12px;
    background: #e8f5ef;
    color: #176b52;
    font-size: 22px;
}

.brand-name {
    color: #123b32;
    font-size: 1.4rem;
    font-weight: 800;
    letter-spacing: -0.6px;
}

.brand-name span {
    color: #176b52;
}

.townlink-nav {
    gap: 3px;
}

.townlink-nav .nav-link {
    padding: 10px 12px !important;
    border-radius: 8px;
    color: #43534b !important;
    font-size: 14px;
    font-weight: 600;
    white-space: nowrap;
    transition: background .2s ease, color .2s ease;
}

.townlink-nav .nav-link:hover,
.townlink-nav .nav-link:focus {
    background: #e8f5ef;
    color: #176b52 !important;
}

.townlink-nav-actions {
    display: flex;
    align-items: center;
    gap: 16px;
}

.townlink-search {
    width: 205px;
    height: 40px;
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 0 9px 0 12px;
    border: 1px solid #e1e9e5;
    border-radius: 10px;
    background: #f8faf9;
}

.townlink-search > i {
    color: #718078;
    flex-shrink: 0;
}

.townlink-search .form-control {
    min-width: 0;
    height: 36px;
    padding: 0;
    border: 0;
    outline: 0;
    background: transparent;
    box-shadow: none;
    font-size: 12px;
}

.townlink-search button {
    display: grid;
    place-items: center;
    flex-shrink: 0;
    width: 27px;
    height: 27px;
    border: 0;
    border-radius: 7px;
    background: #e8f5ef;
    color: #176b52;
}

.townlink-search button:hover {
    background: #176b52;
    color: #ffffff;
}

.townlink-login {
    color: #123b32;
    font-size: 14px;
    font-weight: 700;
    white-space: nowrap;
}

.townlink-login:hover {
    color: #176b52;
}

.townlink-account-btn {
    display: inline-flex;
    justify-content: center;
    align-items: center;
    gap: 5px;
    min-height: 40px;
    padding: 9px 14px;
    border: 1px solid #176b52;
    border-radius: 9px;
    background: #176b52;
    color: #ffffff;
    font-size: 13px;
    font-weight: 700;
    white-space: nowrap;
}

.townlink-account-btn:hover {
    border-color: #123b32;
    background: #123b32;
    color: #ffffff;
}

@media (max-width: 1199.98px) {
    .townlink-nav-actions {
        gap: 10px;
    }

    .townlink-search {
        width: 170px;
    }

    .townlink-nav .nav-link {
        padding-right: 9px !important;
        padding-left: 9px !important;
    }
}

@media (max-width: 991.98px) {
    .townlink-navbar .navbar-collapse {
        padding: 18px 0 8px;
    }

    .townlink-nav {
        align-items: stretch !important;
        margin: 0 0 15px;
    }

    .townlink-nav .nav-link {
        padding: 11px 12px !important;
    }

    .townlink-nav-actions {
        align-items: stretch;
        flex-wrap: wrap;
        gap: 12px;
    }

    .townlink-search {
        width: 100%;
        margin-bottom: 3px;
    }

    .townlink-login {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        padding: 10px;
    }
}

@media (max-width: 420px) {
    .townlink-nav-actions {
        display: grid;
        grid-template-columns: 1fr 1fr;
    }

    .townlink-search {
        grid-column: 1 / -1;
    }

    .townlink-account-btn {
        width: 100%;
    }
}

    .navbar {
        background: var(--townlink-surface);
        box-shadow: 0 2px 12px rgba(20, 55, 43, 0.06);
        padding-top: 14px;
        padding-bottom: 14px;
    }

    .navbar-brand {
        font-size: 1.45rem;
        font-weight: 800;
        letter-spacing: -0.5px;
        color: var(--townlink-dark) !important;
    }

    .navbar-brand span {
        color: var(--townlink-primary);
    }

    .nav-link {
        font-weight: 600;
        color: #394b43 !important;
        margin: 0 4px;
        transition: color 0.2s ease;
    }

    .nav-link:hover,
    .nav-link:focus {
        color: var(--townlink-primary) !important;
    }

    .navbar-toggler {
        border-color: var(--townlink-border);
        border-radius: 9px;
    }

    .navbar-toggler:focus {
        box-shadow: 0 0 0 0.2rem rgba(23, 107, 82, 0.15);
    }

    /*
    |--------------------------------------------------------------------------
    | Hero
    |--------------------------------------------------------------------------
    */

.hero {
    min-height: 600px;
    width: 100%;
    position: relative;
    display: flex;
    align-items: center;

    background:
        linear-gradient(
            rgba(18, 59, 50, 0.45),
            rgba(18, 59, 50, 0.45)
        ),
        url("nampc.jpg");

    background-size: contain;
    background-position: cover;
    background-repeat: repeat;
    background-color: #123b32;
}

    .hero-content {
        max-width: 760px;
        color: #ffffff;
    }

    .hero-badge {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        background: rgba(255, 255, 255, 0.12);
        border: 1px solid rgba(255, 255, 255, 0.24);
        padding: 8px 15px;
        border-radius: 30px;
        margin-bottom: 20px;
        font-size: 0.9rem;
    }

    .hero h1 {
        font-size: clamp(2.5rem, 5vw, 4.4rem);
        line-height: 1.08;
        font-weight: 800;
        letter-spacing: -1px;
        margin-bottom: 22px;
    }

    .hero h1 span {
        color: #b8e5d0;
    }

    .hero p {
        font-size: 1.15rem;
        line-height: 1.7;
        color: rgba(255, 255, 255, 0.88);
        max-width: 680px;
    }

    .hero-buttons {
        display: flex;
        gap: 12px;
        flex-wrap: wrap;
        margin-top: 30px;
    }

    .btn-townlink {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        background: var(--townlink-primary);
        border: 1px solid var(--townlink-primary);
        color: #ffffff;
        padding: 12px 23px;
        border-radius: 9px;
        font-weight: 700;
        transition: background 0.2s ease,
                    border-color 0.2s ease,
                    transform 0.2s ease;
    }

    .btn-townlink:hover,
    .btn-townlink:focus {
        background: #0f543f;
        border-color: #0f543f;
        color: #ffffff;
        transform: translateY(-1px);
    }

    .btn-outline-light-custom {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        border: 1px solid rgba(255, 255, 255, 0.65);
        background: transparent;
        color: #ffffff;
        padding: 12px 23px;
        border-radius: 9px;
        font-weight: 700;
        transition: background 0.2s ease,
                    color 0.2s ease;
    }

    .btn-outline-light-custom:hover,
    .btn-outline-light-custom:focus {
        background: #ffffff;
        color: var(--townlink-dark);
    }

    /*
    |--------------------------------------------------------------------------
    | Municipality Selector
    |--------------------------------------------------------------------------
    */

    .municipality-box {
        margin-top: -45px;
        position: relative;
        z-index: 10;
    }

    .municipality-card {
        background: var(--townlink-surface);
        border: 1px solid var(--townlink-border);
        border-radius: var(--townlink-radius);
        box-shadow: 0 8px 28px rgba(20, 55, 43, 0.08);
        padding: 25px;
    }

    .municipality-card h3,
    .municipality-card h4,
    .municipality-card h5 {
        color: var(--townlink-dark);
        font-weight: 700;
    }

    .municipality-card input,
    .municipality-card select {
        border-color: var(--townlink-border);
        border-radius: 9px;
        min-height: 44px;
    }

    .municipality-card input:focus,
    .municipality-card select:focus {
        border-color: var(--townlink-primary);
        box-shadow: 0 0 0 0.2rem rgba(23, 107, 82, 0.12);
    }

    /*
    |--------------------------------------------------------------------------
    | Sections
    |--------------------------------------------------------------------------
    */

    .section {
        padding: 85px 0;
    }

    .section-light {
        background: var(--townlink-background);
        image-rendering: auto;
    }

    .section-title {
        font-weight: 800;
        color: var(--townlink-dark);
        margin-bottom: 10px;
        letter-spacing: -0.5px;
    }

    .section-subtitle {
        color: var(--townlink-muted);
        max-width: 700px;
        margin: auto;
        line-height: 1.7;
    }

    /*
    |--------------------------------------------------------------------------
    | Cards
    |--------------------------------------------------------------------------
    */

    .feature-card,
    .service-card,
    .department-card,
    .announcement-card {
        background: var(--townlink-surface);
        border: 1px solid var(--townlink-border);
        border-radius: var(--townlink-radius);
        height: 100%;
        overflow: hidden;
        transition: border-color 0.2s ease,
                    transform 0.2s ease,
                    box-shadow 0.2s ease;
    }

    .feature-card:hover,
    .service-card:hover,
    .department-card:hover,
    .announcement-card:hover {
        border-color: #b7d7c8;
        transform: translateY(-3px);
        box-shadow: var(--townlink-shadow);
    }

    .card-body {
        padding: 25px;
    }

    .icon-box {
        width: 55px;
        height: 55px;
        border-radius: 14px;
        display: flex;
        align-items: center;
        justify-content: center;
        background: var(--townlink-light);
        color: var(--townlink-dark);
        font-size: 1.5rem;
        margin-bottom: 18px;
    }

    .service-card h5,
    .department-card h5,
    .announcement-card h5 {
        font-weight: 700;
        color: var(--townlink-dark);
        margin-bottom: 10px;
    }

    .service-card p,
    .department-card p,
    .announcement-card p {
        color: var(--townlink-muted);
        line-height: 1.7;
    }

    .feature-card a,
    .service-card a,
    .department-card a,
    .announcement-card a {
        color: var(--townlink-primary);
        font-weight: 700;
    }

    .feature-card a:hover,
    .service-card a:hover,
    .department-card a:hover,
    .announcement-card a:hover {
        color: var(--townlink-dark);
    }

    /*
    |--------------------------------------------------------------------------
    | Stats
    |--------------------------------------------------------------------------
    */

    .stats-section {
        background: var(--townlink-dark);
        color: #ffffff;
        padding: 55px 0;
    }

    .stat-number {
        font-size: 2.4rem;
        font-weight: 800;
        line-height: 1.3;
    }

    .stat-label {
        color: rgba(255, 255, 255, 0.72);
    }

    /*
    |--------------------------------------------------------------------------
    | How It Works
    |--------------------------------------------------------------------------
    */

    .step-number {
        width: 48px;
        height: 48px;
        border-radius: 14px;
        background: var(--townlink-light);
        color: var(--townlink-dark);
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 800;
        margin-bottom: 15px;
    }

    /*
    |--------------------------------------------------------------------------
    | Call to Action
    |--------------------------------------------------------------------------
    */

    .cta-section {
        background: linear-gradient(
            135deg,
            #123b32,
            #176b52
        );
        color: #ffffff;
        padding: 75px 0;
    }

    .cta-section h2,
    .cta-section h3 {
        color: #ffffff;
        font-weight: 800;
    }

    .cta-section p {
        color: rgba(255, 255, 255, 0.82);
    }

    /*
    |--------------------------------------------------------------------------
    | Footer
    |--------------------------------------------------------------------------
    */

    footer {
        background: #0c2923;
        color: rgba(255, 255, 255, 0.75);
        padding: 55px 0 25px;
    }

    footer h5 {
        color: #ffffff;
        font-weight: 700;
        margin-bottom: 18px;
    }

    footer a {
        color: rgba(255, 255, 255, 0.72);
        text-decoration: none;
        transition: color 0.2s ease;
    }

    footer a:hover,
    footer a:focus {
        color: #b8e5d0;
    }

    .footer-bottom {
        border-top: 1px solid rgba(255, 255, 255, 0.12);
        margin-top: 35px;
        padding-top: 20px;
        font-size: 0.9rem;
    }

    /*
    |--------------------------------------------------------------------------
    | Forms and General Controls
    |--------------------------------------------------------------------------
    */

    .form-control,
    .form-select {
        border-color: var(--townlink-border);
        border-radius: 9px;
    }

    .form-control:focus,
    .form-select:focus {
        border-color: var(--townlink-primary);
        box-shadow: 0 0 0 0.2rem rgba(23, 107, 82, 0.12);
    }

    .text-muted {
        color: var(--townlink-muted) !important;
    }

    /*
    |--------------------------------------------------------------------------
    | Accessibility
    |--------------------------------------------------------------------------
    */

    a:focus-visible,
    button:focus-visible {
        outline: 3px solid #8ccfb1;
        outline-offset: 3px;
    }

    /*
    |--------------------------------------------------------------------------
    | Mobile
    |--------------------------------------------------------------------------
    */

    @media (max-width: 768px) {
        .hero {
            min-height: 570px;
        }

        .hero h1 {
            font-size: 2.5rem;
        }

        .hero p {
            font-size: 1rem;
        }

        .municipality-box {
            margin-top: -25px;
        }

        .municipality-card {
            padding: 20px;
        }

        .section {
            padding: 60px 0;
        }

        .card-body {
            padding: 21px;
        }

        .cta-section {
            padding: 55px 0;
        }
    }

    @media (max-width: 480px) {
        .hero h1 {
            font-size: 2.2rem;
        }

        .hero-buttons {
            align-items: stretch;
            flex-direction: column;
        }

        .hero-buttons .btn-townlink,
        .hero-buttons .btn-outline-light-custom {
            width: 100%;
        }

        .stat-number {
            font-size: 2rem;
        }
    }

    @media (prefers-reduced-motion: reduce) {
        *,
        *::before,
        *::after {
            scroll-behavior: auto !important;
            transition: none !important;
            animation: none !important;
        }
    }
</style>

</head>

<body>

<!-- ============================================================
     NAVIGATION
============================================================ -->

<!-- ============================================================
     PROFESSIONAL TOWNLINK NAVBAR
============================================================ -->

<nav class="navbar navbar-expand-lg sticky-top townlink-navbar">
    <div class="container">

        <!-- Brand -->
        <a class="navbar-brand townlink-brand" href="index.php">
            <span class="brand-icon">
                <i class="bi bi-buildings"></i>
            </span>
            <span class="brand-name">Town<span>Link</span></span>
        </a>

        <!-- Mobile toggle -->
        <button
            class="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#mainNavigation"
            aria-controls="mainNavigation"
            aria-expanded="false"
            aria-label="Open navigation"
        >
            <i class="bi bi-list fs-3"></i>
        </button>

        <div class="collapse navbar-collapse" id="mainNavigation">

            <!-- Public navigation -->
            <ul class="navbar-nav mx-lg-auto townlink-nav">

                <li class="nav-item">
                    <a class="nav-link" href="index.php#services">
                        Services
                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="index.php#announcements">
                        Public Notices
                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="index.php#municipalities">
                        Municipalities
                    </a>
                </li>

            </ul>

            <!-- Search and account actions -->
            <div class="townlink-nav-actions">

                <!--
                    This search currently searches the visible homepage
                    cards. It does not require a separate search page.
                -->
                <form
                    class="townlink-search"
                    id="townlinkSearchForm"
                    role="search"
                >
                    <i class="bi bi-search"></i>

                    <input
                        type="search"
                        id="townlinkSearchInput"
                        class="form-control"
                        placeholder="Search TownLink"
                        aria-label="Search services, departments and notices"
                    >

                    <button type="submit" aria-label="Search">
                        <i class="bi bi-arrow-right"></i>
                    </button>
                </form>

                <?php if ($isLoggedIn): ?>

                    <a
                        href="../resident/profile.php"
                        class="btn townlink-account-btn"
                    >
                        <i class="bi bi-person-circle me-1"></i>
                        My profile
                    </a>

                <?php else: ?>

                    <a href="login.php" class="townlink-login">
                        Log in
                    </a>

                    <a
                        href="register.php"
                        class="btn townlink-account-btn"
                    >
                        Create Account
                    </a>

                <?php endif; ?>

            </div>

        </div>
    </div>
</nav>


<!-- ============================================================
     HERO
============================================================ -->

<section class="hero">

    <div class="container">

        <div class="hero-content">

            <div class="hero-badge">
                <i class="bi bi-geo-alt-fill"></i>
                Connecting communities across Namibia
            </div>

            <h1>
                Your community.
                <span>Your municipality.</span>
                One platform.
            </h1>

            <p>
                TownLink makes it easier for residents to discover
                municipal services, find departments, receive official
                information and communicate directly with their municipality.
            </p>

            <div class="hero-buttons">

                <a
                    href="#municipalities"
                    class="btn btn-townlink"
                >
                    <i class="bi bi-building me-2"></i>
                    Find My Municipality
                </a>

                <a
                    href="#services"
                    class="btn btn-outline-light-custom"
                >
                    <i class="bi bi-grid me-2"></i>
                    Explore Services
                </a>

            </div>

        </div>

    </div>

</section>


<!-- ============================================================
     MUNICIPALITY SELECTOR
============================================================ -->

<section
    class="municipality-box"
    id="municipalities"
>

    <div class="container">

        <div class="municipality-card">

            <div class="row align-items-center g-4">

                <div class="col-lg-5">

                    <h4 class="fw-bold mb-2">
                        <i class="bi bi-building me-2 text-primary"></i>
                        Select your municipality
                    </h4>

                    <p class="text-muted mb-0">
                        Explore public information and services
                        available in your municipality.
                    </p>

                </div>

                <div class="col-lg-7">

                    <div class="row g-2">

                        <div class="col-md-8">

                            <select
                                class="form-select form-select-lg"
                                id="municipalitySelect"
                            >

                                <option value="">
                                    Select a municipality
                                </option>

                                <?php foreach ($municipalities as $municipality): ?>

                                    <option
                                        value="<?= (int)$municipality['id'] ?>"
                                    >
                                        <?= htmlspecialchars(
                                            $municipality['municipality_name']
                                        ) ?>
                                    </option>

                                <?php endforeach; ?>

                            </select>

                        </div>

                        <div class="col-md-4">

                            <button
                                type="button"
                                class="btn btn-townlink btn-lg w-100"
                                onclick="selectMunicipality()"
                            >
                                Explore
                            </button>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>

</section>


<!-- ============================================================
     PLATFORM FEATURES
============================================================ -->

<section class="section">

    <div class="container">

        <div class="text-center mb-5">

            <h2 class="section-title">
                Everything you need from your municipality
            </h2>

            <p class="section-subtitle">
                TownLink brings municipal information, services and
                communication together in one convenient platform.
            </p>

        </div>

        <div class="row g-4">

            <div class="col-md-6 col-lg-3">

                <div class="feature-card">

                    <div class="card-body">

                        <div class="icon-box">
                            <i class="bi bi-search"></i>
                        </div>

                        <h5>
                            Discover Services
                        </h5>

                        <p class="mb-0">
                            Find municipal services and information
                            without needing to visit an office first.
                        </p>

                    </div>

                </div>

            </div>


            <div class="col-md-6 col-lg-3">

                <div class="feature-card">

                    <div class="card-body">

                        <div class="icon-box">
                            <i class="bi bi-chat-dots"></i>
                        </div>

                        <h5>
                            Communicate
                        </h5>

                        <p class="mb-0">
                            Communicate directly with your municipality
                            through structured requests and reports.
                        </p>

                    </div>

                </div>

            </div>


            <div class="col-md-6 col-lg-3">

                <div class="feature-card">

                    <div class="card-body">

                        <div class="icon-box">
                            <i class="bi bi-megaphone"></i>
                        </div>

                        <h5>
                            Stay Informed
                        </h5>

                        <p class="mb-0">
                            Access official announcements, notices and
                            important community information.
                        </p>

                    </div>

                </div>

            </div>


            <div class="col-md-6 col-lg-3">

                <div class="feature-card">

                    <div class="card-body">

                        <div class="icon-box">
                            <i class="bi bi-clock-history"></i>
                        </div>

                        <h5>
                            Track Requests
                        </h5>

                        <p class="mb-0">
                            Submit requests and keep track of their
                            progress from your personal account.
                        </p>

                    </div>

                </div>

            </div>

        </div>

    </div>

</section>


<!-- ============================================================
     SERVICES
============================================================ -->

<section
    class="section section-light"
    id="services"
>

    <div class="container">

        <div class="d-flex justify-content-between align-items-end mb-5">

            <div>

                <h2 class="section-title">
                    Municipal Services
                </h2>

                <p class="text-muted mb-0">
                    Explore services available through TownLink.
                </p>

            </div>

            <a
                href="services.php"
                class="btn btn-outline-primary d-none d-md-inline-block"
            >
                View All Services
                <i class="bi bi-arrow-right ms-1"></i>
            </a>

        </div>


        <div class="row g-4">

            <?php if (!empty($services)): ?>

                <?php foreach ($services as $service): ?>

                    <div class="col-md-6 col-lg-3">

                        <div class="service-card">

                            <div class="card-body">

                                <div class="icon-box">
                                    <i class="bi bi-briefcase"></i>
                                </div>

                                <h5>
                                    <?= htmlspecialchars(
                                        $service['service_name']
                                    ) ?>
                                </h5>

                                <p>
                                    <?= htmlspecialchars(
                                        mb_strimwidth(
                                            $service['description'] ?? '',
                                            0,
                                            110,
                                            '...'
                                        )
                                    ) ?>
                                </p>

                                <small class="text-primary fw-semibold">
                                    <i class="bi bi-building me-1"></i>

                                    <?= htmlspecialchars(
                                        $service['municipality_name']
                                    ) ?>
                                </small>

                            </div>

                        </div>

                    </div>

                <?php endforeach; ?>

            <?php else: ?>

                <div class="col-12">

                    <div class="text-center py-5">

                        <i class="bi bi-grid fs-1 text-muted"></i>

                        <h5 class="mt-3">
                            Services will appear here
                        </h5>

                        <p class="text-muted">
                            Municipal services will be displayed
                            once they are published.
                        </p>

                    </div>

                </div>

            <?php endif; ?>

        </div>


        <div class="text-center mt-4 d-md-none">

            <a
                href="services.php"
                class="btn btn-outline-primary"
            >
                View All Services
            </a>

        </div>

    </div>

</section>




<!-- ============================================================
     ANNOUNCEMENTS
============================================================ -->

<section
    class="section section-light"
    id="announcements"
>

    <div class="container">

        <div class="d-flex justify-content-between align-items-end mb-5">

            <div>

                <h2 class="section-title">
                    Latest Announcements
                </h2>

                <p class="text-muted mb-0">
                    Stay updated with official municipal information.
                </p>

            </div>

            <a
                href="announcements.php"
                class="btn btn-outline-primary d-none d-md-inline-block"
            >
                Browse All Updates
                <i class="bi bi-arrow-right ms-1"></i>
            </a>

        </div>


        <div class="row g-4">

            <?php if (!empty($announcements)): ?>

                <?php foreach ($announcements as $announcement): ?>

                    <div class="col-md-6 col-lg-4">

                        <div class="announcement-card">

                            <div class="card-body">

                                <div class="d-flex justify-content-between mb-3">

                                    <span class="badge bg-primary">
                                        Official
                                    </span>

                                    <small class="text-muted">
                                        <?= date(
                                            'd M Y',
                                            strtotime(
                                                $announcement['created_at']
                                            )
                                        ) ?>
                                    </small>

                                </div>

                                <h5>
                                    <?= htmlspecialchars(
                                        $announcement['title']
                                    ) ?>
                                </h5>

                                <p>
                                    <?= htmlspecialchars(
                                        mb_strimwidth(
                                            strip_tags(
                                                $announcement['content'] ?? ''
                                            ),
                                            0,
                                            160,
                                            '...'
                                        )
                                    ) ?>
                                </p>

                                <?php if (!empty(
                                    $announcement['municipality_name']
                                )): ?>

                                    <small class="text-primary fw-semibold">

                                        <i class="bi bi-building me-1"></i>

                                        <?= htmlspecialchars(
                                            $announcement['municipality_name']
                                        ) ?>

                                    </small>

                                <?php else: ?>

                                    <small class="text-success fw-semibold">

                                        <i class="bi bi-globe me-1"></i>

                                        National Announcement

                                    </small>

                                <?php endif; ?>

                            </div>

                        </div>

                    </div>

                <?php endforeach; ?>

            <?php else: ?>

                <div class="col-12 text-center py-4">

                    <i class="bi bi-megaphone fs-1 text-muted"></i>

                    <p class="text-muted mt-3">
                        No announcements are currently available.
                    </p>

                </div>

            <?php endif; ?>

        </div>

    </div>

</section>


<!-- ============================================================
     HOW IT WORKS
============================================================ -->

<section
    class="section"
    id="how-it-works"
>

    <div class="container">

        <div class="text-center mb-5">

            <h2 class="section-title">
                How TownLink Works
            </h2>

            <p class="section-subtitle">
                Access information publicly. Sign in when you need
                direct communication with your municipality.
            </p>

        </div>


        <div class="row g-5">

            <div class="col-md-4">

                <div class="step-number">
                    1
                </div>

                <h5 class="fw-bold">
                    Choose your municipality
                </h5>

                <p class="text-muted">
                    Select your municipality to discover its public
                    services, departments and official information.
                </p>

            </div>


            <div class="col-md-4">

                <div class="step-number">
                    2
                </div>

                <h5 class="fw-bold">
                    Explore information
                </h5>

                <p class="text-muted">
                    Browse services, announcements and municipal
                    departments without needing an account.
                </p>

            </div>


            <div class="col-md-4">

                <div class="step-number">
                    3
                </div>

                <h5 class="fw-bold">
                    Connect when needed
                </h5>

                <p class="text-muted">
                    Register or log in when you need to submit a request,
                    report an issue or communicate with your municipality.
                </p>

            </div>

        </div>

    </div>

</section>


<!-- ============================================================
     CALL TO ACTION
============================================================ -->

<section class="cta-section">

    <div class="container text-center">

        <div class="mx-auto" style="max-width: 750px;">

            <h2 class="fw-bold mb-3">
                Need to contact your municipality?
            </h2>

            <p class="lead mb-4">
                Create your TownLink account and communicate with
                your municipality through one secure platform.
            </p>

            <?php if ($isLoggedIn): ?>

                <a
                    href="./index.php"
                    class="btn btn-light btn-lg px-4"
                >
                    <i class="bi bi-speedometer2 me-2"></i>
                    Go to My Dashboard
                </a>

            <?php else: ?>

                <a
                    href="../register.php"
                    class="btn btn-light btn-lg px-4 me-2"
                >
                    <i class="bi bi-person-plus me-2"></i>
                    Create Account
                </a>

                <a
                    href="../login.php"
                    class="btn btn-outline-light btn-lg px-4"
                >
                    Login
                </a>

            <?php endif; ?>

        </div>

    </div>

</section>


<!-- ============================================================
     FOOTER
============================================================ -->

<footer>

    <div class="container">

        <div class="row g-5">

            <div class="col-lg-4">

                <h5>
                    TownLink
                </h5>

                <p>
                    A digital platform connecting communities,
                    residents and municipalities across Namibia.
                </p>

            </div>


            <div class="col-6 col-lg-2">

                <h5>
                    Explore
                </h5>

                <ul class="list-unstyled">

                    <li class="mb-2">
                        <a href="../resident/services.php">
                            Services
                        </a>
                    </li>

                    <li class="mb-2">
                        <a href="#departments">
                            Departments
                        </a>
                    </li>

                    <li class="mb-2">
                        <a href="login.php">
                            Announcements
                        </a>
                    </li>

                </ul>

            </div>


            <div class="col-6 col-lg-3">

                <h5>
                    Account
                </h5>

                <ul class="list-unstyled">

                    <li class="mb-2">
                        <a href="./login.php">
                            Login
                        </a>
                    </li>

                    <li class="mb-2">
                        <a href="./register.php">
                            Register
                        </a>
                    </li>

                    <li class="mb-2">
                        <a href="./register.php">
                            Forgot password
                        </a>
                    </li>

                </ul>

            </div>


            <div class="col-lg-3">

                <h5>
                    TownLink Namibia
                </h5>

                <p class="mb-2">
                    <i class="bi bi-globe2 me-2"></i>
                    Connecting communities digitally
                </p>

                <p>
                    <i class="bi bi-shield-check me-2"></i>
                    Secure municipal communication
                </p>

            </div>

        </div>


        <div class="footer-bottom text-center">

            &copy; <?= date('Y') ?> TownLink Namibia.
            All rights reserved.

        </div>

    </div>

</footer>


<!-- ============================================================
     BOOTSTRAP JAVASCRIPT
============================================================ -->

<script src="../assets/vendor/bootstrap/js/bootstrap.bundle.min.js">
</script>


<script>

/*
|--------------------------------------------------------------------------
| Municipality Selection
|--------------------------------------------------------------------------
|
| This currently stores the selected municipality in the URL.
| The public services/announcements pages can later use this
| value for filtering.
|
| IMPORTANT:
| This selection is for public browsing only.
| It does NOT change the municipality authorized for a logged-in user.
|--------------------------------------------------------------------------
*/


document.getElementById('townlinkSearchForm')
    ?.addEventListener('submit', function (event) {

        event.preventDefault();

        const input = document.getElementById('townlinkSearchInput');
        const query = input.value.trim().toLowerCase();

        if (!query) {
            input.focus();
            return;
        }

        const sections = [
            document.getElementById('services'),
            document.getElementById('departments'),
            document.getElementById('announcements')
        ];

        let firstMatch = null;

        sections.forEach(section => {
            if (!section) return;

            section.querySelectorAll(
                '.service-card, .department-card, .announcement-card'
            ).forEach(card => {

                const matches = card.textContent
                    .toLowerCase()
                    .includes(query);

                card.style.display = matches ? '' : 'none';

                if (matches && !firstMatch) {
                    firstMatch = card;
                }
            });
        });

        if (firstMatch) {
            firstMatch.scrollIntoView({
                behavior: 'smooth',
                block: 'center'
            });
        } else {
            alert(
                'No matching services, departments or notices were found on this page.'
            );
        }
    });


/*
|--------------------------------------------------------------------------
| MUNICIPALITY SELECTION
|--------------------------------------------------------------------------
*/

function selectMunicipality() {

    const select = document.getElementById('municipalitySelect');
    const municipalityId = select.value;

    if (!municipalityId) {
        alert('Please select a municipality first.');
        return;
    }

    window.location.href =
        'services.php?municipality_id=' +
        encodeURIComponent(municipalityId);
}

</script>

</body>
</html>
```