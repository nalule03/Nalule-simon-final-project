<?php

declare(strict_types=1);

require_once __DIR__ . '/../includes/_auth.php';

requireSystemAdmin();

$municipalityId = filter_input(
    INPUT_GET,
    'municipality_id',
    FILTER_VALIDATE_INT
);

if (
    !$municipalityId ||
    $municipalityId <= 0
) {

    http_response_code(400);

    exit(
        'Invalid municipality ID.'
    );
}

try {

    $stmt = $pdo->prepare("
        SELECT
            id,
            name,
            code,
            status
        FROM municipalities
        WHERE id = :id
        LIMIT 1
    ");

    $stmt->execute([
        ':id' => $municipalityId
    ]);

    $municipality =
        $stmt->fetch(
            PDO::FETCH_ASSOC
        );

    if (!$municipality) {

        http_response_code(404);

        exit(
            'Municipality not found.'
        );
    }

} catch (PDOException $e) {

    error_log(
        'Load municipality admin form error: ' .
        $e->getMessage()
    );

    http_response_code(500);

    exit(
        'Unable to load municipality.'
    );
}

?>

<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Create Municipality Admin | TownLink
    </title>

</head>

<body>

<header>

    <h1>
        Create Municipality Administrator
    </h1>

    <p>

        Municipality:

        <strong>
            <?= e(
                $municipality['name']
            ) ?>
        </strong>

    </p>

</header>

<nav>

    <a href="index.php">
        Municipalities
    </a>

    |

    <a href="view.php?id=<?= $municipalityId ?>">
        Municipality
    </a>

</nav>

<hr>

<main>

    <p>
        The administrator will receive a temporary password.
        They must change it after their first login.
    </p>

    <form
        method="POST"
        action="store-admin.php"
    >

        <input
            type="hidden"
            name="csrf_token"
            value="<?= e(csrfToken()) ?>"
        >

        <input
            type="hidden"
            name="municipality_id"
            value="<?= $municipalityId ?>"
        >

        <p>

            <label for="first_name">
                First Name
            </label>

            <br>

            <input
                type="text"
                id="first_name"
                name="first_name"
                maxlength="100"
                required
            >

        </p>

        <p>

            <label for="last_name">
                Last Name
            </label>

            <br>

            <input
                type="text"
                id="last_name"
                name="last_name"
                maxlength="100"
                required
            >

        </p>

        <p>

            <label for="email">
                Email
            </label>

            <br>

            <input
                type="email"
                id="email"
                name="email"
                maxlength="150"
                required
            >

        </p>

        <p>

            <label for="phone">
                Phone
            </label>

            <br>

            <input
                type="text"
                id="phone"
                name="phone"
                maxlength="50"
            >

        </p>

        <p>

            <label for="temporary_password">
                Temporary Password
            </label>

            <br>

            <input
                type="password"
                id="temporary_password"
                name="temporary_password"
                minlength="8"
                required
            >

        </p>

        <p>
            Minimum 8 characters.
        </p>

        <button type="submit">
            Create Municipality Admin
        </button>

        <a href="view.php?id=<?= $municipalityId ?>">
            Cancel
        </a>

    </form>

</main>

</body>

</html>