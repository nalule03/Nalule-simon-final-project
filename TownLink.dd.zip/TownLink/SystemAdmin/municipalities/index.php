<?php

declare(strict_types=1);

require_once __DIR__ . '/../includes/_auth.php';

$search = trim(
    $_GET['search'] ?? ''
);

$status = trim(
    $_GET['status'] ?? ''
);

$type = trim(
    $_GET['type'] ?? ''
);

$where = [];

$params = [];

/*
|--------------------------------------------------------------------------
| Search
|--------------------------------------------------------------------------
*/

if ($search !== '') {

    $where[] = "
        (
            m.name LIKE :search
            OR m.code LIKE :search
            OR m.region LIKE :search
            OR m.email LIKE :search
        )
    ";

    $params[':search'] =
        '%' . $search . '%';
}

/*
|--------------------------------------------------------------------------
| Status
|--------------------------------------------------------------------------
*/

if (
    in_array(
        $status,
        ['active', 'inactive'],
        true
    )
) {

    $where[] =
        'm.status = :status';

    $params[':status'] =
        $status;
}

/*
|--------------------------------------------------------------------------
| Type
|--------------------------------------------------------------------------
*/

if (
    in_array(
        $type,
        [
            'municipality',
            'town',
            'village'
        ],
        true
    )
) {

    $where[] =
        'm.type = :type';

    $params[':type'] =
        $type;
}

/*
|--------------------------------------------------------------------------
| Query
|--------------------------------------------------------------------------
*/

$sql = "
    SELECT
        m.id,
        m.name,
        m.code,
        m.type,
        m.region,
        m.phone,
        m.email,
        m.status,
        m.created_at,

        (
            SELECT COUNT(*)
            FROM users u
            WHERE
                u.municipality_id = m.id
                AND u.role = 'municipality_admin'
        ) AS admin_count

    FROM municipalities m
";

if ($where) {

    $sql .=
        ' WHERE ' .
        implode(
            ' AND ',
            $where
        );
}

$sql .= "
    ORDER BY m.name ASC
    LIMIT 200
";

try {

    $stmt = $pdo->prepare($sql);

    $stmt->execute($params);

    $municipalities =
        $stmt->fetchAll(
            PDO::FETCH_ASSOC
        );

} catch (PDOException $e) {

    error_log(
        'TownLink municipalities index error: ' .
        $e->getMessage()
    );

    http_response_code(500);

    exit(
        'Unable to load municipalities.'
    );
}

?>

<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Municipalities | TownLink
    </title>

</head>

<body>

<header>

    <h1>
        TownLink
    </h1>

    <p>
        System Administration
    </p>

</header>

<nav>

    <a href="../index.php">
        Dashboard
    </a>

    |

    <a href="index.php">
        Municipalities
    </a>

    |

    <a href="../public/logout.php">
        Logout
    </a>

</nav>

<hr>

<main>

    <h2>
        Municipalities
    </h2>

    <p>
        <a href="create.php">
            Create Municipality
        </a>
    </p>

    <form method="GET">

        <p>

            <label for="search">
                Search
            </label>

            <input
                type="text"
                id="search"
                name="search"
                value="<?= e($search) ?>"
                placeholder="Name, code, region or email"
            >

        </p>

        <p>

            <label for="status">
                Status
            </label>

            <select
                id="status"
                name="status"
            >

                <option value="">
                    All
                </option>

                <option
                    value="active"
                    <?= $status === 'active'
                        ? 'selected'
                        : '' ?>
                >
                    Active
                </option>

                <option
                    value="inactive"
                    <?= $status === 'inactive'
                        ? 'selected'
                        : '' ?>
                >
                    Inactive
                </option>

            </select>

        </p>

        <p>

            <label for="type">
                Type
            </label>

            <select
                id="type"
                name="type"
            >

                <option value="">
                    All
                </option>

                <option
                    value="municipality"
                    <?= $type === 'municipality'
                        ? 'selected'
                        : '' ?>
                >
                    Municipality
                </option>

                <option
                    value="town"
                    <?= $type === 'town'
                        ? 'selected'
                        : '' ?>
                >
                    Town
                </option>

                <option
                    value="village"
                    <?= $type === 'village'
                        ? 'selected'
                        : '' ?>
                >
                    Village
                </option>

            </select>

        </p>

        <button type="submit">
            Search
        </button>

        <a href="index.php">
            Reset
        </a>

    </form>

    <hr>

    <?php if (!$municipalities): ?>

        <p>
            No municipalities found.
        </p>

    <?php else: ?>

        <table border="1" cellpadding="8">

            <thead>

                <tr>

                    <th>
                        Name
                    </th>

                    <th>
                        Code
                    </th>

                    <th>
                        Type
                    </th>

                    <th>
                        Region
                    </th>

                    <th>
                        Admins
                    </th>

                    <th>
                        Status
                    </th>

                    <th>
                        Actions
                    </th>

                </tr>

            </thead>

            <tbody>

            <?php foreach (
                $municipalities
                as $municipality
            ): ?>

                <tr>

                    <td>

                        <?= e(
                            $municipality['name']
                        ) ?>

                    </td>

                    <td>

                        <?= e(
                            $municipality['code']
                        ) ?>

                    </td>

                    <td>

                        <?= e(
                            ucfirst(
                                $municipality['type']
                            )
                        ) ?>

                    </td>

                    <td>

                        <?= e(
                            $municipality['region']
                        ) ?>

                    </td>

                    <td>

                        <?= (int) (
                            $municipality['admin_count']
                            ?? 0
                        ) ?>

                    </td>

                    <td>

                        <?= e(
                            ucfirst(
                                $municipality['status']
                            )
                        ) ?>

                    </td>

                    <td>

                        <a
                            href="view.php?id=<?= (int) $municipality['id'] ?>"
                        >
                            View
                        </a>

                        |

                        <a
                            href="edit.php?id=<?= (int) $municipality['id'] ?>"
                        >
                            Edit
                        </a>

                        |

                        <a
                            href="create-admin.php?municipality_id=<?= (int) $municipality['id'] ?>"
                        >
                            Create Admin
                        </a>

                    </td>

                </tr>

            <?php endforeach; ?>

            </tbody>

        </table>

    <?php endif; ?>

</main>

</body>

</html>