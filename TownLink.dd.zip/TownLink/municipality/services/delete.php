<?php

declare(strict_types=1);

require_once __DIR__ . '/../auth.php';

requireMunicipalityAdmin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Method not allowed.');
}

verifyCsrf();

$id = filter_input(
    INPUT_POST,
    'id',
    FILTER_VALIDATE_INT
);

if (!$id) {
    http_response_code(400);
    exit('Invalid service.');
}

try {

    $stmt = $pdo->prepare("
        SELECT name
        FROM services
        WHERE id = :id
        AND municipality_id = :municipality_id
        LIMIT 1
    ");

    $stmt->execute([
        ':id' => $id,
        ':municipality_id' => $municipalityId
    ]);

    $service =
        $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$service) {
        http_response_code(404);
        exit('Service not found.');
    }

    /*
    |--------------------------------------------------------------------------
    | A service with requests should not be physically deleted.
    |--------------------------------------------------------------------------
    */

    $stmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM service_requests
        WHERE service_id = :service_id
    ");

    $stmt->execute([
        ':service_id' => $id
    ]);

    if ((int) $stmt->fetchColumn() > 0) {

        header(
            'Location: view.php?id=' .
            $id .
            '&error=has_requests'
        );

        exit;
    }

    $stmt = $pdo->prepare("
        DELETE FROM services
        WHERE id = :id
        AND municipality_id = :municipality_id
    ");

    $stmt->execute([
        ':id' => $id,
        ':municipality_id' => $municipalityId
    ]);

    auditLog(
        $pdo,
        $municipalityId,
        $userId,
        'delete',
        'service',
        $id,
        'Deleted service: ' .
        $service['name']
    );

    header(
        'Location: index.php'
    );

    exit;

} catch (PDOException $e) {

    error_log(
        'Service delete error: ' .
        $e->getMessage()
    );

    http_response_code(500);
    exit('Unable to delete service.');
}
