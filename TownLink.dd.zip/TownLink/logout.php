<?php

declare(strict_types=1);

session_start();

require_once __DIR__ . '/../app/config/database.php';

$userId = $_SESSION['user_id'] ?? null;
$municipalityId = $_SESSION['municipality_id'] ?? null;

if ($userId) {

    try {

        $stmt = $pdo->prepare("
            INSERT INTO audit_logs
            (
                municipality_id,
                user_id,
                action,
                entity_type,
                entity_id,
                description,
                ip_address,
                user_agent
            )
            VALUES
            (
                :municipality_id,
                :user_id,
                'logout',
                'user',
                :entity_id,
                'User logged out of TownLink.',
                :ip_address,
                :user_agent
            )
        ");

        $stmt->execute([
            ':municipality_id' => $municipalityId,
            ':user_id' => $userId,
            ':entity_id' => $userId,
            ':ip_address' => $_SERVER['REMOTE_ADDR'] ?? null,
            ':user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? null
        ]);

    } catch (PDOException $e) {

        error_log(
            'TownLink logout audit error: ' . $e->getMessage()
        );
    }
}

$_SESSION = [];

if (ini_get('session.use_cookies')) {

    $params = session_get_cookie_params();

    setcookie(
        session_name(),
        '',
        time() - 42000,
        $params['path'],
        $params['domain'],
        $params['secure'],
        $params['httponly']
    );
}

session_destroy();

header('Location: login.php');
exit;
