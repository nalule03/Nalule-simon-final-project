
<?php
declare(strict_types=1);

session_start();

require_once __DIR__ . '/app/config/database.php';

function e($value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$token = trim((string)($_POST['token'] ?? $_GET['token'] ?? ''));
$message = '';
$success = false;

$validToken = preg_match('/\A[a-f0-9]{64}\z/', $token) === 1;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf = (string)($_POST['csrf_token'] ?? '');
    $password = (string)($_POST['password'] ?? '');
    $confirmPassword = (string)($_POST['confirm_password'] ?? '');

    if (!hash_equals($_SESSION['csrf_token'], $csrf)) {
        $message = 'Your session expired. Refresh the page and try again.';
    } elseif (!$validToken) {
        $message = 'This reset link is invalid or has expired. Request a new one.';
    } elseif (strlen($password) < 10) {
        $message = 'Your new password must contain at least 10 characters.';
    } elseif (strlen($password) > 4096) {
        $message = 'Please choose a shorter password.';
    } elseif ($password !== $confirmPassword) {
        $message = 'The passwords do not match.';
    } else {
        try {
            $pdo->beginTransaction();

            $stmt = $pdo->prepare(
                "SELECT pr.id, pr.user_id
                 FROM password_resets pr
                 INNER JOIN users u ON u.id = pr.user_id
                 WHERE pr.token_hash = :token_hash
                   AND pr.expires_at > NOW()
                   AND pr.used_at IS NULL
                   AND u.status = 'active'
                 LIMIT 1
                 FOR UPDATE"
            );

            $stmt->execute([
                ':token_hash' => hash('sha256', $token)
            ]);

            $reset = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$reset) {
                $pdo->rollBack();
                $message = 'This reset link is invalid or has expired. Request a new one.';
            } else {
                $passwordHash = password_hash(
                    $password,
                    PASSWORD_DEFAULT
                );

                $update = $pdo->prepare(
                    'UPDATE users
                     SET password_hash = :password_hash,
                         must_change_password = 0
                     WHERE id = :user_id'
                );

                $update->execute([
                    ':password_hash' => $passwordHash,
                    ':user_id' => $reset['user_id']
                ]);

                // Mark this token used and invalidate all other reset links
                // belonging to the same user.
                $used = $pdo->prepare(
                    'UPDATE password_resets
                     SET used_at = NOW()
                     WHERE id = :id'
                );
                $used->execute([':id' => $reset['id']]);

                $deleteOthers = $pdo->prepare(
                    'DELETE FROM password_resets
                     WHERE user_id = :user_id
                       AND id <> :id'
                );
                $deleteOthers->execute([
                    ':user_id' => $reset['user_id'],
                    ':id' => $reset['id']
                ]);

                $pdo->commit();

                $success = true;
                $message = 'Your password has been changed successfully. You can now sign in with your new password.';

                // Remove the token from the displayed page and browser form.
                $token = '';
                $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            }
        } catch (Throwable $exception) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }

            error_log('TownLink reset-password error: ' . $exception->getMessage());
            $message = 'We could not reset your password right now. Please try again.';
        }
    }
} elseif (!$validToken) {
    $message = 'This reset link is invalid or has expired. Request a new one.';
} else {
    // Check the link before showing the form.
    try {
        $stmt = $pdo->prepare(
            "SELECT pr.id
             FROM password_resets pr
             INNER JOIN users u ON u.id = pr.user_id
             WHERE pr.token_hash = :token_hash
               AND pr.expires_at > NOW()
               AND pr.used_at IS NULL
               AND u.status = 'active'
             LIMIT 1"
        );

        $stmt->execute([
            ':token_hash' => hash('sha256', $token)
        ]);

        if (!$stmt->fetch()) {
            $message = 'This reset link is invalid or has expired. Request a new one.';
            $token = '';
        }
    } catch (PDOException $exception) {
        error_log('TownLink reset-link check error: ' . $exception->getMessage());
        $message = 'Unable to verify your reset link right now. Please try again.';
        $token = '';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Reset Password | TownLink</title>
<style>
:root{--green:#176b52;--dark:#123b32;--muted:#718078;--line:#e1e9e5}
*{box-sizing:border-box}
body{margin:0;background:#f3f7f5;color:#20332b;font-family:Segoe UI,Arial,sans-serif;min-height:100vh;display:grid;place-items:center;padding:22px}
.card{width:100%;max-width:440px;background:#fff;border:1px solid var(--line);border-radius:20px;padding:36px;box-shadow:0 16px 50px #123b3210}
.brand{font-size:23px;font-weight:800;color:var(--dark);margin-bottom:30px}
.brand span{color:var(--green)}
.icon{width:56px;height:56px;border-radius:16px;background:#e8f5ef;color:var(--green);display:grid;place-items:center;font-size:27px;margin-bottom:22px}
h1{font-size:28px;margin:0 0 10px;color:var(--dark)}
p{color:var(--muted);line-height:1.65}
label{display:block;font-weight:700;font-size:14px;margin:20px 0 8px}
input{width:100%;height:48px;border:1px solid #d5dfd9;border-radius:9px;padding:0 13px;font-size:15px}
input:focus{outline:3px solid #176b5220;border-color:var(--green)}
button,.primary{width:100%;min-height:49px;display:flex;align-items:center;justify-content:center;border:0;border-radius:9px;background:var(--green);color:#fff;font-weight:700;font-size:15px;margin-top:22px;cursor:pointer;text-decoration:none}
button:hover,.primary:hover{background:var(--dark);color:#fff}
.notice{padding:14px;border-radius:9px;background:#fff0ef;color:#a62f29;line-height:1.6;font-size:14px}
.notice.success{background:#eaf6ef;color:#176b52}
.back{display:block;text-align:center;margin-top:24px;color:var(--green);font-weight:700;text-decoration:none}
small{display:block;text-align:center;color:var(--muted);margin-top:28px}
</style>
</head>
<body>
<main class="card">
    <div class="brand">Town<span>Link</span></div>
    <div class="icon" aria-hidden="true">&#128274;</div>

    <h1><?= $success ? 'Password updated' : 'Create a new password' ?></h1>
    <p>
        <?= $success
            ? 'Your account is ready. Sign in using your new password.'
            : 'Choose a strong password that you have not used for this account before.' ?>
    </p>

    <?php if ($message !== ''): ?>
        <div class="notice <?= $success ? 'success' : '' ?>" role="status">
            <?= e($message) ?>
        </div>
    <?php endif; ?>

    <?php if ($success): ?>
        <a class="primary" href="login.php">Return to login</a>
    <?php elseif ($validToken && $token !== '' && strpos($message, 'invalid or has expired') === false && strpos($message, 'Unable to verify') === false): ?>
        <form method="post">
            <input type="hidden" name="csrf_token" value="<?= e($_SESSION['csrf_token']) ?>">
            <input type="hidden" name="token" value="<?= e($token) ?>">

            <label for="password">New password</label>
            <input type="password" id="password" name="password"
                   minlength="10" maxlength="4096"
                   autocomplete="new-password" required>

            <label for="confirm_password">Confirm new password</label>
            <input type="password" id="confirm_password" name="confirm_password"
                   minlength="10" maxlength="4096"
                   autocomplete="new-password" required>

            <button type="submit">Save new password</button>
        </form>
    <?php endif; ?>

    <a class="back" href="forgot-password.php">Request another reset link</a>
    <small>&copy; <?= date('Y') ?> TownLink Namibia</small>
</main>
</body>
</html>
