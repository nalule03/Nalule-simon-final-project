<?php

declare(strict_types=1);

require_once __DIR__ . '/../auth.php';
require_once __DIR__ . '/../layout.php';

$statusFilter = trim($_GET['status'] ?? '');
$priorityFilter = trim($_GET['priority'] ?? '');
$search = trim($_GET['search'] ?? '');

$where = [
    'sr.municipality_id = :municipality_id'
];

$params = [
    ':municipality_id' => $municipalityId
];

/*
|--------------------------------------------------------------------------
| Department Staff Restriction
|--------------------------------------------------------------------------
*/

if (!isMunicipalityAdmin()) {

    if ($currentUser['department_id'] === null) {

        $where[] = '1 = 0';

    } else {

        $where[] = 's.department_id = :department_id';

        $params[':department_id'] =
            (int) $currentUser['department_id'];
    }
}

/*
|--------------------------------------------------------------------------
| Filters
|--------------------------------------------------------------------------
*/

$validStatuses = [
    'submitted',
    'under_review',
    'assigned',
    'in_progress',
    'pending_resident',
    'resolved',
    'closed',
    'rejected',
    'cancelled'
];

$validPriorities = [
    'low',
    'normal',
    'high',
    'urgent'
];

if (in_array($statusFilter, $validStatuses, true)) {

    $where[] = 'sr.status = :status';

    $params[':status'] = $statusFilter;
}

if (in_array($priorityFilter, $validPriorities, true)) {

    $where[] = 'sr.priority = :priority';

    $params[':priority'] = $priorityFilter;
}

if ($search !== '') {

    $where[] = "
        (
            sr.reference_number LIKE :search
            OR sr.subject LIKE :search
            OR CONCAT(
                u.first_name,
                ' ',
                u.last_name
            ) LIKE :search
        )
    ";

    $params[':search'] = '%' . $search . '%';
}

/*
|--------------------------------------------------------------------------
| Requests
|--------------------------------------------------------------------------
*/

$requests = [];

try {

    $sql = "
        SELECT
            sr.id,
            sr.reference_number,
            sr.subject,
            sr.priority,
            sr.status,
            sr.submitted_at,

            s.name AS service_name,

            d.name AS department_name,

            CONCAT(
                u.first_name,
                ' ',
                u.last_name
            ) AS resident_name

        FROM service_requests sr

        INNER JOIN services s
            ON s.id = sr.service_id

        INNER JOIN departments d
            ON d.id = s.department_id

        INNER JOIN users u
            ON u.id = sr.resident_id

        WHERE " . implode(' AND ', $where) . "

        ORDER BY sr.submitted_at DESC

        LIMIT 100
    ";

    $stmt = $pdo->prepare($sql);

    $stmt->execute($params);

    $requests = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {

    error_log(
        'Municipality requests index error: ' .
        $e->getMessage()
    );
}

municipalityHeader(
    'Service Requests',
    'requests'
);

?>

<div class="container-fluid">

    <div class="d-flex justify-content-between align-items-center mb-4">

        <div>

            <h2 class="mb-1">
                Service Requests
            </h2>

            <p class="text-muted mb-0">
                Review and process requests submitted by residents.
            </p>

        </div>

    </div>


    <?php if (!$requests && $search !== ''): ?>

        <div class="alert alert-info">
            No requests matched your search.
        </div>

    <?php endif; ?>


    <div class="card shadow-sm mb-4">

        <div class="card-header bg-white">

            <h5 class="mb-0">
                Filter Requests
            </h5>

        </div>

        <div class="card-body">

            <form method="GET">

                <div class="row g-3">

                    <div class="col-md-5">

                        <label
                            for="search"
                            class="form-label"
                        >
                            Search
                        </label>

                        <input
                            type="text"
                            class="form-control"
                            id="search"
                            name="search"
                            value="<?= e($search) ?>"
                            placeholder="Reference, subject or resident"
                        >

                    </div>


                    <div class="col-md-3">

                        <label
                            for="status"
                            class="form-label"
                        >
                            Status
                        </label>

                        <select
                            class="form-select"
                            id="status"
                            name="status"
                        >

                            <option value="">
                                All statuses
                            </option>

                            <?php foreach (
                                $validStatuses as $status
                            ): ?>

                                <option
                                    value="<?= e($status) ?>"
                                    <?= $statusFilter === $status
                                        ? 'selected'
                                        : ''
                                    ?>
                                >
                                    <?= e(
                                        ucwords(
                                            str_replace(
                                                '_',
                                                ' ',
                                                $status
                                            )
                                        )
                                    ) ?>
                                </option>

                            <?php endforeach; ?>

                        </select>

                    </div>


                    <div class="col-md-2">

                        <label
                            for="priority"
                            class="form-label"
                        >
                            Priority
                        </label>

                        <select
                            class="form-select"
                            id="priority"
                            name="priority"
                        >

                            <option value="">
                                All priorities
                            </option>

                            <?php foreach (
                                $validPriorities as $priority
                            ): ?>

                                <option
                                    value="<?= e($priority) ?>"
                                    <?= $priorityFilter === $priority
                                        ? 'selected'
                                        : ''
                                    ?>
                                >
                                    <?= e(
                                        ucfirst($priority)
                                    ) ?>
                                </option>

                            <?php endforeach; ?>

                        </select>

                    </div>


                    <div class="col-md-2 d-flex align-items-end">

                        <div class="d-flex gap-2 w-100">

                            <button
                                type="submit"
                                class="btn btn-primary"
                            >
                                Search
                            </button>

                            <a
                                href="index.php"
                                class="btn btn-secondary"
                            >
                                Reset
                            </a>

                        </div>

                    </div>

                </div>

            </form>

        </div>

    </div>


    <div class="card shadow-sm">

        <div class="card-header bg-white">

            <div class="d-flex justify-content-between align-items-center">

                <h5 class="mb-0">
                    Requests
                </h5>

                <span class="badge text-bg-secondary">
                    <?= count($requests) ?>
                </span>

            </div>

        </div>


        <div class="card-body p-0">

            <?php if (!$requests): ?>

                <div class="p-4">

                    <p class="text-muted mb-0">
                        No service requests found.
                    </p>

                </div>

            <?php else: ?>

                <div class="table-responsive">

                    <table class="table table-hover mb-0">

                        <thead class="table-light">

                        <tr>

                            <th>
                                Reference
                            </th>

                            <th>
                                Subject
                            </th>

                            <th>
                                Resident
                            </th>

                            <th>
                                Department
                            </th>

                            <th>
                                Service
                            </th>

                            <th>
                                Priority
                            </th>

                            <th>
                                Status
                            </th>

                            <th>
                                Submitted
                            </th>

                        </tr>

                        </thead>


                        <tbody>

                        <?php foreach (
                            $requests as $request
                        ): ?>

                            <tr>

                                <td>

                                    <a
                                        href="view.php?id=<?= (int) $request['id'] ?>"
                                        class="fw-semibold text-decoration-none"
                                    >
                                        <?= e(
                                            $request['reference_number']
                                        ) ?>
                                    </a>

                                </td>


                                <td>
                                    <?= e(
                                        $request['subject']
                                    ) ?>
                                </td>


                                <td>
                                    <?= e(
                                        $request['resident_name']
                                    ) ?>
                                </td>


                                <td>
                                    <?= e(
                                        $request['department_name']
                                    ) ?>
                                </td>


                                <td>
                                    <?= e(
                                        $request['service_name']
                                    ) ?>
                                </td>


                                <td>

                                    <?php

                                    $priorityClass = match (
                                        $request['priority']
                                    ) {
                                        'urgent' => 'danger',
                                        'high' => 'warning',
                                        'normal' => 'primary',
                                        default => 'secondary'
                                    };

                                    ?>

                                    <span
                                        class="badge text-bg-<?= e($priorityClass) ?>"
                                    >
                                        <?= e(
                                            ucfirst(
                                                $request['priority']
                                            )
                                        ) ?>
                                    </span>

                                </td>


                                <td>

                                    <?php

                                    $statusClass = match (
                                        $request['status']
                                    ) {
                                        'resolved',
                                        'closed'
                                            => 'success',

                                        'rejected',
                                        'cancelled'
                                            => 'danger',

                                        'pending_resident',
                                        'under_review'
                                            => 'warning',

                                        'submitted',
                                        'assigned',
                                        'in_progress'
                                            => 'primary',

                                        default
                                            => 'secondary'
                                    };

                                    ?>

                                    <span
                                        class="badge text-bg-<?= e($statusClass) ?>"
                                    >
                                        <?= e(
                                            ucwords(
                                                str_replace(
                                                    '_',
                                                    ' ',
                                                    $request['status']
                                                )
                                            )
                                        ) ?>
                                    </span>

                                </td>


                                <td>
                                    <?= e(
                                        $request['submitted_at']
                                    ) ?>
                                </td>

                            </tr>

                        <?php endforeach; ?>

                        </tbody>

                    </table>

                </div>

            <?php endif; ?>

        </div>

    </div>

</div>

<?php

municipalityFooter();