<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| TownLink - Resident Profile
|--------------------------------------------------------------------------
*/

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

require_once __DIR__ . '/../app/config/database.php';

/*
|--------------------------------------------------------------------------
| Authentication
|--------------------------------------------------------------------------
*/

if (empty($_SESSION['user_id'])) {
    header('Location: ../public/login.php');
    exit;
}

if (($_SESSION['role'] ?? '') !== 'resident') {
    http_response_code(403);
    exit('Access denied.');
}

$userId = (int) $_SESSION['user_id'];

if ($userId <= 0) {
    http_response_code(403);
    exit('Invalid user account.');
}

/*
|--------------------------------------------------------------------------
| Helpers
|--------------------------------------------------------------------------
*/

if (!function_exists('residentProfileEscape')) {
    function residentProfileEscape(mixed $value): string
    {
        return htmlspecialchars(
            (string) ($value ?? ''),
            ENT_QUOTES | ENT_SUBSTITUTE,
            'UTF-8'
        );
    }
}

function residentProfileColumn(
    array $columns,
    array $candidates
): ?string {
    foreach ($candidates as $candidate) {
        if (in_array($candidate, $columns, true)) {
            return $candidate;
        }
    }

    return null;
}

/*
|--------------------------------------------------------------------------
| Load and update profile
|--------------------------------------------------------------------------
*/

$profile = [];
$columns = [];
$errors = [];
$successMessage = '';
$databaseError = '';

$csrfToken = $_SESSION['profile_csrf_token']
    ?? bin2hex(random_bytes(32));

$_SESSION['profile_csrf_token'] = $csrfToken;

try {
    /*
     * This page expects the account table to be named "users"
     * and its primary key to be "id".
     */

    $columnStatement = $pdo->query('SHOW COLUMNS FROM users');
    $columns = $columnStatement->fetchAll(PDO::FETCH_COLUMN);

    if (!in_array('id', $columns, true)) {
        throw new RuntimeException(
            'The users table does not contain an id column.'
        );
    }

    $stmt = $pdo->prepare(
        'SELECT * FROM users WHERE id = :id LIMIT 1'
    );

    $stmt->execute([':id' => $userId]);

    $profile = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];

    if (!$profile) {
        http_response_code(404);
        exit('Resident account not found.');
    }

    /*
     * Resolve optional columns used by different schemas.
     */

    $firstNameColumn = residentProfileColumn(
        $columns,
        ['first_name', 'firstname']
    );

    $lastNameColumn = residentProfileColumn(
        $columns,
        ['last_name', 'lastname', 'surname']
    );

    $emailColumn = residentProfileColumn(
        $columns,
        ['email', 'email_address']
    );

    $phoneColumn = residentProfileColumn(
        $columns,
        ['phone', 'phone_number', 'contact_number', 'mobile']
    );

    $addressColumn = residentProfileColumn(
        $columns,
        ['address', 'residential_address']
    );

    /*
     * Process profile form.
     */

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $submittedToken = $_POST['csrf_token'] ?? '';

        if (
            !is_string($submittedToken)
            || !hash_equals($csrfToken, $submittedToken)
        ) {
            $errors[] =
                'Your session has expired. Refresh the page and try again.';
        } else {
            $updates = [];

            $fieldDefinitions = [
                'first_name' => [
                    'column' => $firstNameColumn,
                    'label' => 'First name',
                    'max' => 100,
                    'required' => true,
                ],
                'last_name' => [
                    'column' => $lastNameColumn,
                    'label' => 'Last name',
                    'max' => 100,
                    'required' => true,
                ],
                'email' => [
                    'column' => $emailColumn,
                    'label' => 'Email address',
                    'max' => 254,
                    'required' => true,
                ],
                'phone' => [
                    'column' => $phoneColumn,
                    'label' => 'Phone number',
                    'max' => 30,
                    'required' => false,
                ],
                'address' => [
                    'column' => $addressColumn,
                    'label' => 'Residential address',
                    'max' => 255,
                    'required' => false,
                ],
            ];

            foreach ($fieldDefinitions as $field => $definition) {
                $column = $definition['column'];

                if ($column === null) {
                    continue;
                }

                $value = trim(
                    (string) ($_POST[$field] ?? '')
                );

                if (
                    $definition['required']
                    && $value === ''
                ) {
                    $errors[] =
                        $definition['label'] . ' is required.';
                    continue;
                }

                if (strlen($value) > $definition['max']) {
                    $errors[] =
                        $definition['label'] .
                        ' must not exceed ' .
                        $definition['max'] .
                        ' characters.';
                    continue;
                }

                if (
                    $field === 'email'
                    && $value !== ''
                    && !filter_var(
                        $value,
                        FILTER_VALIDATE_EMAIL
                    )
                ) {
                    $errors[] = 'Enter a valid email address.';
                    continue;
                }

                $updates[$column] = $value;
            }

            if (
                !$errors
                && $emailColumn !== null
                && isset($updates[$emailColumn])
            ) {
                $email = $updates[$emailColumn];

                $stmt = $pdo->prepare(
                    "SELECT id FROM users
                     WHERE `$emailColumn` = :email
                       AND id <> :id
                     LIMIT 1"
                );

                $stmt->execute([
                    ':email' => $email,
                    ':id' => $userId,
                ]);

                if ($stmt->fetchColumn()) {
                    $errors[] =
                        'That email address is already in use.';
                }
            }

            if (!$errors && $updates) {
                $setParts = [];
                $params = [':id' => $userId];
                $index = 0;

                foreach ($updates as $column => $value) {
                    /*
                     * Column names come only from the database
                     * column list and the predefined field map.
                     */

                    if (!in_array($column, $columns, true)) {
                        continue;
                    }

                    $placeholder = ':field_' . $index++;

                    $setParts[] =
                        "`$column` = $placeholder";

                    $params[$placeholder] = $value;
                }

                if ($setParts) {
                    $sql = 'UPDATE users SET ' .
                        implode(', ', $setParts) .
                        ' WHERE id = :id';

                    $stmt = $pdo->prepare($sql);
                    $stmt->execute($params);
                }

                /*
                 * Reload the saved record.
                 */

                $stmt = $pdo->prepare(
                    'SELECT * FROM users WHERE id = :id LIMIT 1'
                );

                $stmt->execute([':id' => $userId]);

                $profile = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];

                /*
                 * Keep session names synchronized with the profile.
                 */

                if ($firstNameColumn !== null) {
                    $_SESSION['first_name'] =
                        $profile[$firstNameColumn] ?? '';
                }

                if ($lastNameColumn !== null) {
                    $_SESSION['last_name'] =
                        $profile[$lastNameColumn] ?? '';
                }

                $_SESSION['profile_csrf_token'] =
                    bin2hex(random_bytes(32));

                $csrfToken = $_SESSION['profile_csrf_token'];

                $successMessage =
                    'Your profile has been updated successfully.';
            } elseif (!$errors && !$updates) {
                $errors[] =
                    'No editable profile fields were found in the users table.';
            }
        }
    }
} catch (Throwable $e) {
    error_log(
        'TownLink resident profile error: ' .
        $e->getMessage()
    );

    $databaseError =
        'Your profile could not be loaded or saved. ' .
        'Please check your database configuration and try again.';
}

/*
|--------------------------------------------------------------------------
| Display values
|--------------------------------------------------------------------------
*/

$firstName = $firstNameColumn !== null
    ? (string) ($profile[$firstNameColumn] ?? '')
    : (string) ($_SESSION['first_name'] ?? '');

$lastName = $lastNameColumn !== null
    ? (string) ($profile[$lastNameColumn] ?? '')
    : (string) ($_SESSION['last_name'] ?? '');

$email = $emailColumn !== null
    ? (string) ($profile[$emailColumn] ?? '')
    : '';

$phone = $phoneColumn !== null
    ? (string) ($profile[$phoneColumn] ?? '')
    : '';

$address = $addressColumn !== null
    ? (string) ($profile[$addressColumn] ?? '')
    : '';

$fullName = trim($firstName . ' ' . $lastName);

if ($fullName === '') {
    $fullName = 'Resident';
}

$initial = strtoupper(substr($fullName, 0, 1));

$createdAt = (string) (
    $profile['created_at'] ?? ''
);

$municipalityName = 'Your Municipality';

try {
    $municipalityId = (int) (
        $_SESSION['municipality_id'] ?? 0
    );

    if ($municipalityId > 0) {
        $stmt = $pdo->prepare(
            'SELECT name FROM municipalities
             WHERE id = :id LIMIT 1'
        );

        $stmt->execute([':id' => $municipalityId]);

        $municipalityName = (string) (
            $stmt->fetchColumn() ?: $municipalityName
        );
    }
} catch (Throwable $e) {
    error_log(
        'TownLink profile municipality lookup error: ' .
        $e->getMessage()
    );
}

$pageTitle = 'My Profile';

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <meta name="theme-color" content="#123b32">

    <title><?= residentProfileEscape($pageTitle) ?> | TownLink</title>
     <link rel="stylesheet" href="../assets/vendor/bootstrap-icons/bootstrap-icons.css">

    <style>
        :root {
            --profile-green: #176b52;
            --profile-dark: #123b32;
            --profile-light: #e8f5ef;
            --profile-background: #f4f7f6;
            --profile-border: #e1e9e5;
            --profile-muted: #718078;
        }

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            background: var(--profile-background);
            color: #182b25;
            font-family: "Segoe UI", Arial, sans-serif;
        }

        .profile-page {
            max-width: 1120px;
            margin: 0 auto;
            padding: 34px 24px 55px;
        }

        .profile-heading {
            margin-bottom: 25px;
        }

        .profile-heading h1 {
            margin: 0 0 7px;
            color: var(--profile-dark);
            font-size: clamp(26px, 3vw, 34px);
            font-weight: 800;
            letter-spacing: -.7px;
        }

        .profile-heading p {
            margin: 0;
            color: var(--profile-muted);
        }

        .profile-layout {
            display: grid;
            grid-template-columns: 300px minmax(0, 1fr);
            gap: 22px;
            align-items: start;
        }

        .profile-card {
            overflow: hidden;
            background: #fff;
            border: 1px solid var(--profile-border);
            border-radius: 17px;
            box-shadow: 0 5px 22px rgba(20, 55, 43, .045);
        }

        .profile-summary {
            padding: 30px 22px;
            text-align: center;
        }

        .profile-avatar {
            width: 90px;
            height: 90px;
            display: grid;
            place-items: center;
            margin: 0 auto 16px;
            border: 5px solid #dff1e7;
            border-radius: 50%;
            background: var(--profile-light);
            color: var(--profile-dark);
            font-size: 32px;
            font-weight: 800;
        }

        .profile-summary h2 {
            margin: 0 0 5px;
            color: var(--profile-dark);
            font-size: 20px;
            font-weight: 800;
            overflow-wrap: anywhere;
        }

        .profile-role {
            color: var(--profile-muted);
            font-size: 13px;
        }

        .profile-divider {
            height: 1px;
            background: var(--profile-border);
        }

        .profile-meta {
            padding: 20px 23px;
        }

        .profile-meta-item {
            margin-bottom: 17px;
        }

        .profile-meta-item:last-child {
            margin-bottom: 0;
        }

        .profile-meta-label {
            display: block;
            margin-bottom: 4px;
            color: var(--profile-muted);
            font-size: 12px;
        }

        .profile-meta-value {
            color: var(--profile-dark);
            font-size: 14px;
            font-weight: 700;
            overflow-wrap: anywhere;
        }

        .profile-form-card {
            padding: 27px;
        }

        .profile-form-heading {
            margin-bottom: 23px;
        }

        .profile-form-heading h2 {
            margin: 0 0 5px;
            color: var(--profile-dark);
            font-size: 20px;
            font-weight: 800;
        }

        .profile-form-heading p {
            margin: 0;
            color: var(--profile-muted);
            font-size: 13px;
        }

        .profile-label {
            display: block;
            margin-bottom: 7px;
            color: var(--profile-dark);
            font-size: 13px;
            font-weight: 700;
        }

        .profile-input {
            width: 100%;
            min-height: 45px;
            padding: 10px 12px;
            border: 1px solid var(--profile-border);
            border-radius: 9px;
            background: #fff;
            color: #182b25;
            font: inherit;
            outline: none;
        }

        .profile-input:focus {
            border-color: var(--profile-green);
            box-shadow: 0 0 0 3px rgba(23, 107, 82, .12);
        }

        textarea.profile-input {
            min-height: 100px;
            resize: vertical;
        }

        .profile-field {
            margin-bottom: 19px;
        }

        .profile-actions {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-top: 25px;
        }

        .profile-button {
            display: inline-flex;
            min-height: 43px;
            align-items: center;
            justify-content: center;
            padding: 10px 17px;
            border: 1px solid transparent;
            border-radius: 9px;
            background: var(--profile-green);
            color: #fff;
            font-size: 13px;
            font-weight: 800;
            text-decoration: none;
            cursor: pointer;
        }

        .profile-button:hover {
            background: var(--profile-dark);
            color: #fff;
        }

        .profile-button-secondary {
            border-color: var(--profile-border);
            background: #fff;
            color: var(--profile-dark);
        }

        .profile-button-secondary:hover {
            background: #f1f7f3;
            color: var(--profile-dark);
        }

        .profile-notice {
            padding: 13px 15px;
            margin-bottom: 20px;
            border: 1px solid;
            border-radius: 10px;
            font-size: 13px;
        }

        .profile-notice-success {
            border-color: #b7e4c7;
            background: #effaf2;
            color: #176b40;
        }

        .profile-notice-error {
            border-color: #f3c3bf;
            background: #fff3f2;
            color: #a12620;
        }

        .profile-footer {
            margin-top: 25px;
            color: var(--profile-muted);
            font-size: 12px;
            text-align: center;
        }

        @media (max-width: 760px) {
            .profile-page {
                padding: 25px 15px 35px;
            }

            .profile-layout {
                grid-template-columns: 1fr;
            }

            .profile-form-card {
                padding: 21px 17px;
            }
        }
    </style>
</head>

<body>

<?php require_once __DIR__ . '/_navbar.php'; ?>

<main class="profile-page">

    <header class="profile-heading">
        <h1>My Profile</h1>
        <p>
            View your resident account information and update your details.
        </p>
    </header>

    <?php if ($successMessage !== ''): ?>
        <div class="profile-notice profile-notice-success" role="status">
            <?= residentProfileEscape($successMessage) ?>
        </div>
    <?php endif; ?>

    <?php if ($databaseError !== ''): ?>
        <div class="profile-notice profile-notice-error" role="alert">
            <?= residentProfileEscape($databaseError) ?>
        </div>
    <?php endif; ?>

    <?php if ($errors): ?>
        <div class="profile-notice profile-notice-error" role="alert">
            <strong>Please correct the following:</strong>
            <ul class="mb-0 mt-2">
                <?php foreach ($errors as $error): ?>
                    <li><?= residentProfileEscape($error) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <?php if ($profile): ?>

        <div class="profile-layout">

            <aside class="profile-card">

                <div class="profile-summary">

                    <div class="profile-avatar" aria-hidden="true">
                        <?= residentProfileEscape($initial) ?>
                    </div>

                    <h2><?= residentProfileEscape($fullName) ?></h2>

                    <div class="profile-role">
                        Resident account
                    </div>

                </div>

                <div class="profile-divider"></div>

                <div class="profile-meta">

                    <div class="profile-meta-item">
                        <span class="profile-meta-label">
                            Municipality
                        </span>

                        <div class="profile-meta-value">
                            <?= residentProfileEscape($municipalityName) ?>
                        </div>
                    </div>

                    <div class="profile-meta-item">
                        <span class="profile-meta-label">
                            Account ID
                        </span>

                        <div class="profile-meta-value">
                            #<?= $userId ?>
                        </div>
                    </div>

                    <div class="profile-meta-item">
                        <span class="profile-meta-label">
                            Email address
                        </span>

                        <div class="profile-meta-value">
                            <?= residentProfileEscape($email ?: 'Not provided') ?>
                        </div>
                    </div>

                    <div class="profile-meta-item">
                        <span class="profile-meta-label">
                            Member since
                        </span>

                        <div class="profile-meta-value">
                            <?= residentProfileEscape(
                                $createdAt !== ''
                                    ? $createdAt
                                    : 'Not available'
                            ) ?>
                        </div>
                    </div>

                </div>

            </aside>

            <section class="profile-card profile-form-card">

                <div class="profile-form-heading">
                    <h2>Personal Information</h2>
                    <p>
                        Update the details associated with your account.
                    </p>
                </div>

                <form method="POST" action="profile.php">

                    <input
                        type="hidden"
                        name="csrf_token"
                        value="<?= residentProfileEscape($csrfToken) ?>"
                    >

                    <div class="row">

                        <?php if ($firstNameColumn !== null): ?>
                            <div class="col-md-6">
                                <div class="profile-field">
                                    <label class="profile-label" for="first_name">
                                        First name
                                    </label>

                                    <input
                                        class="profile-input"
                                        type="text"
                                        id="first_name"
                                        name="first_name"
                                        maxlength="100"
                                        autocomplete="given-name"
                                        required
                                        value="<?= residentProfileEscape($firstName) ?>"
                                    >
                                </div>
                            </div>
                        <?php endif; ?>

                        <?php if ($lastNameColumn !== null): ?>
                            <div class="col-md-6">
                                <div class="profile-field">
                                    <label class="profile-label" for="last_name">
                                        Last name
                                    </label>

                                    <input
                                        class="profile-input"
                                        type="text"
                                        id="last_name"
                                        name="last_name"
                                        maxlength="100"
                                        autocomplete="family-name"
                                        required
                                        value="<?= residentProfileEscape($lastName) ?>"
                                    >
                                </div>
                            </div>
                        <?php endif; ?>

                        <?php if ($emailColumn !== null): ?>
                            <div class="col-md-6">
                                <div class="profile-field">
                                    <label class="profile-label" for="email">
                                        Email address
                                    </label>

                                    <input
                                        class="profile-input"
                                        type="email"
                                        id="email"
                                        name="email"
                                        maxlength="254"
                                        autocomplete="email"
                                        required
                                        value="<?= residentProfileEscape($email) ?>"
                                    >
                                </div>
                            </div>
                        <?php endif; ?>

                        <?php if ($phoneColumn !== null): ?>
                            <div class="col-md-6">
                                <div class="profile-field">
                                    <label class="profile-label" for="phone">
                                        Phone number
                                    </label>

                                    <input
                                        class="profile-input"
                                        type="tel"
                                        id="phone"
                                        name="phone"
                                        maxlength="30"
                                        autocomplete="tel"
                                        value="<?= residentProfileEscape($phone) ?>"
                                    >
                                </div>
                            </div>
                        <?php endif; ?>

                        <?php if ($addressColumn !== null): ?>
                            <div class="col-12">
                                <div class="profile-field">
                                    <label class="profile-label" for="address">
                                        Residential address
                                    </label>

                                    <textarea
                                        class="profile-input"
                                        id="address"
                                        name="address"
                                        maxlength="255"
                                        autocomplete="street-address"
                                    ><?= residentProfileEscape($address) ?></textarea>
                                </div>
                            </div>
                        <?php endif; ?>

                    </div>

                    <div class="profile-actions">

                        <button
                            type="submit"
                            class="profile-button"
                            <?= $databaseError !== '' ? 'disabled' : '' ?>
                        >
                            Save Changes
                        </button>

                        <a
                            href="dashboard.php"
                            class="profile-button profile-button-secondary"
                        >
                            Cancel
                        </a>

                    </div>

                </form>

            </section>

        </div>

    <?php endif; ?>

    <footer class="profile-footer">
        &copy; <?= date('Y') ?> TownLink Namibia. Resident Services Portal.
    </footer>

</main>

</body>
</html>