<?php

declare(strict_types=1);

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

require_once __DIR__ . '/../app/config/database.php';
require_once __DIR__ . '/../app/helpers/audit.php';

/*
|--------------------------------------------------------------------------
| Authentication
|--------------------------------------------------------------------------
*/

if (!isset($_SESSION['user_id'])) {
    header('Location: ../public/login.php');
    exit;
}

$userId = (int) $_SESSION['user_id'];
$role = (string) ($_SESSION['role'] ?? '');
$municipalityId = (int) ($_SESSION['municipality_id'] ?? 0);

$allowedRoles = [
    'municipality_admin',
    'department_staff',
];

if (!in_array($role, $allowedRoles, true)) {
    http_response_code(403);
    exit('Access denied.');
}

if ($municipalityId <= 0) {
    http_response_code(403);
    exit('No municipality is associated with this account.');
}

/*
|--------------------------------------------------------------------------
| Current User and Municipality
|--------------------------------------------------------------------------
*/

try {
    $stmt = $pdo->prepare("
        SELECT
            id,
            municipality_id,
            department_id,
            first_name,
            last_name,
            email,
            phone,
            role,
            status
        FROM users
        WHERE id = :id
        LIMIT 1
    ");

    $stmt->execute([
        ':id' => $userId,
    ]);

    $currentUser = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$currentUser) {
        session_unset();
        session_destroy();

        header('Location: ../public/login.php');
        exit;
    }

    if ($currentUser['status'] !== 'active') {
        session_unset();
        session_destroy();

        header('Location: ../public/login.php');
        exit;
    }

    if (
        $currentUser['municipality_id'] === null ||
        (int) $currentUser['municipality_id'] !== $municipalityId
    ) {
        http_response_code(403);
        exit('Invalid municipality access.');
    }

    $stmt = $pdo->prepare("
        SELECT
            id,
            name,
            code,
            type,
            region,
            description,
            address,
            phone,
            email,
            website,
            logo,
            status,
            created_at,
            updated_at
        FROM municipalities
        WHERE id = :id
        LIMIT 1
    ");

    $stmt->execute([
        ':id' => $municipalityId,
    ]);

    $currentMunicipality = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$currentMunicipality) {
        http_response_code(404);
        exit('Municipality not found.');
    }

    if ($currentMunicipality['status'] !== 'active') {
        http_response_code(403);
        exit('This municipality is inactive.');
    }

} catch (PDOException $e) {
    error_log(
        'TownLink municipality auth error: ' .
        $e->getMessage()
    );

    http_response_code(500);
    exit('Unable to load municipality information.');
}

/*
|--------------------------------------------------------------------------
| HTML Escape Helper
|--------------------------------------------------------------------------
*/

function e(?string $value): string
{
    return htmlspecialchars(
        (string) $value,
        ENT_QUOTES,
        'UTF-8'
    );
}

/*
|--------------------------------------------------------------------------
| Municipality Administrator
|--------------------------------------------------------------------------
*/

function isMunicipalityAdmin(): bool
{
    return ($_SESSION['role'] ?? '') === 'municipality_admin';
}

function requireMunicipalityAdmin(): void
{
    if (!isMunicipalityAdmin()) {
        http_response_code(403);
        exit(
            'Access denied. Municipality administrator privileges are required.'
        );
    }
}

/*
|--------------------------------------------------------------------------
| CSRF Protection
|--------------------------------------------------------------------------
*/

function csrfToken(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }

    return $_SESSION['csrf_token'];
}

function verifyCsrf(): void
{
    $token = $_POST['csrf_token'] ?? '';

    if (
        !is_string($token) ||
        !hash_equals(csrfToken(), $token)
    ) {
        http_response_code(419);
        exit(
            'Invalid security token. Please go back and try again.'
        );
    }
}