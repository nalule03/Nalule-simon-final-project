<?php

declare(strict_types=1);

require_once __DIR__ . '/../auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Method not allowed.');
}

verify_csrf();

$id = filter_input(
    INPUT_POST,
    'id',
    FILTER_VALIDATE_INT
);

if (!$id) {
    http_response_code(400);
    exit('Invalid department.');
}

$stmt = $pdo->prepare("
    SELECT status
    FROM departments
    WHERE id = :id
    AND municipality_id = :municipality_id
    LIMIT 1
");

$stmt->execute([
    ':id' => $id,
    ':municipality_id' => $municipalityId
]);

$department = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$department) {
    http_response_code(404);
    exit('Department not found.');
}

$newStatus =
    $department['status'] === 'active'
    ? 'inactive'
    : 'active';

$update = $pdo->prepare("
    UPDATE departments

    SET status = :status

    WHERE id = :id
    AND municipality_id = :municipality_id
");

$update->execute([
    ':status' => $newStatus,
    ':id' => $id,
    ':municipality_id' => $municipalityId
]);

header('Location: index.php');
exit;
