<?php

declare(strict_types=1);

require_once __DIR__ . '/../_auth.php';

requireMunicipalityAdmin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Method not allowed.');
}

verifyCsrf();

$id = filter_input(
    INPUT_POST,
    'id',
    FILTER_VALIDATE_INT
);

if (!$id) {
    http_response_code(400);
    exit('Invalid department.');
}

try {

    $stmt = $pdo->prepare("
        SELECT name
        FROM departments
        WHERE id = :id
        AND municipality_id = :municipality_id
        LIMIT 1
    ");

    $stmt->execute([
        ':id' => $id,
        ':municipality_id' => $municipalityId
    ]);

    $department =
        $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$department) {
        http_response_code(404);
        exit('Department not found.');
    }

    /*
    |--------------------------------------------------------------------------
    | Do not delete departments that still have services.
    |--------------------------------------------------------------------------
    */

    $stmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM services
        WHERE department_id = :department_id
    ");

    $stmt->execute([
        ':department_id' => $id
    ]);

    if ((int) $stmt->fetchColumn() > 0) {

        header(
            'Location: view.php?id=' .
            $id .
            '&error=has_services'
        );

        exit;
    }

    $pdo->beginTransaction();

    $stmt = $pdo->prepare("
        DELETE FROM departments
        WHERE id = :id
        AND municipality_id = :municipality_id
    ");

    $stmt->execute([
        ':id' => $id,
        ':municipality_id' => $municipalityId
    ]);

    $pdo->commit();

    auditLog(
        $pdo,
        $municipalityId,
        $userId,
        'delete',
        'department',
        $id,
        'Deleted department: ' .
        $department['name']
    );

    header(
        'Location: index.php'
    );

    exit;

} catch (PDOException $e) {

    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    error_log(
        'Department delete error: ' .
        $e->getMessage()
    );

    http_response_code(500);
    exit('Unable to delete department.');
}
