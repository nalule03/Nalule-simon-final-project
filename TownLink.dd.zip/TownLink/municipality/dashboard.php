<?php

declare(strict_types=1);

require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/layout.php';

$stats = [
    'departments' => 0,
    'services' => 0,
    'categories' => 0,
    'requests' => 0,
    'submitted' => 0,
    'in_progress' => 0,
    'resolved' => 0,
    'urgent' => 0
];

$recentRequests = [];

try {

    /*
    |--------------------------------------------------------------------------
    | Departments
    |--------------------------------------------------------------------------
    */

    $stmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM departments
        WHERE municipality_id = :municipality_id
    ");

    $stmt->execute([
        ':municipality_id' => $municipalityId
    ]);

    $stats['departments'] =
        (int) $stmt->fetchColumn();


    /*
    |--------------------------------------------------------------------------
    | Services
    |--------------------------------------------------------------------------
    */

    $stmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM services
        WHERE municipality_id = :municipality_id
        AND status = 'active'
    ");

    $stmt->execute([
        ':municipality_id' => $municipalityId
    ]);

    $stats['services'] =
        (int) $stmt->fetchColumn();


    /*
    |--------------------------------------------------------------------------
    | Categories
    |--------------------------------------------------------------------------
    */

    $stmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM service_categories
        WHERE municipality_id = :municipality_id
        AND status = 'active'
    ");

    $stmt->execute([
        ':municipality_id' => $municipalityId
    ]);

    $stats['categories'] =
        (int) $stmt->fetchColumn();


    /*
    |--------------------------------------------------------------------------
    | Requests
    |--------------------------------------------------------------------------
    */

    $stmt = $pdo->prepare("
        SELECT
            COUNT(*) AS total,

            SUM(
                status = 'submitted'
            ) AS submitted,

            SUM(
                status = 'in_progress'
            ) AS in_progress,

            SUM(
                status IN (
                    'resolved',
                    'closed'
                )
            ) AS resolved,

            SUM(
                priority = 'urgent'
                AND status NOT IN (
                    'resolved',
                    'closed',
                    'cancelled',
                    'rejected'
                )
            ) AS urgent

        FROM service_requests

        WHERE municipality_id = :municipality_id
    ");

    $stmt->execute([
        ':municipality_id' => $municipalityId
    ]);

    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    $stats['requests'] =
        (int) ($row['total'] ?? 0);

    $stats['submitted'] =
        (int) ($row['submitted'] ?? 0);

    $stats['in_progress'] =
        (int) ($row['in_progress'] ?? 0);

    $stats['resolved'] =
        (int) ($row['resolved'] ?? 0);

    $stats['urgent'] =
        (int) ($row['urgent'] ?? 0);


    /*
    |--------------------------------------------------------------------------
    | Recent Requests
    |--------------------------------------------------------------------------
    */

    $stmt = $pdo->prepare("
        SELECT
            sr.id,
            sr.reference_number,
            sr.subject,
            sr.priority,
            sr.status,
            sr.submitted_at,

            s.name AS service_name,

            CONCAT(
                u.first_name,
                ' ',
                u.last_name
            ) AS resident_name

        FROM service_requests sr

        INNER JOIN services s
            ON s.id = sr.service_id

        INNER JOIN users u
            ON u.id = sr.resident_id

        WHERE sr.municipality_id = :municipality_id

        ORDER BY sr.submitted_at DESC

        LIMIT 10
    ");

    $stmt->execute([
        ':municipality_id' => $municipalityId
    ]);

    $recentRequests =
        $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {

    error_log(
        'TownLink municipality dashboard error: ' .
        $e->getMessage()
    );

}

municipalityHeader(
    'Dashboard',
    'dashboard'
);

?>

<div class="container-fluid">

    <div class="d-flex justify-content-between align-items-center mb-4">

        <div>

            <h2 class="mb-1">
                Municipality Dashboard
            </h2>

            <p class="text-muted mb-0">
                Overview of your municipality's
                services and requests.
            </p>

        </div>

    </div>


    <!-- Statistics -->

    <div class="row g-4 mb-4">

        <div class="col-12 col-sm-6 col-xl-3">

            <div class="card shadow-sm h-100">

                <div class="card-body">

                    <h6 class="text-muted">
                        Departments
                    </h6>

                    <h2 class="fw-bold">
                        <?= $stats['departments'] ?>
                    </h2>

                    <a
                        href="departments/index.php"
                        class="btn btn-sm btn-outline-primary"
                    >
                        View Departments
                    </a>

                </div>

            </div>

        </div>


        <div class="col-12 col-sm-6 col-xl-3">

            <div class="card shadow-sm h-100">

                <div class="card-body">

                    <h6 class="text-muted">
                        Active Services
                    </h6>

                    <h2 class="fw-bold">
                        <?= $stats['services'] ?>
                    </h2>

                    <a
                        href="services/index.php"
                        class="btn btn-sm btn-outline-primary"
                    >
                        View Services
                    </a>

                </div>

            </div>

        </div>


        <div class="col-12 col-sm-6 col-xl-3">

            <div class="card shadow-sm h-100">

                <div class="card-body">

                    <h6 class="text-muted">
                        Categories
                    </h6>

                    <h2 class="fw-bold">
                        <?= $stats['categories'] ?>
                    </h2>

                    <a
                        href="categories/index.php"
                        class="btn btn-sm btn-outline-primary"
                    >
                        View Categories
                    </a>

                </div>

            </div>

        </div>


        <div class="col-12 col-sm-6 col-xl-3">

            <div class="card shadow-sm h-100">

                <div class="card-body">

                    <h6 class="text-muted">
                        Total Requests
                    </h6>

                    <h2 class="fw-bold">
                        <?= $stats['requests'] ?>
                    </h2>

                    <a
                        href="requests/index.php"
                        class="btn btn-sm btn-outline-primary"
                    >
                        View Requests
                    </a>

                </div>

            </div>

        </div>

    </div>


    <!-- Request Status -->

    <div class="row g-4 mb-4">

        <div class="col-12 col-md-4">

            <div class="card border-warning shadow-sm">

                <div class="card-body">

                    <h6 class="text-muted">
                        New Requests
                    </h6>

                    <h3 class="text-warning fw-bold">
                        <?= $stats['submitted'] ?>
                    </h3>

                    <span class="badge text-bg-warning">
                        Submitted
                    </span>

                </div>

            </div>

        </div>


        <div class="col-12 col-md-4">

            <div class="card border-primary shadow-sm">

                <div class="card-body">

                    <h6 class="text-muted">
                        In Progress
                    </h6>

                    <h3 class="text-primary fw-bold">
                        <?= $stats['in_progress'] ?>
                    </h3>

                    <span class="badge text-bg-primary">
                        In Progress
                    </span>

                </div>

            </div>

        </div>


        <div class="col-12 col-md-4">

            <div class="card border-success shadow-sm">

                <div class="card-body">

                    <h6 class="text-muted">
                        Resolved
                    </h6>

                    <h3 class="text-success fw-bold">
                        <?= $stats['resolved'] ?>
                    </h3>

                    <span class="badge text-bg-success">
                        Resolved
                    </span>

                </div>

            </div>

        </div>

    </div>


    <!-- Urgent Requests -->

    <div class="card border-danger shadow-sm mb-4">

        <div class="card-body">

            <div
                class="d-flex justify-content-between align-items-center"
            >

                <div>

                    <h5 class="card-title mb-1">
                        Urgent Open Requests
                    </h5>

                    <p class="text-muted mb-0">
                        Requests requiring urgent attention.
                    </p>

                </div>

                <span class="badge text-bg-danger fs-6">

                    <?= $stats['urgent'] ?>

                </span>

            </div>

        </div>

    </div>


    <!-- Recent Requests -->

    <div class="card shadow-sm">

        <div class="card-header bg-white">

            <h5 class="mb-0">
                Recent Requests
            </h5>

        </div>

        <div class="card-body p-0">

            <?php if (!$recentRequests): ?>

                <div class="p-4">

                    <div class="alert alert-info mb-0">

                        No service requests yet.

                    </div>

                </div>

            <?php else: ?>

                <div class="table-responsive">

                    <table class="table table-hover mb-0">

                        <thead class="table-light">

                            <tr>

                                <th>
                                    Reference
                                </th>

                                <th>
                                    Subject
                                </th>

                                <th>
                                    Resident
                                </th>

                                <th>
                                    Service
                                </th>

                                <th>
                                    Priority
                                </th>

                                <th>
                                    Status
                                </th>

                                <th>
                                    Action
                                </th>

                            </tr>

                        </thead>

                        <tbody>

                        <?php foreach (
                            $recentRequests
                            as $request
                        ): ?>

                            <tr>

                                <td>

                                    <strong>
                                        <?= e(
                                            $request[
                                                'reference_number'
                                            ]
                                        ) ?>
                                    </strong>

                                </td>

                                <td>

                                    <?= e(
                                        $request['subject']
                                    ) ?>

                                </td>

                                <td>

                                    <?= e(
                                        $request[
                                            'resident_name'
                                        ]
                                    ) ?>

                                </td>

                                <td>

                                    <?= e(
                                        $request[
                                            'service_name'
                                        ]
                                    ) ?>

                                </td>

                                <td>

                                    <?php

                                    $priorityClass =
                                        match (
                                            $request['priority']
                                        ) {

                                            'urgent' =>
                                                'danger',

                                            'high' =>
                                                'warning',

                                            'low' =>
                                                'secondary',

                                            default =>
                                                'primary'
                                        };

                                    ?>

                                    <span
                                        class="badge text-bg-<?= $priorityClass ?>"
                                    >
                                        <?= e(
                                            ucfirst(
                                                $request[
                                                    'priority'
                                                ]
                                            )
                                        ) ?>
                                    </span>

                                </td>

                                <td>

                                    <?php

                                    $statusClass =
                                        match (
                                            $request['status']
                                        ) {

                                            'resolved',
                                            'closed' =>
                                                'success',

                                            'rejected',
                                            'cancelled' =>
                                                'danger',

                                            'submitted',
                                            'pending' =>
                                                'warning',

                                            default =>
                                                'primary'
                                        };

                                    ?>

                                    <span
                                        class="badge text-bg-<?= $statusClass ?>"
                                    >
                                        <?= e(
                                            ucwords(
                                                str_replace(
                                                    '_',
                                                    ' ',
                                                    $request[
                                                        'status'
                                                    ]
                                                )
                                            )
                                        ) ?>
                                    </span>

                                </td>

                                <td>

                                    <a
                                        href="requests/view.php?id=<?= (int) $request['id'] ?>"
                                        class="btn btn-sm btn-primary"
                                    >
                                        View
                                    </a>

                                </td>

                            </tr>

                        <?php endforeach; ?>

                        </tbody>

                    </table>

                </div>

            <?php endif; ?>

        </div>

    </div>

</div>

<?php

municipalityFooter();