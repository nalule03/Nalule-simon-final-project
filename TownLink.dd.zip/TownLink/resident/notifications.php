<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| TownLink - Resident Notifications
|--------------------------------------------------------------------------
| Features:
| - Secure resident-only access
| - Resident-specific notifications
| - Read/unread status
| - Search and filters
| - Mark one or all notifications as read
| - Link to related service requests
| - Responsive layout
|--------------------------------------------------------------------------
*/

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

require_once __DIR__ . '/../app/config/database.php';

/*
|--------------------------------------------------------------------------
| 1. AUTHENTICATION
|--------------------------------------------------------------------------
*/

if (empty($_SESSION['user_id'])) {
    header('Location: ../public/login.php');
    exit;
}

if (($_SESSION['role'] ?? '') !== 'resident') {
    http_response_code(403);
    exit('Access denied.');
}

$userId = (int) $_SESSION['user_id'];

/*
|--------------------------------------------------------------------------
| 2. HELPERS
|--------------------------------------------------------------------------
*/

if (!function_exists('residentNotificationsEscape')) {
    function residentNotificationsEscape(mixed $value): string
    {
        return htmlspecialchars(
            (string) ($value ?? ''),
            ENT_QUOTES | ENT_SUBSTITUTE,
            'UTF-8'
        );
    }
}

function residentNotificationType(string $type): array
{
    $type = strtolower(trim($type));

    $types = [
        'success' => [
            'label' => 'Success',
            'icon' => '✓',
            'class' => 'success',
        ],
        'application' => [
            'label' => 'Application',
            'icon' => '▣',
            'class' => 'application',
        ],
        'request' => [
            'label' => 'Request update',
            'icon' => '↗',
            'class' => 'request',
        ],
        'status' => [
            'label' => 'Status update',
            'icon' => '↻',
            'class' => 'status',
        ],
        'announcement' => [
            'label' => 'Announcement',
            'icon' => '◈',
            'class' => 'announcement',
        ],
        'reminder' => [
            'label' => 'Reminder',
            'icon' => '◷',
            'class' => 'reminder',
        ],
        'warning' => [
            'label' => 'Important',
            'icon' => '!',
            'class' => 'warning',
        ],
        'info' => [
            'label' => 'Information',
            'icon' => 'i',
            'class' => 'info',
        ],
    ];

    return $types[$type] ?? [
        'label' => $type !== ''
            ? ucwords(str_replace('_', ' ', $type))
            : 'Notification',
        'icon' => '●',
        'class' => 'info',
    ];
}

function residentNotificationDate(string $date): string
{
    try {
        $created = new DateTimeImmutable($date);
        $now = new DateTimeImmutable('now');

        $seconds = $now->getTimestamp() - $created->getTimestamp();

        if ($seconds >= 0 && $seconds < 60) {
            return 'Just now';
        }

        if ($seconds >= 60 && $seconds < 3600) {
            return floor($seconds / 60) . ' min ago';
        }

        if ($seconds >= 3600 && $seconds < 86400) {
            return floor($seconds / 3600) . ' hr ago';
        }

        if ($seconds >= 86400 && $seconds < 172800) {
            return 'Yesterday';
        }

        return $created->format('d M Y, H:i');

    } catch (Throwable $e) {
        return $date;
    }
}

/*
|--------------------------------------------------------------------------
| 3. CSRF PROTECTION
|--------------------------------------------------------------------------
*/

if (empty($_SESSION['notifications_csrf_token'])) {
    $_SESSION['notifications_csrf_token'] = bin2hex(
        random_bytes(32)
    );
}

$csrfToken = (string) $_SESSION['notifications_csrf_token'];

/*
|--------------------------------------------------------------------------
| 4. INITIAL VALUES
|--------------------------------------------------------------------------
*/

$notifications = [];
$totalNotifications = 0;
$unreadCount = 0;
$readCount = 0;

$errorMessage = '';
$successMessage = '';

/*
|--------------------------------------------------------------------------
| 5. HANDLE NOTIFICATION ACTIONS
|--------------------------------------------------------------------------
*/

try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $submittedToken = (string) (
            $_POST['csrf_token'] ?? ''
        );

        if (!hash_equals($csrfToken, $submittedToken)) {
            http_response_code(403);
            exit('Invalid or expired form token. Please refresh the page.');
        }

        $action = (string) ($_POST['action'] ?? '');

        if ($action === 'mark_read') {
            $notificationId = filter_var(
                $_POST['notification_id'] ?? null,
                FILTER_VALIDATE_INT
            );

            if (!$notificationId || $notificationId < 1) {
                throw new RuntimeException(
                    'Invalid notification selected.'
                );
            }

            $stmt = $pdo->prepare("
                UPDATE notifications
                SET
                    is_read = 1,
                    read_at = COALESCE(read_at, CURRENT_TIMESTAMP)
                WHERE id = :notification_id
                  AND user_id = :user_id
                  AND is_read = 0
            ");

            $stmt->execute([
                ':notification_id' => $notificationId,
                ':user_id' => $userId,
            ]);

            $successMessage = $stmt->rowCount() > 0
                ? 'Notification marked as read.'
                : 'The notification is already read or is unavailable.';

        } elseif ($action === 'mark_all_read') {
            $stmt = $pdo->prepare("
                UPDATE notifications
                SET
                    is_read = 1,
                    read_at = COALESCE(read_at, CURRENT_TIMESTAMP)
                WHERE user_id = :user_id
                  AND is_read = 0
            ");

            $stmt->execute([
                ':user_id' => $userId,
            ]);

            $successMessage = 'All your notifications have been marked as read.';

        } else {
            throw new RuntimeException(
                'The requested action is not supported.'
            );
        }
    }

    /*
    |--------------------------------------------------------------------------
    | 6. LOAD NOTIFICATIONS
    |--------------------------------------------------------------------------
    |
    | The user_id condition is essential. Residents must never
    | be able to retrieve another resident's notifications.
    |--------------------------------------------------------------------------
    */

    $stmt = $pdo->prepare("
        SELECT
            id,
            user_id,
            municipality_id,
            request_id,
            title,
            message,
            type,
            is_read,
            read_at,
            created_at
        FROM notifications
        WHERE user_id = :user_id
        ORDER BY
            is_read ASC,
            created_at DESC,
            id DESC
    ");

    $stmt->execute([
        ':user_id' => $userId,
    ]);

    $notifications = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $totalNotifications = count($notifications);

    foreach ($notifications as $notification) {
        if ((int) $notification['is_read'] === 1) {
            $readCount++;
        } else {
            $unreadCount++;
        }
    }

} catch (RuntimeException $e) {
    $errorMessage = $e->getMessage();

} catch (Throwable $e) {
    error_log(
        'TownLink resident notifications error: ' .
        $e->getMessage()
    );

    $errorMessage =
        'We could not load your notifications. Please try again later.';
}

/*
|--------------------------------------------------------------------------
| 7. PAGE CONFIGURATION
|--------------------------------------------------------------------------
*/

$filter = (string) ($_GET['filter'] ?? 'all');

if (!in_array($filter, ['all', 'unread', 'read'], true)) {
    $filter = 'all';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1"
    >

    <meta
        name="description"
        content="View your TownLink municipal notifications and service updates."
    >

    <title>Notifications | TownLink</title>
     <link rel="stylesheet" href="../assets/vendor/bootstrap-icons/bootstrap-icons.css">

    <style>
        :root {
            --primary: #176b52;
            --primary-dark: #10523f;
            --primary-soft: #e8f5ef;
            --page: #f4f7f6;
            --surface: #ffffff;
            --text: #20332b;
            --muted: #718078;
            --border: #e1e9e4;
            --danger: #a12626;
            --radius: 14px;
        }

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            background: var(--page);
            color: var(--text);
            font-family: Arial, Helvetica, sans-serif;
            line-height: 1.6;
        }

        button,
        input,
        select {
            font: inherit;
        }

        [hidden] {
            display: none !important;
        }

        .container {
            width: min(1050px, 100%);
            margin: 0 auto;
            padding: 30px 20px 45px;
        }

        .page-header {
            display: flex;
            align-items: flex-start;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 18px;
            margin-bottom: 25px;
        }

        .page-header h1 {
            margin: 0 0 6px;
            font-size: clamp(26px, 4vw, 34px);
            line-height: 1.25;
        }

        .page-header p {
            margin: 0;
            color: var(--muted);
        }

        .header-icon {
            display: grid;
            width: 55px;
            height: 55px;
            flex-shrink: 0;
            place-items: center;
            border-radius: 15px;
            background: var(--primary-soft);
            color: var(--primary);
            font-size: 28px;
        }

        .summary {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 15px;
            margin-bottom: 27px;
        }

        .summary-card {
            padding: 19px;
            border: 1px solid var(--border);
            border-radius: var(--radius);
            background: var(--surface);
        }

        .summary-card span {
            display: block;
            color: var(--muted);
            font-size: 13px;
        }

        .summary-card strong {
            display: block;
            margin-top: 5px;
            font-size: 27px;
        }

        .summary-card.unread strong {
            color: var(--primary);
        }

        .panel {
            overflow: hidden;
            border: 1px solid var(--border);
            border-radius: var(--radius);
            background: var(--surface);
        }

        .panel-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 12px;
            padding: 21px;
            border-bottom: 1px solid var(--border);
        }

        .panel-header h2 {
            margin: 0;
            font-size: 21px;
        }

        .mark-all-button {
            padding: 9px 12px;
            border: 1px solid var(--primary);
            border-radius: 8px;
            background: #ffffff;
            color: var(--primary);
            font-size: 13px;
            font-weight: 700;
            cursor: pointer;
        }

        .mark-all-button:hover {
            background: var(--primary-soft);
        }

        .toolbar {
            display: grid;
            grid-template-columns: minmax(0, 1fr) 180px;
            gap: 12px;
            padding: 18px 21px;
            border-bottom: 1px solid var(--border);
        }

        .toolbar input,
        .toolbar select {
            width: 100%;
            min-height: 44px;
            padding: 10px 12px;
            border: 1px solid var(--border);
            border-radius: 8px;
            background: #ffffff;
            color: var(--text);
        }

        input:focus-visible,
        select:focus-visible,
        button:focus-visible,
        a:focus-visible {
            outline: 3px solid #9bd8bf;
            outline-offset: 2px;
        }

        .notice {
            margin: 18px 21px 0;
            padding: 12px 14px;
            border: 1px solid #b7dfc8;
            border-radius: 8px;
            background: #effaf3;
            color: #17633f;
            font-size: 14px;
        }

        .notice.error {
            border-color: #f0caca;
            background: #fff3f3;
            color: var(--danger);
        }

        .notification-list {
            display: flex;
            flex-direction: column;
        }

        .notification {
            display: grid;
            grid-template-columns: 43px minmax(0, 1fr);
            gap: 14px;
            padding: 21px;
            border-bottom: 1px solid var(--border);
            transition: background .15s;
        }

        .notification:last-child {
            border-bottom: 0;
        }

        .notification.unread {
            background: #f7fcf9;
        }

        .notification-icon {
            display: grid;
            width: 42px;
            height: 42px;
            place-items: center;
            border-radius: 12px;
            background: var(--primary-soft);
            color: var(--primary);
            font-size: 19px;
            font-weight: 700;
        }

        .notification-icon.warning {
            background: #fff4dd;
            color: #925c00;
        }

        .notification-icon.application {
            background: #edf0ff;
            color: #3e50a1;
        }

        .notification-icon.announcement {
            background: #f3eefe;
            color: #7042a3;
        }

        .notification-icon.reminder {
            background: #fff0e5;
            color: #9c4b0a;
        }

        .notification-content {
            min-width: 0;
        }

        .notification-heading {
            display: flex;
            align-items: flex-start;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 8px;
        }

        .notification-heading h3 {
            margin: 0;
            font-size: 16px;
            line-height: 1.45;
            overflow-wrap: anywhere;
        }

        .unread-dot {
            display: inline-block;
            width: 8px;
            height: 8px;
            margin-left: 5px;
            border-radius: 50%;
            background: #198754;
            vertical-align: middle;
        }

        .type-label {
            display: inline-block;
            margin-top: 7px;
            padding: 3px 8px;
            border-radius: 20px;
            background: #eef3f0;
            color: #52655b;
            font-size: 11px;
            font-weight: 700;
        }

        .notification-message {
            margin: 10px 0;
            color: #53645b;
            font-size: 14px;
            white-space: pre-line;
            overflow-wrap: anywhere;
        }

        .notification-footer {
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 10px;
            margin-top: 12px;
        }

        .notification-date {
            color: var(--muted);
            font-size: 12px;
        }

        .notification-actions {
            display: flex;
            align-items: center;
            flex-wrap: wrap;
            gap: 12px;
        }

        .action-link,
        .action-button {
            padding: 0;
            border: 0;
            background: transparent;
            color: var(--primary);
            font-size: 12px;
            font-weight: 700;
            text-decoration: none;
            cursor: pointer;
        }

        .action-link:hover,
        .action-button:hover {
            text-decoration: underline;
        }

        .empty-state {
            padding: 48px 22px;
            text-align: center;
        }

        .empty-icon {
            margin-bottom: 12px;
            font-size: 43px;
        }

        .empty-state h3 {
            margin: 0 0 8px;
        }

        .empty-state p {
            max-width: 450px;
            margin: 0 auto;
            color: var(--muted);
            font-size: 14px;
        }

        .footer {
            padding: 23px;
            color: var(--muted);
            text-align: center;
            font-size: 12px;
        }

        @media (max-width: 650px) {
            .container {
                padding: 22px 13px 32px;
            }

            .summary {
                grid-template-columns: 1fr;
                gap: 10px;
            }

            .summary-card {
                padding: 14px 16px;
            }

            .summary-card strong {
                font-size: 23px;
            }

            .toolbar {
                grid-template-columns: 1fr;
                padding: 14px;
            }

            .panel-header {
                padding: 16px;
            }

            .notification {
                grid-template-columns: 35px minmax(0, 1fr);
                gap: 11px;
                padding: 17px 13px;
            }

            .notification-icon {
                width: 35px;
                height: 35px;
                border-radius: 10px;
                font-size: 16px;
            }

            .notification-heading h3 {
                font-size: 15px;
            }

            .notification-footer {
                align-items: flex-start;
                flex-direction: column;
            }
        }

        @media (prefers-reduced-motion: reduce) {
            *,
            *::before,
            *::after {
                transition: none !important;
            }
        }
    </style>
</head>

<body>

<?php require_once __DIR__ . '/_navbar.php'; ?>

<main class="container">

    <header class="page-header">
        <div>
            <h1>Notifications</h1>
            <p>
                Keep up with your municipal updates, application
                progress and important messages from TownLink.
            </p>
        </div>

        <div class="header-icon" aria-hidden="true">♧</div>
    </header>

    <?php if ($errorMessage !== ''): ?>

        <div class="notice error" role="alert">
            <?= residentNotificationsEscape($errorMessage) ?>
        </div>

    <?php else: ?>

        <section class="summary" aria-label="Notification summary">

            <div class="summary-card">
                <span>Total notifications</span>
                <strong><?= number_format($totalNotifications) ?></strong>
            </div>

            <div class="summary-card unread">
                <span>Unread notifications</span>
                <strong><?= number_format($unreadCount) ?></strong>
            </div>

            <div class="summary-card">
                <span>Read notifications</span>
                <strong><?= number_format($readCount) ?></strong>
            </div>

        </section>

        <section class="panel" aria-labelledby="notificationHeading">

            <div class="panel-header">
                <h2 id="notificationHeading">Your inbox</h2>

                <?php if ($unreadCount > 0): ?>
                    <form method="post">
                        <input
                            type="hidden"
                            name="csrf_token"
                            value="<?= residentNotificationsEscape($csrfToken) ?>"
                        >

                        <input
                            type="hidden"
                            name="action"
                            value="mark_all_read"
                        >

                        <button
                            type="submit"
                            class="mark-all-button"
                        >
                            Mark all as read
                        </button>
                    </form>
                <?php endif; ?>
            </div>

            <?php if ($successMessage !== ''): ?>
                <div class="notice" role="status">
                    <?= residentNotificationsEscape($successMessage) ?>
                </div>
            <?php endif; ?>

            <div class="toolbar">
                <input
                    type="search"
                    id="notificationSearch"
                    placeholder="Search your notifications..."
                    aria-label="Search notifications"
                    autocomplete="off"
                >

                <select
                    id="notificationFilter"
                    aria-label="Filter notifications"
                >
                    <option value="all" <?= $filter === 'all' ? 'selected' : '' ?>>
                        All notifications
                    </option>

                    <option value="unread" <?= $filter === 'unread' ? 'selected' : '' ?>>
                        Unread only
                    </option>

                    <option value="read" <?= $filter === 'read' ? 'selected' : '' ?>>
                        Read only
                    </option>
                </select>
            </div>

            <?php if (!$notifications): ?>

                <div class="empty-state">
                    <div class="empty-icon" aria-hidden="true">♧</div>

                    <h3>You're all caught up</h3>

                    <p>
                        You don't have any notifications yet.
                        Important messages and updates will appear here
                        when they are sent to your account.
                    </p>
                </div>

            <?php else: ?>

                <div class="notification-list" id="notificationList">

                    <?php foreach ($notifications as $notification): ?>

                        <?php
                        $isRead = (int) $notification['is_read'] === 1;

                        $typeInfo = residentNotificationType(
                            (string) ($notification['type'] ?? '')
                        );

                        $title = (string) $notification['title'];
                        $message = (string) $notification['message'];

                        $searchText = strtolower(
                            $title . ' ' .
                            $message . ' ' .
                            $typeInfo['label']
                        );

                        $requestId = $notification['request_id'] !== null
                            ? (int) $notification['request_id']
                            : 0;

                        $createdAt = (string) $notification['created_at'];
                        ?>

                        <article
                            class="notification <?= $isRead ? 'read' : 'unread' ?>"
                            data-status="<?= $isRead ? 'read' : 'unread' ?>"
                            data-search="<?= residentNotificationsEscape($searchText) ?>"
                        >

                            <div
                                class="notification-icon <?= residentNotificationsEscape($typeInfo['class']) ?>"
                                aria-hidden="true"
                            >
                                <?= residentNotificationsEscape($typeInfo['icon']) ?>
                            </div>

                            <div class="notification-content">

                                <div class="notification-heading">
                                    <h3>
                                        <?= residentNotificationsEscape($title) ?>

                                        <?php if (!$isRead): ?>
                                            <span
                                                class="unread-dot"
                                                aria-label="Unread"
                                            ></span>
                                        <?php endif; ?>
                                    </h3>
                                </div>

                                <span class="type-label">
                                    <?= residentNotificationsEscape($typeInfo['label']) ?>
                                </span>

                                <p class="notification-message"><?= residentNotificationsEscape($message) ?></p>

                                <div class="notification-footer">

                                    <time
                                        class="notification-date"
                                        datetime="<?= residentNotificationsEscape($createdAt) ?>"
                                        title="<?= residentNotificationsEscape($createdAt) ?>"
                                    >
                                        <?= residentNotificationsEscape(
                                            residentNotificationDate($createdAt)
                                        ) ?>
                                    </time>

                                    <div class="notification-actions">

                                        <?php if ($requestId > 0): ?>
                                            <a
                                                class="action-link"
                                                href="my-requests.php"
                                            >
                                                View My Requests
                                            </a>
                                        <?php endif; ?>

                                        <?php if (!$isRead): ?>
                                            <form method="post">
                                                <input
                                                    type="hidden"
                                                    name="csrf_token"
                                                    value="<?= residentNotificationsEscape($csrfToken) ?>"
                                                >

                                                <input
                                                    type="hidden"
                                                    name="action"
                                                    value="mark_read"
                                                >

                                                <input
                                                    type="hidden"
                                                    name="notification_id"
                                                    value="<?= (int) $notification['id'] ?>"
                                                >

                                                <button
                                                    type="submit"
                                                    class="action-button"
                                                >
                                                    Mark as read
                                                </button>
                                            </form>
                                        <?php endif; ?>

                                    </div>

                                </div>

                            </div>

                        </article>

                    <?php endforeach; ?>

                    <div
                        class="empty-state"
                        id="noMatchingNotifications"
                        hidden
                    >
                        <div class="empty-icon" aria-hidden="true">⌕</div>

                        <h3>No matching notifications</h3>

                        <p>
                            Try another search term or change your filter.
                        </p>
                    </div>

                </div>

            <?php endif; ?>

        </section>

    <?php endif; ?>

</main>

<footer class="footer">
    &copy; <?= date('Y') ?> TownLink.
    Connecting Namibia's communities.
</footer>

<script>
(function () {
    'use strict';

    const searchInput = document.getElementById('notificationSearch');
    const filterSelect = document.getElementById('notificationFilter');

    const notifications = Array.from(
        document.querySelectorAll('.notification')
    );

    const noResults = document.getElementById(
        'noMatchingNotifications'
    );

    function filterNotifications() {
        if (!searchInput || !filterSelect) {
            return;
        }

        const query = searchInput.value.trim().toLowerCase();
        const filter = filterSelect.value;

        let visible = 0;

        notifications.forEach(function (notification) {
            const text = notification.dataset.search || '';
            const status = notification.dataset.status || '';

            const matchesSearch = text.includes(query);

            const matchesFilter =
                filter === 'all' || status === filter;

            const matches = matchesSearch && matchesFilter;

            notification.hidden = !matches;

            if (matches) {
                visible++;
            }
        });

        if (noResults) {
            noResults.hidden = visible !== 0;
        }
    }

    if (searchInput) {
        searchInput.addEventListener(
            'input',
            filterNotifications
        );
    }

    if (filterSelect) {
        filterSelect.addEventListener(
            'change',
            filterNotifications
        );
    }

    filterNotifications();
})();
</script>

</body>
</html>