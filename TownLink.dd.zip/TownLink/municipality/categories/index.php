<?php

declare(strict_types=1);

require_once __DIR__ . '/../auth.php';
require_once __DIR__ . '/../layout.php';

$stmt = $pdo->prepare("
    SELECT
        c.id,
        c.name,
        c.description,
        c.status,
        c.created_at,

        (
            SELECT COUNT(*)
            FROM services s
            WHERE s.category_id = c.id
        ) AS service_count

    FROM service_categories c

    WHERE c.municipality_id = :municipality_id

    ORDER BY c.name ASC
");

$stmt->execute([
    ':municipality_id' => $municipalityId
]);

$categories =
    $stmt->fetchAll(PDO::FETCH_ASSOC);

municipalityHeader(
    'Service Categories',
    'categories'
);

?>

<div class="page-header">

    <div>
        <h2>Service Categories</h2>
        <p>Organise municipal services into categories.</p>
    </div>

    <?php if (isMunicipalityAdmin()): ?>

        <a
            class="button"
            href="create.php"
        >
            + Add Category
        </a>

    <?php endif; ?>

</div>

<div class="card">

    <?php if (!$categories): ?>

        <p class="muted">
            No service categories have been created.
        </p>

    <?php else: ?>

        <table>

            <thead>

            <tr>
                <th>Name</th>
                <th>Description</th>
                <th>Services</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>

            </thead>

            <tbody>

            <?php foreach ($categories as $category): ?>

                <tr>

                    <td>
                        <strong>
                            <?= e($category['name']) ?>
                        </strong>
                    </td>

                    <td>
                        <?= e(
                            $category['description']
                        ) ?>
                    </td>

                    <td>
                        <?= (int) $category['service_count'] ?>
                    </td>

                    <td>

                        <span
                            class="badge <?= e($category['status']) ?>"
                        >
                            <?= e(
                                ucfirst(
                                    $category['status']
                                )
                            ) ?>
                        </span>

                    </td>

                    <td>

                        <?php if (isMunicipalityAdmin()): ?>

                            <a
                                class="button"
                                href="edit.php?id=<?= (int) $category['id'] ?>"
                            >
                                Edit
                            </a>

                        <?php endif; ?>

                    </td>

                </tr>

            <?php endforeach; ?>

            </tbody>

        </table>

    <?php endif; ?>

</div>

<?php

municipalityFooter();
