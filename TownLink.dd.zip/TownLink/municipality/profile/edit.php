<?php

declare(strict_types=1);

require_once __DIR__ . '/../auth.php';
require_once __DIR__ . '/../layout.php';

requireMunicipalityAdmin();

municipalityHeader(
    'Edit Municipality Profile',
    'profile'
);

?>

<div class="container-fluid">

    <div class="d-flex justify-content-between align-items-center mb-4">

        <div>

            <h2 class="mb-1">
                Edit Municipality Profile
            </h2>

            <p class="text-muted mb-0">
                Update your municipality information.
            </p>

        </div>

        <a
            class="btn btn-secondary"
            href="index.php"
        >
            Cancel
        </a>

    </div>


    <div class="card shadow-sm">

        <div class="card-header bg-white">

            <h5 class="mb-0">
                Municipality Information
            </h5>

        </div>

        <div class="card-body">

            <form
                method="post"
                action="update.php"
            >

                <input
                    type="hidden"
                    name="csrf_token"
                    value="<?= e(csrfToken()) ?>"
                >


                <div class="row g-3">

                    <div class="col-md-6">

                        <label
                            for="name"
                            class="form-label"
                        >
                            Municipality Name
                        </label>

                        <input
                            type="text"
                            class="form-control"
                            id="name"
                            name="name"
                            value="<?= e(
                                $currentMunicipality['name']
                            ) ?>"
                            required
                        >

                    </div>


                    <div class="col-md-6">

                        <label
                            for="code"
                            class="form-label"
                        >
                            Municipality Code
                        </label>

                        <input
                            type="text"
                            class="form-control"
                            id="code"
                            name="code"
                            value="<?= e(
                                $currentMunicipality['code']
                            ) ?>"
                            required
                        >

                    </div>


                    <div class="col-md-6">

                        <label
                            for="type"
                            class="form-label"
                        >
                            Municipality Type
                        </label>

                        <select
                            class="form-select"
                            id="type"
                            name="type"
                            required
                        >

                            <?php

                            $types = [
                                'municipality',
                                'town',
                                'village',
                                'city'
                            ];

                            foreach ($types as $type):

                            ?>

                                <option
                                    value="<?= e($type) ?>"
                                    <?= $currentMunicipality['type'] === $type
                                        ? 'selected'
                                        : ''
                                    ?>
                                >
                                    <?= e(
                                        ucfirst($type)
                                    ) ?>
                                </option>

                            <?php endforeach; ?>

                        </select>

                    </div>


                    <div class="col-md-6">

                        <label
                            for="region"
                            class="form-label"
                        >
                            Region
                        </label>

                        <input
                            type="text"
                            class="form-control"
                            id="region"
                            name="region"
                            value="<?= e(
                                $currentMunicipality['region']
                            ) ?>"
                        >

                    </div>


                    <div class="col-12">

                        <label
                            for="address"
                            class="form-label"
                        >
                            Address
                        </label>

                        <textarea
                            class="form-control"
                            id="address"
                            name="address"
                            rows="3"
                        ><?= e(
                            $currentMunicipality['address']
                        ) ?></textarea>

                    </div>


                    <div class="col-md-6">

                        <label
                            for="phone"
                            class="form-label"
                        >
                            Phone
                        </label>

                        <input
                            type="text"
                            class="form-control"
                            id="phone"
                            name="phone"
                            value="<?= e(
                                $currentMunicipality['phone']
                            ) ?>"
                        >

                    </div>


                    <div class="col-md-6">

                        <label
                            for="email"
                            class="form-label"
                        >
                            Email
                        </label>

                        <input
                            type="email"
                            class="form-control"
                            id="email"
                            name="email"
                            value="<?= e(
                                $currentMunicipality['email']
                            ) ?>"
                        >

                    </div>


                    <div class="col-12">

                        <label
                            for="website"
                            class="form-label"
                        >
                            Website
                        </label>

                        <input
                            type="url"
                            class="form-control"
                            id="website"
                            name="website"
                            value="<?= e(
                                $currentMunicipality['website']
                            ) ?>"
                            placeholder="https://example.com"
                        >

                    </div>

                </div>


                <div class="d-flex gap-2 mt-4">

                    <a
                        class="btn btn-secondary"
                        href="index.php"
                    >
                        Cancel
                    </a>

                    <button
                        type="submit"
                        class="btn btn-primary"
                        href="update.php"
                    >
                        Save Changes
                    </button>

                </div>

            </form>

        </div>

    </div>

</div>

<?php

municipalityFooter();