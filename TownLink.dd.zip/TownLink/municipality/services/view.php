<?php

declare(strict_types=1);

require_once __DIR__ . '/../auth.php';
require_once __DIR__ . '/../layout.php';

$id = filter_input(
    INPUT_GET,
    'id',
    FILTER_VALIDATE_INT
);

if (!$id) {
    http_response_code(400);
    exit('Invalid service.');
}

$stmt = $pdo->prepare("
    SELECT
        s.*,
        d.name AS department_name,
        d.code AS department_code,
        c.name AS category_name

    FROM services s

    INNER JOIN departments d
        ON d.id = s.department_id

    LEFT JOIN service_categories c
        ON c.id = s.category_id

    WHERE s.id = :id
    AND s.municipality_id = :municipality_id

    LIMIT 1
");

$stmt->execute([
    ':id' => $id,
    ':municipality_id' => $municipalityId
]);

$service =
    $stmt->fetch(PDO::FETCH_ASSOC);

if (!$service) {
    http_response_code(404);
    exit('Service not found.');
}

municipalityHeader(
    'Service',
    'services'
);

?>

<div class="page-header">

    <div>
        <h2><?= e($service['name']) ?></h2>

        <p>
            <?= e(
                $service['department_name']
            ) ?>
        </p>
    </div>

    <div class="actions">

        <?php if (isMunicipalityAdmin()): ?>

            <a
                class="button"
                href="edit.php?id=<?= (int) $id ?>"
            >
                Edit
            </a>

        <?php endif; ?>

        <a
            class="button secondary"
            href="index.php"
        >
            Back
        </a>

    </div>

</div>

<div class="card">

    <div class="detail-grid">

        <div class="detail-label">Service</div>
        <div><?= e($service['name']) ?></div>

        <div class="detail-label">Department</div>
        <div>
            <?= e($service['department_name']) ?>
            (<?= e($service['department_code']) ?>)
        </div>

        <div class="detail-label">Category</div>
        <div>
            <?= e(
                $service['category_name']
            ) ?: 'Uncategorised' ?>
        </div>

        <div class="detail-label">Description</div>
        <div>
            <?= nl2br(
                e($service['description'])
            ) ?: 'No description.' ?>
        </div>

        <div class="detail-label">Instructions</div>
        <div>
            <?= nl2br(
                e($service['instructions'])
            ) ?: 'No instructions.' ?>
        </div>

        <div class="detail-label">
            Estimated Days
        </div>

        <div>
            <?= $service['estimated_days'] !== null
                ? (int) $service['estimated_days'] . ' days'
                : 'Not specified'
            ?>
        </div>

        <div class="detail-label">Status</div>

        <div>
            <span
                class="badge <?= e($service['status']) ?>"
            >
                <?= e(
                    ucfirst(
                        $service['status']
                    )
                ) ?>
            </span>
        </div>

    </div>

</div>

<?php

municipalityFooter();
