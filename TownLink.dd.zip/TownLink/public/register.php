<?php

declare(strict_types=1);

session_start();

require_once __DIR__ . '/../app/config/database.php';

$message = '';
$messageType = '';

$firstName = '';
$lastName = '';
$email = '';
$phone = '';
$municipalityId = '';
$municipalities = [];

function e($value): string
{
    return htmlspecialchars(
        (string)($value ?? ''),
        ENT_QUOTES,
        'UTF-8'
    );
}

/*
|--------------------------------------------------------------------------
| Load active municipalities
|--------------------------------------------------------------------------
*/

try {

    $stmt = $pdo->query("
        SELECT id, name
        FROM municipalities
        WHERE status = 'active'
        ORDER BY name ASC
    ");

    $municipalities = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $exception) {

    error_log(
        'TownLink municipality loading error: ' .
        $exception->getMessage()
    );

    $message = 'Unable to load municipalities right now.';
    $messageType = 'error';
}

/*
|--------------------------------------------------------------------------
| Registration
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $firstName = trim((string)($_POST['first_name'] ?? ''));
    $lastName = trim((string)($_POST['last_name'] ?? ''));
    $email = trim((string)($_POST['email'] ?? ''));
    $phone = trim((string)($_POST['phone'] ?? ''));
    $password = (string)($_POST['password'] ?? '');

    $municipalityInput = filter_var(
        $_POST['municipality_id'] ?? null,
        FILTER_VALIDATE_INT
    );

    $municipalityId = $municipalityInput !== false
        && $municipalityInput !== null
        && $municipalityInput > 0
            ? $municipalityInput
            : '';

    if (
        $firstName === '' ||
        $lastName === '' ||
        $email === '' ||
        $password === '' ||
        $municipalityId === ''
    ) {

        $message = 'Please complete all required fields.';
        $messageType = 'error';

    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

        $message = 'Please enter a valid email address.';
        $messageType = 'error';

    } elseif (strlen($firstName) > 100 || strlen($lastName) > 100) {

        $message = 'Your name is too long.';
        $messageType = 'error';

    } elseif (strlen($email) > 150) {

        $message = 'Your email address is too long.';
        $messageType = 'error';

    } elseif (strlen($phone) > 50) {

        $message = 'Phone number is too long.';
        $messageType = 'error';

    } elseif (strlen($password) < 8) {

        $message = 'Password must be at least 8 characters.';
        $messageType = 'error';

    } else {

        try {

            /*
            |--------------------------------------------------------------------------
            | Verify municipality
            |--------------------------------------------------------------------------
            */

            $municipalityStmt = $pdo->prepare("
                SELECT id
                FROM municipalities
                WHERE id = :id
                  AND status = 'active'
                LIMIT 1
            ");

            $municipalityStmt->execute([
                ':id' => $municipalityId
            ]);

            if (!$municipalityStmt->fetch()) {

                $message = 'Please select a valid municipality.';
                $messageType = 'error';

            } else {

                /*
                |--------------------------------------------------------------------------
                | Check email
                |--------------------------------------------------------------------------
                */

                $emailStmt = $pdo->prepare("
                    SELECT id
                    FROM users
                    WHERE email = :email
                    LIMIT 1
                ");

                $emailStmt->execute([
                    ':email' => $email
                ]);

                if ($emailStmt->fetch()) {

                    $message =
                        'An account with that email already exists.';

                    $messageType = 'error';

                } else {

                    /*
                    |--------------------------------------------------------------------------
                    | Create resident account
                    |--------------------------------------------------------------------------
                    */

                    $passwordHash = password_hash(
                        $password,
                        PASSWORD_DEFAULT
                    );

                    $insertStmt = $pdo->prepare("
                        INSERT INTO users
                        (
                            municipality_id,
                            department_id,
                            first_name,
                            last_name,
                            email,
                            phone,
                            password_hash,
                            role,
                            status
                        )
                        VALUES
                        (
                            :municipality_id,
                            NULL,
                            :first_name,
                            :last_name,
                            :email,
                            :phone,
                            :password_hash,
                            'resident',
                            'active'
                        )
                    ");

                    $insertStmt->execute([
                        ':municipality_id' => $municipalityId,
                        ':first_name' => $firstName,
                        ':last_name' => $lastName,
                        ':email' => $email,
                        ':phone' => $phone !== '' ? $phone : null,
                        ':password_hash' => $passwordHash
                    ]);

                    $userId = (int)$pdo->lastInsertId();

                    /*
                    |--------------------------------------------------------------------------
                    | Audit registration
                    |--------------------------------------------------------------------------
                    */

                    try {

                        $auditStmt = $pdo->prepare("
                            INSERT INTO audit_logs
                            (
                                municipality_id,
                                user_id,
                                action,
                                entity_type,
                                entity_id,
                                description,
                                ip_address,
                                user_agent
                            )
                            VALUES
                            (
                                :municipality_id,
                                :user_id,
                                'registration',
                                'user',
                                :entity_id,
                                'Resident account created.',
                                :ip_address,
                                :user_agent
                            )
                        ");

                        $auditStmt->execute([
                            ':municipality_id' => $municipalityId,
                            ':user_id' => $userId,
                            ':entity_id' => $userId,
                            ':ip_address' => $_SERVER['REMOTE_ADDR'] ?? null,
                            ':user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? null
                        ]);

                    } catch (PDOException $auditError) {

                        error_log(
                            'TownLink registration audit error: ' .
                            $auditError->getMessage()
                        );
                    }

                    $message =
                        'Your resident account has been created successfully. You can now sign in.';

                    $messageType = 'success';

                    $firstName = '';
                    $lastName = '';
                    $email = '';
                    $phone = '';
                    $municipalityId = '';
                }
            }

        } catch (PDOException $exception) {

            error_log(
                'TownLink registration error: ' .
                $exception->getMessage()
            );

            $message = 'Unable to create your account right now.';
            $messageType = 'error';
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <meta
        name="description"
        content="Create your TownLink Namibia resident account and connect with your municipality."
    >

    <title>Register | TownLink Namibia</title>

    <link
        rel="stylesheet"
        href="../assets/vendor/bootstrap/css/bootstrap.min.css"
    >

    <link
        rel="stylesheet"
        href="../assets/vendor/bootstrap-icons/bootstrap-icons.css"
    >

    <style>
        :root {
            --green: #176b52;
            --green-dark: #123b32;
            --green-light: #e8f5ef;
            --text: #182b25;
            --muted: #718078;
            --border: #e1e9e5;
            --background: #f4f7f6;
        }

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: "Segoe UI", Arial, sans-serif;
            color: var(--text);
            background: var(--background);
            min-height: 100vh;
        }

        a {
            color: var(--green);
            text-decoration: none;
        }

        a:hover {
            color: var(--green-dark);
        }

        /* Navigation */

        .townlink-navbar {
            min-height: 76px;
            background: #fff;
            border-bottom: 1px solid var(--border);
            box-shadow: 0 3px 16px rgba(18, 59, 50, .045);
        }

        .brand {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            color: var(--green-dark);
            font-size: 1.4rem;
            font-weight: 800;
        }

        .brand:hover {
            color: var(--green-dark);
        }

        .brand-icon {
            width: 42px;
            height: 42px;
            display: grid;
            place-items: center;
            border-radius: 12px;
            background: var(--green-light);
            color: var(--green);
            font-size: 22px;
        }

        .brand-name span {
            color: var(--green);
        }

        .nav-home {
            color: #43534b;
            font-size: .9rem;
            font-weight: 600;
        }

        /* Registration layout */

        .register-section {
            min-height: calc(100vh - 76px);
            display: flex;
            align-items: center;
            padding: 38px 0;
        }

        .register-wrapper {
            width: 100%;
            max-width: 1100px;
            margin: auto;
            overflow: hidden;
            background: #fff;
            border: 1px solid var(--border);
            border-radius: 22px;
            box-shadow: 0 12px 40px rgba(18, 59, 50, .07);
        }

        .register-row {
            min-height: 650px;
        }

/* Picture panel */

.register-picture {
    position: relative;
    min-height: 650px;
    display: flex;
    align-items: flex-end;
    padding: 42px;
    color: #fff;
    background-color: var(--green-dark);

    background-image:
        linear-gradient(
            180deg,
            rgba(18, 59, 50, .08),
            rgba(18, 59, 50, .90)
        ),
        url("muni pic.jpg");

    background-position: center;
    background-size: cover;
    background-repeat: no-repeat;
}

        .picture-content {
            max-width: 400px;
        }

        .picture-label {
            display: inline-block;
            padding: 7px 12px;
            margin-bottom: 16px;
            border: 1px solid rgba(255,255,255,.35);
            border-radius: 30px;
            background: rgba(255,255,255,.12);
            font-size: .82rem;
            font-weight: 600;
        }

        .picture-content h2 {
            margin-bottom: 14px;
            font-size: clamp(1.8rem, 3vw, 2.6rem);
            font-weight: 800;
            line-height: 1.2;
        }

        .picture-content p {
            margin: 0;
            color: rgba(255,255,255,.88);
            line-height: 1.8;
        }

        /* Form */

        .register-form-area {
            display: flex;
            align-items: center;
            padding: 38px 42px;
        }

        .register-form-inner {
            width: 100%;
            max-width: 430px;
            margin: auto;
        }

        .welcome-icon {
            width: 50px;
            height: 50px;
            display: grid;
            place-items: center;
            margin-bottom: 17px;
            border-radius: 14px;
            background: var(--green-light);
            color: var(--green);
            font-size: 23px;
        }

        .register-form-inner h1 {
            margin-bottom: 8px;
            color: var(--green-dark);
            font-size: 1.9rem;
            font-weight: 800;
            letter-spacing: -.5px;
        }

        .form-description {
            margin-bottom: 23px;
            color: var(--muted);
            line-height: 1.7;
            font-size: .92rem;
        }

        .form-label {
            margin-bottom: 7px;
            font-size: .86rem;
            font-weight: 700;
        }

        .form-control,
        .form-select {
            min-height: 45px;
            border: 1px solid #d5dfd9;
            border-radius: 9px;
            font-size: .9rem;
        }

        .form-control:focus,
        .form-select:focus {
            border-color: var(--green);
            box-shadow: 0 0 0 3px rgba(23,107,82,.10);
        }

        .input-group {
            border: 1px solid #d5dfd9;
            border-radius: 9px;
            overflow: hidden;
        }

        .input-group:focus-within {
            border-color: var(--green);
            box-shadow: 0 0 0 3px rgba(23,107,82,.10);
        }

        .input-group-text {
            border: 0;
            background: #fff;
            color: var(--muted);
        }

        .input-group .form-control {
            min-height: 43px;
            border: 0;
            box-shadow: none;
        }

        .password-toggle {
            padding: 0 13px;
            border: 0;
            background: #fff;
            color: var(--muted);
        }

        .password-toggle:hover {
            color: var(--green);
        }

        .password-hint {
            display: block;
            margin-top: 6px;
            color: var(--muted);
            font-size: .77rem;
        }

        .btn-register {
            width: 100%;
            min-height: 48px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 9px;
            border: 1px solid var(--green);
            border-radius: 10px;
            background: var(--green);
            color: #fff;
            font-weight: 700;
            transition: background .2s ease;
        }

        .btn-register:hover {
            border-color: var(--green-dark);
            background: var(--green-dark);
            color: #fff;
        }

        .login-text {
            margin-top: 20px;
            margin-bottom: 0;
            color: var(--muted);
            text-align: center;
            font-size: .88rem;
        }

        .login-text a {
            font-weight: 700;
        }

        .alert {
            border: 0;
            border-radius: 10px;
            font-size: .88rem;
        }

        .alert-success {
            color: #166534;
            background: #ecfdf3;
        }

        .alert-danger {
            color: #842029;
            background: #f8d7da;
        }

        .security-note {
            display: flex;
            align-items: flex-start;
            gap: 9px;
            margin-top: 20px;
            padding: 12px;
            border-radius: 10px;
            background: #f5f9f6;
            color: #5f7167;
            font-size: .78rem;
            line-height: 1.6;
        }

        .security-note i {
            margin-top: 2px;
            color: var(--green);
        }

        .footer-text {
            padding: 16px 10px;
            color: var(--muted);
            text-align: center;
            font-size: .8rem;
        }

        @media (max-width: 767.98px) {
            .register-section {
                min-height: auto;
                padding: 25px 12px;
            }

            .register-wrapper {
                max-width: 500px;
                border-radius: 16px;
            }

            .register-row {
                min-height: auto;
            }

            .register-picture {
                min-height: 210px;
                padding: 25px;
                background-position: center 40%;
            }

            .picture-content h2 {
                font-size: 1.65rem;
            }

            .picture-content p {
                font-size: .88rem;
            }

            .picture-label {
                margin-bottom: 9px;
            }

            .register-form-area {
                padding: 30px 23px;
            }

            .register-form-inner h1 {
                font-size: 1.7rem;
            }
        }

        @media (prefers-reduced-motion: reduce) {
            *,
            *::before,
            *::after {
                transition: none !important;
            }
        }
    </style>

</head>

<body>

<!-- Navigation -->

<nav class="townlink-navbar">

    <div class="container d-flex align-items-center justify-content-between py-3">

        <a class="brand" href="public/index.php">

            <span class="brand-icon">
                <i class="bi bi-buildings"></i>
            </span>

            <span class="brand-name">
                Town<span>Link</span>
            </span>

        </a>

        <a href="index.php" class="nav-home">
            <i class="bi bi-arrow-left me-1"></i>
            Back to Home
        </a>

    </div>

</nav>


<!-- Registration -->

<main class="register-section">

    <div class="container">

        <div class="register-wrapper">

            <div class="row g-0 register-row">

                <!-- Picture panel -->

                <div class="col-md-5">

                    <section
                        class="register-picture"
                        aria-label="TownLink community"
                    >

                        <div class="picture-content">

                            <span class="picture-label">
                                <i class="bi bi-people me-1"></i>
                                Join TownLink Namibia
                            </span>

                            <h2>
                                Your community.
                                Your voice.
                            </h2>

                            <p>
                                Create your resident account to stay informed,
                                explore municipal services and connect with
                                your municipality.
                            </p>

                        </div>

                    </section>

                </div>


                <!-- Form panel -->

                <div class="col-md-7 register-form-area">

                    <div class="register-form-inner">

                        <div class="welcome-icon">
                            <i class="bi bi-person-plus"></i>
                        </div>

                        <h1>Create your account</h1>

                        <p class="form-description">
                            Register as a resident to get started with TownLink.
                        </p>


                        <?php if ($message !== ''): ?>

                            <div
                                class="alert <?= $messageType === 'success'
                                    ? 'alert-success'
                                    : 'alert-danger'
                                ?> mb-4"
                                role="alert"
                            >

                                <i class="bi <?= $messageType === 'success'
                                    ? 'bi-check-circle'
                                    : 'bi-exclamation-circle'
                                ?> me-2"></i>

                                <?= e($message) ?>

                            </div>

                        <?php endif; ?>


                        <form method="POST" action="">

                            <div class="row g-3">

                                <!-- First name -->

                                <div class="col-sm-6">

                                    <label
                                        for="first_name"
                                        class="form-label"
                                    >
                                        First name *
                                    </label>

                                    <input
                                        type="text"
                                        id="first_name"
                                        name="first_name"
                                        class="form-control"
                                        placeholder="Your first name"
                                        value="<?= e($firstName) ?>"
                                        maxlength="100"
                                        autocomplete="given-name"
                                        required
                                    >

                                </div>


                                <!-- Last name -->

                                <div class="col-sm-6">

                                    <label
                                        for="last_name"
                                        class="form-label"
                                    >
                                        Last name *
                                    </label>

                                    <input
                                        type="text"
                                        id="last_name"
                                        name="last_name"
                                        class="form-control"
                                        placeholder="Your last name"
                                        value="<?= e($lastName) ?>"
                                        maxlength="100"
                                        autocomplete="family-name"
                                        required
                                    >

                                </div>


                                <!-- Email -->

                                <div class="col-12">

                                    <label
                                        for="email"
                                        class="form-label"
                                    >
                                        Email address *
                                    </label>

                                    <div class="input-group">

                                        <span class="input-group-text">
                                            <i class="bi bi-envelope"></i>
                                        </span>

                                        <input
                                            type="email"
                                            id="email"
                                            name="email"
                                            class="form-control"
                                            placeholder="you@example.com"
                                            value="<?= e($email) ?>"
                                            maxlength="150"
                                            autocomplete="email"
                                            required
                                        >

                                    </div>

                                </div>


                                <!-- Phone -->

                                <div class="col-12">

                                    <label
                                        for="phone"
                                        class="form-label"
                                    >
                                        Phone number
                                    </label>

                                    <div class="input-group">

                                        <span class="input-group-text">
                                            <i class="bi bi-telephone"></i>
                                        </span>

                                        <input
                                            type="tel"
                                            id="phone"
                                            name="phone"
                                            class="form-control"
                                            placeholder="Enter your phone number"
                                            value="<?= e($phone) ?>"
                                            maxlength="50"
                                            autocomplete="tel"
                                        >

                                    </div>

                                </div>


                                <!-- Municipality -->

                                <div class="col-12">

                                    <label
                                        for="municipality_id"
                                        class="form-label"
                                    >
                                        Municipality *
                                    </label>

                                    <div class="input-group">

                                        <span class="input-group-text">
                                            <i class="bi bi-building"></i>
                                        </span>

                                        <select
                                            id="municipality_id"
                                            name="municipality_id"
                                            class="form-select"
                                            required
                                        >

                                            <option value="">
                                                Select your municipality
                                            </option>

                                            <?php foreach ($municipalities as $municipality): ?>

                                                <option
                                                    value="<?= (int)$municipality['id'] ?>"
                                                    <?= (string)$municipalityId ===
                                                        (string)$municipality['id']
                                                        ? 'selected'
                                                        : ''
                                                    ?>
                                                >
                                                    <?= e($municipality['name']) ?>
                                                </option>

                                            <?php endforeach; ?>

                                        </select>

                                    </div>

                                </div>


                                <!-- Password -->

                                <div class="col-12">

                                    <label
                                        for="password"
                                        class="form-label"
                                    >
                                        Create password *
                                    </label>

                                    <div class="input-group">

                                        <span class="input-group-text">
                                            <i class="bi bi-lock"></i>
                                        </span>

                                        <input
                                            type="password"
                                            id="password"
                                            name="password"
                                            class="form-control"
                                            placeholder="Create a secure password"
                                            minlength="8"
                                            autocomplete="new-password"
                                            required
                                        >

                                        <button
                                            type="button"
                                            class="password-toggle"
                                            id="togglePassword"
                                            aria-label="Show password"
                                            aria-pressed="false"
                                        >
                                            <i
                                                class="bi bi-eye"
                                                id="passwordIcon"
                                            ></i>
                                        </button>

                                    </div>

                                    <small class="password-hint">
                                        Use at least 8 characters.
                                    </small>

                                </div>


                                <!-- Submit -->

                                <div class="col-12 mt-4">

                                    <button
                                        type="submit"
                                        class="btn btn-register"
                                    >
                                        <i class="bi bi-person-check"></i>
                                        Create Resident Account
                                    </button>

                                </div>

                            </div>

                        </form>


                        <p class="login-text">

                            Already have an account?

                            <a href="login.php">
                                Sign in
                            </a>

                        </p>


                        <div class="security-note">

                            <i class="bi bi-shield-lock-fill"></i>

                            <span>
                                Your password is securely hashed before
                                storage. Never share your account password
                                with anyone.
                            </span>

                        </div>

                    </div>

                </div>

            </div>

        </div>

        <div class="footer-text">
            &copy; <?= date('Y') ?> TownLink Namibia. All rights reserved.
        </div>

    </div>

</main>


<script src="../assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<script>
    const togglePassword = document.getElementById('togglePassword');
    const passwordInput = document.getElementById('password');
    const passwordIcon = document.getElementById('passwordIcon');

    togglePassword.addEventListener('click', function () {

        const isHidden = passwordInput.type === 'password';

        passwordInput.type = isHidden ? 'text' : 'password';

        passwordIcon.className = isHidden
            ? 'bi bi-eye-slash'
            : 'bi bi-eye';

        togglePassword.setAttribute(
            'aria-label',
            isHidden ? 'Hide password' : 'Show password'
        );

        togglePassword.setAttribute(
            'aria-pressed',
            isHidden ? 'true' : 'false'
        );
    });
</script>

</body>
</html>