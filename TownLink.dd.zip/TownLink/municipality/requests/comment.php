<?php

declare(strict_types=1);

require_once __DIR__ . '/../auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {

    http_response_code(405);

    exit('Method not allowed.');
}

verifyCsrf();

$requestId = filter_input(
    INPUT_POST,
    'request_id',
    FILTER_VALIDATE_INT
);

$comment = trim(
    $_POST['comment'] ?? ''
);

$isInternal = isset(
    $_POST['is_internal']
) ? 1 : 0;


if (!$requestId) {

    http_response_code(400);

    exit('Invalid request.');
}


if ($comment === '') {

    http_response_code(400);

    exit('Comment cannot be empty.');
}


try {

    /*
    |--------------------------------------------------------------------------
    | Verify request belongs to municipality
    |--------------------------------------------------------------------------
    */

    $sql = "
        SELECT
            sr.id

        FROM service_requests sr

        INNER JOIN services s
            ON s.id = sr.service_id

        WHERE sr.id = :id

        AND sr.municipality_id = :municipality_id
    ";

    $params = [
        ':id' => $requestId,
        ':municipality_id' => $municipalityId
    ];


    /*
    |--------------------------------------------------------------------------
    | Department Staff Restriction
    |--------------------------------------------------------------------------
    */

    if (!isMunicipalityAdmin()) {

        if (
            $currentUser['department_id'] === null
        ) {

            http_response_code(403);

            exit(
                'No department is assigned to your account.'
            );
        }

        $sql .= "
            AND s.department_id = :department_id
        ";

        $params[':department_id'] =
            (int) $currentUser['department_id'];
    }


    $sql .= "
        LIMIT 1
    ";


    $stmt = $pdo->prepare($sql);

    $stmt->execute($params);


    if (!$stmt->fetch()) {

        http_response_code(404);

        exit('Request not found.');
    }


    /*
    |--------------------------------------------------------------------------
    | Only Municipality Admin Can Create Internal Comments
    |--------------------------------------------------------------------------
    */

    if (!isMunicipalityAdmin()) {

        $isInternal = 0;
    }


    /*
    |--------------------------------------------------------------------------
    | Create Comment
    |--------------------------------------------------------------------------
    */

    $stmt = $pdo->prepare("
        INSERT INTO request_comments
        (
            request_id,
            user_id,
            comment,
            is_internal
        )
        VALUES
        (
            :request_id,
            :user_id,
            :comment,
            :is_internal
        )
    ");


    $stmt->execute([
        ':request_id' => $requestId,
        ':user_id' => $userId,
        ':comment' => $comment,
        ':is_internal' => $isInternal
    ]);


    /*
    |--------------------------------------------------------------------------
    | Audit
    |--------------------------------------------------------------------------
    */

    auditLog(
        $pdo,
        $municipalityId,
        $userId,
        'create',
        'request_comment',
        $requestId,
        'Added a comment to service request.'
    );


    /*
    |--------------------------------------------------------------------------
    | Return to Request
    |--------------------------------------------------------------------------
    */

    header(
        'Location: view.php?id=' . $requestId
    );

    exit;


} catch (PDOException $e) {

    error_log(
        'TownLink request comment error: ' .
        $e->getMessage()
    );

    http_response_code(500);

    exit(
        'Unable to add comment.'
    );
}