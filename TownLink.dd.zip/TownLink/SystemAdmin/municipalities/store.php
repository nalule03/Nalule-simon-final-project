<?php

declare(strict_types=1);

require_once __DIR__ . '/../includes/_auth.php';

requireSystemAdmin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {

    header('Location: create.php');

    exit;
}

verifyCsrf();

$name = trim(
    $_POST['name'] ?? ''
);

$code = trim(
    $_POST['code'] ?? ''
);

$type = trim(
    $_POST['type'] ?? ''
);

$region = trim(
    $_POST['region'] ?? ''
);

$address = trim(
    $_POST['address'] ?? ''
);

$phone = trim(
    $_POST['phone'] ?? ''
);

$email = trim(
    $_POST['email'] ?? ''
);

$website = trim(
    $_POST['website'] ?? ''
);

$description = trim(
    $_POST['description'] ?? ''
);

$errors = [];

/*
|--------------------------------------------------------------------------
| Validation
|--------------------------------------------------------------------------
*/

if ($name === '') {
    $errors[] =
        'Municipality name is required.';
}

if ($code === '') {
    $errors[] =
        'Municipality code is required.';
}

if (
    !in_array(
        $type,
        [
            'municipality',
            'town',
            'village'
        ],
        true
    )
) {

    $errors[] =
        'Invalid municipality type.';
}

if (
    $email !== '' &&
    !filter_var(
        $email,
        FILTER_VALIDATE_EMAIL
    )
) {

    $errors[] =
        'Invalid municipality email address.';
}

if (
    $website !== '' &&
    !filter_var(
        $website,
        FILTER_VALIDATE_URL
    )
) {

    $errors[] =
        'Invalid website URL.';
}

/*
|--------------------------------------------------------------------------
| Duplicate Code
|--------------------------------------------------------------------------
*/

if (!$errors) {

    try {

        $stmt = $pdo->prepare("
            SELECT id
            FROM municipalities
            WHERE code = :code
            LIMIT 1
        ");

        $stmt->execute([
            ':code' => $code
        ]);

        if ($stmt->fetch()) {

            $errors[] =
                'That municipality code already exists.';
        }

    } catch (PDOException $e) {

        error_log(
            'Municipality code check error: ' .
            $e->getMessage()
        );

        $errors[] =
            'Unable to validate municipality code.';
    }
}

/*
|--------------------------------------------------------------------------
| Display Errors
|--------------------------------------------------------------------------
*/

if ($errors) {

    echo '<h1>Unable to create municipality</h1>';

    echo '<ul>';

    foreach ($errors as $error) {

        echo '<li>' .
            e($error) .
            '</li>';
    }

    echo '</ul>';

    echo '<p>';
    echo '<a href="create.php">Go Back</a>';
    echo '</p>';

    exit;
}

/*
|--------------------------------------------------------------------------
| Insert Municipality
|--------------------------------------------------------------------------
*/

try {

    $pdo->beginTransaction();

    $stmt = $pdo->prepare("
        INSERT INTO municipalities
        (
            name,
            code,
            type,
            region,
            description,
            address,
            phone,
            email,
            website,
            status
        )
        VALUES
        (
            :name,
            :code,
            :type,
            :region,
            :description,
            :address,
            :phone,
            :email,
            :website,
            'active'
        )
    ");

    $stmt->execute([
        ':name' =>
            $name,

        ':code' =>
            $code,

        ':type' =>
            $type,

        ':region' =>
            $region !== ''
            ? $region
            : null,

        ':description' =>
            $description !== ''
            ? $description
            : null,

        ':address' =>
            $address !== ''
            ? $address
            : null,

        ':phone' =>
            $phone !== ''
            ? $phone
            : null,

        ':email' =>
            $email !== ''
            ? $email
            : null,

        ':website' =>
            $website !== ''
            ? $website
            : null
    ]);

    $municipalityId =
        (int) $pdo->lastInsertId();

    $pdo->commit();

    header(
        'Location: view.php?id=' .
        $municipalityId
    );

    exit;

} catch (PDOException $e) {

    if (
        $pdo->inTransaction()
    ) {

        $pdo->rollBack();
    }

    error_log(
        'Create municipality error: ' .
        $e->getMessage()
    );

    http_response_code(500);

    exit(
        'Unable to create municipality.'
    );
}