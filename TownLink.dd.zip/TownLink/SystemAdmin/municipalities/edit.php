<?php

declare(strict_types=1);

require_once __DIR__ . '/../includes/_auth.php';

$id = filter_input(
    INPUT_GET,
    'id',
    FILTER_VALIDATE_INT
);

if (!$id || $id <= 0) {

    http_response_code(400);

    exit(
        'Invalid municipality ID.'
    );
}

try {

    $stmt = $pdo->prepare("
        SELECT
            id,
            name,
            code,
            type,
            region,
            description,
            address,
            phone,
            email,
            website,
            status
        FROM municipalities
        WHERE id = :id
        LIMIT 1
    ");

    $stmt->execute([
        ':id' => $id
    ]);

    $municipality =
        $stmt->fetch(
            PDO::FETCH_ASSOC
        );

    if (!$municipality) {

        http_response_code(404);

        exit(
            'Municipality not found.'
        );
    }

} catch (PDOException $e) {

    error_log(
        'Edit municipality error: ' .
        $e->getMessage()
    );

    http_response_code(500);

    exit(
        'Unable to load municipality.'
    );
}

?>

<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Edit Municipality | TownLink
    </title>

</head>

<body>

<header>

    <h1>
        Edit Municipality
    </h1>

</header>

<nav>

    <a href="index.php">
        Municipalities
    </a>

    |

    <a href="view.php?id=<?= $id ?>">
        View
    </a>

</nav>

<hr>

<main>

    <form
        method="POST"
        action="update.php"
    >

        <input
            type="hidden"
            name="csrf_token"
            value="<?= e(csrfToken()) ?>"
        >

        <input
            type="hidden"
            name="id"
            value="<?= $id ?>"
        >

        <p>

            <label for="name">
                Municipality Name
            </label>

            <br>

            <input
                type="text"
                id="name"
                name="name"
                value="<?= e(
                    $municipality['name']
                ) ?>"
                maxlength="150"
                required
            >

        </p>

        <p>

            <label for="code">
                Municipality Code
            </label>

            <br>

            <input
                type="text"
                id="code"
                name="code"
                value="<?= e(
                    $municipality['code']
                ) ?>"
                maxlength="50"
                required
            >

        </p>

        <p>

            <label for="type">
                Type
            </label>

            <br>

            <select
                id="type"
                name="type"
                required
            >

                <option
                    value="municipality"
                    <?= $municipality['type'] === 'municipality'
                        ? 'selected'
                        : '' ?>
                >
                    Municipality
                </option>

                <option
                    value="town"
                    <?= $municipality['type'] === 'town'
                        ? 'selected'
                        : '' ?>
                >
                    Town
                </option>

                <option
                    value="village"
                    <?= $municipality['type'] === 'village'
                        ? 'selected'
                        : '' ?>
                >
                    Village
                </option>

            </select>

        </p>

        <p>

            <label for="region">
                Region
            </label>

            <br>

            <input
                type="text"
                id="region"
                name="region"
                value="<?= e(
                    $municipality['region']
                ) ?>"
                maxlength="100"
            >

        </p>

        <p>

            <label for="address">
                Address
            </label>

            <br>

            <textarea
                id="address"
                name="address"
                rows="4"
            ><?= e(
                $municipality['address']
            ) ?></textarea>

        </p>

        <p>

            <label for="phone">
                Phone
            </label>

            <br>

            <input
                type="text"
                id="phone"
                name="phone"
                value="<?= e(
                    $municipality['phone']
                ) ?>"
                maxlength="50"
            >

        </p>

        <p>

            <label for="email">
                Email
            </label>

            <br>

            <input
                type="email"
                id="email"
                name="email"
                value="<?= e(
                    $municipality['email']
                ) ?>"
                maxlength="150"
            >

        </p>

        <p>

            <label for="website">
                Website
            </label>

            <br>

            <input
                type="url"
                id="website"
                name="website"
                value="<?= e(
                    $municipality['website']
                ) ?>"
                maxlength="255"
            >

        </p>

        <p>

            <label for="description">
                Description
            </label>

            <br>

            <textarea
                id="description"
                name="description"
                rows="5"
            ><?= e(
                $municipality['description']
            ) ?></textarea>

        </p>

        <p>

            <label for="status">
                Status
            </label>

            <br>

            <select
                id="status"
                name="status"
                required
            >

                <option
                    value="active"
                    <?= $municipality['status'] === 'active'
                        ? 'selected'
                        : '' ?>
                >
                    Active
                </option>

                <option
                    value="inactive"
                    <?= $municipality['status'] === 'inactive'
                        ? 'selected'
                        : '' ?>
                >
                    Inactive
                </option>

            </select>

        </p>

        <button type="submit">
            Save Changes
        </button>

        <a href="view.php?id=<?= $id ?>">
            Cancel
        </a>

    </form>

</main>

</body>

</html>
