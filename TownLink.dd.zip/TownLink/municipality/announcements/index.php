<?php
declare(strict_types=1);

require_once __DIR__ . '/../auth.php';
require_once __DIR__ . '/../layout.php';

if (!isMunicipalityAdmin()) {
    http_response_code(403);
    exit('Access denied.');
}

function e($value): string
{
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
}

$stmt = $pdo->prepare("
    SELECT id, title, category, status, publish_at, expires_at, created_at
    FROM announcements
    WHERE municipality_id = :municipality_id
    ORDER BY created_at DESC
    LIMIT 200
");

$stmt->execute([':municipality_id' => $municipalityId]);
$announcements = $stmt->fetchAll(PDO::FETCH_ASSOC);

municipalityHeader('Announcements', 'announcements');
?>

<div class="page-header">
    <div>
        <h2>Announcements</h2>
        <p>Manage municipal notices, jobs, events and public information.</p>
    </div>

    <div class="actions">
        <a class="button" href="create.php">Create Announcement</a>
    </div>
</div>

<div class="card">
    <?php if (!$announcements): ?>
        <p class="muted">No announcements have been created yet.</p>
    <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Category</th>
                    <th>Status</th>
                    <th>Publish date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($announcements as $item): ?>
                <tr>
                    <td><?= e($item['title']) ?></td>
                    <td><?= e($item['category']) ?></td>
                    <td><?= e(ucfirst($item['status'])) ?></td>
                    <td>
                        <?= e($item['publish_at'] ?: 'Not scheduled') ?>
                    </td>
                    <td>
                        <?php if ($item['status'] === 'published'): ?>
                            <a target="_blank" rel="noopener"
                               href="../../public/announcement-details.php?id=<?= (int)$item['id'] ?>">
                                View
                            </a>
                        <?php endif; ?>
                        &nbsp;
                        <a href="edit.php?id=<?= (int)$item['id'] ?>">Edit</a>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

<?php municipalityFooter(); ?>