<?php

declare(strict_types=1);

require_once __DIR__ . '/../auth.php';
require_once __DIR__ . '/../layout.php';

requireMunicipalityAdmin();

$error = '';

$departments = [];
$categories = [];

$stmt = $pdo->prepare("
    SELECT id, name, code
    FROM departments
    WHERE municipality_id = :municipality_id
    AND status = 'active'
    ORDER BY name
");

$stmt->execute([
    ':municipality_id' => $municipalityId
]);

$departments =
    $stmt->fetchAll(PDO::FETCH_ASSOC);

$stmt = $pdo->prepare("
    SELECT id, name
    FROM service_categories
    WHERE municipality_id = :municipality_id
    AND status = 'active'
    ORDER BY name
");

$stmt->execute([
    ':municipality_id' => $municipalityId
]);

$categories =
    $stmt->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    verifyCsrf();

    $name = trim($_POST['name'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $instructions = trim($_POST['instructions'] ?? '');

    $departmentId =
        filter_input(
            INPUT_POST,
            'department_id',
            FILTER_VALIDATE_INT
        );

    $categoryId =
        filter_input(
            INPUT_POST,
            'category_id',
            FILTER_VALIDATE_INT
        );

    $estimatedDays =
        filter_input(
            INPUT_POST,
            'estimated_days',
            FILTER_VALIDATE_INT
        );

    if ($name === '') {

        $error = 'Service name is required.';

    } elseif (!$departmentId) {

        $error = 'Please select a department.';

    } elseif (
        $estimatedDays !== null &&
        $estimatedDays !== false &&
        $estimatedDays < 0
    ) {

        $error =
            'Estimated days cannot be negative.';

    } else {

        try {

            $stmt = $pdo->prepare("
                SELECT id
                FROM departments
                WHERE id = :id
                AND municipality_id = :municipality_id
                AND status = 'active'
                LIMIT 1
            ");

            $stmt->execute([
                ':id' => $departmentId,
                ':municipality_id' => $municipalityId
            ]);

            if (!$stmt->fetch()) {

                $error =
                    'Invalid department selected.';

            } else {

                if ($categoryId) {

                    $stmt = $pdo->prepare("
                        SELECT id
                        FROM service_categories
                        WHERE id = :id
                        AND municipality_id = :municipality_id
                        AND status = 'active'
                        LIMIT 1
                    ");

                    $stmt->execute([
                        ':id' => $categoryId,
                        ':municipality_id' =>
                            $municipalityId
                    ]);

                    if (!$stmt->fetch()) {
                        $categoryId = null;
                    }
                }

                $stmt = $pdo->prepare("
                    INSERT INTO services
                    (
                        municipality_id,
                        department_id,
                        category_id,
                        name,
                        description,
                        instructions,
                        estimated_days,
                        status
                    )
                    VALUES
                    (
                        :municipality_id,
                        :department_id,
                        :category_id,
                        :name,
                        :description,
                        :instructions,
                        :estimated_days,
                        'active'
                    )
                ");

                $stmt->execute([
                    ':municipality_id' => $municipalityId,
                    ':department_id' => $departmentId,
                    ':category_id' => $categoryId,
                    ':name' => $name,
                    ':description' =>
                        $description !== ''
                        ? $description
                        : null,
                    ':instructions' =>
                        $instructions !== ''
                        ? $instructions
                        : null,
                    ':estimated_days' =>
                        $estimatedDays !== false
                        ? $estimatedDays
                        : null
                ]);

                $serviceId =
                    (int) $pdo->lastInsertId();

                auditLog(
                    $pdo,
                    $municipalityId,
                    $userId,
                    'create',
                    'service',
                    $serviceId,
                    'Created service: ' . $name
                );

                header(
                    'Location: view.php?id=' .
                    $serviceId
                );

                exit;
            }

        } catch (PDOException $e) {

            error_log(
                'Service create error: ' .
                $e->getMessage()
            );

            $error =
                'Unable to create the service.';
        }
    }
}

municipalityHeader(
    'Add Service',
    'services'
);

?>

<div class="page-header">

    <div>
        <h2>Add Service</h2>
        <p>Create a service residents can request.</p>
    </div>

</div>

<?php if ($error !== ''): ?>

    <div class="alert error">
        <?= e($error) ?>
    </div>

<?php endif; ?>

<div class="card">

    <form method="POST">

        <input
            type="hidden"
            name="csrf_token"
            value="<?= e(csrfToken()) ?>"
        >

        <div class="form-grid">

            <div class="full">

                <label>
                    Service Name
                </label>

                <input
                    name="name"
                    maxlength="200"
                    required
                    value="<?= e(
                        $_POST['name'] ?? ''
                    ) ?>"
                >

            </div>

            <div>

                <label>
                    Department
                </label>

                <select
                    name="department_id"
                    required
                >

                    <option value="">
                        Select department
                    </option>

                    <?php foreach (
                        $departments as $department
                    ): ?>

                        <option
                            value="<?= (int) $department['id'] ?>"
                            <?= (int) (
                                $_POST['department_id'] ?? 0
                            ) === (int) $department['id']
                                ? 'selected'
                                : '' ?>
                        >
                            <?= e(
                                $department['name']
                            ) ?>
                            (<?= e(
                                $department['code']
                            ) ?>)
                        </option>

                    <?php endforeach; ?>

                </select>

            </div>

            <div>

                <label>
                    Category
                </label>

                <select name="category_id">

                    <option value="">
                        No category
                    </option>

                    <?php foreach (
                        $categories as $category
                    ): ?>

                        <option
                            value="<?= (int) $category['id'] ?>"
                            <?= (int) (
                                $_POST['category_id'] ?? 0
                            ) === (int) $category['id']
                                ? 'selected'
                                : '' ?>
                        >
                            <?= e(
                                $category['name']
                            ) ?>
                        </option>

                    <?php endforeach; ?>

                </select>

            </div>

            <div>

                <label>
                    Estimated Processing Days
                </label>

                <input
                    type="number"
                    name="estimated_days"
                    min="0"
                    value="<?= e(
                        $_POST['estimated_days'] ?? ''
                    ) ?>"
                >

            </div>

            <div class="full">

                <label>
                    Description
                </label>

                <textarea
                    name="description"
                ><?= e(
                    $_POST['description'] ?? ''
                ) ?></textarea>

            </div>

            <div class="full">

                <label>
                    Instructions for Residents
                </label>

                <textarea
                    name="instructions"
                ><?= e(
                    $_POST['instructions'] ?? ''
                ) ?></textarea>

            </div>

        </div>

        <br>

        <button class="button">
            Create Service
        </button>

        <a
            class="button secondary"
            href="index.php"
        >
            Cancel
        </a>

    </form>

</div>

<?php

municipalityFooter();
