<?php

declare(strict_types=1);

if (!function_exists('auditLog')) {
    function auditLog(
        PDO $pdo,
        int $municipalityId,
        int $userId,
        string $action,
        string $entityType,
        int $entityId,
        string $description
    ): void {
        try {
            $stmt = $pdo->prepare("
                INSERT INTO audit_logs (
                    municipality_id,
                    user_id,
                    action,
                    entity_type,
                    entity_id,
                    description,
                    ip_address,
                    user_agent
                ) VALUES (
                    :municipality_id,
                    :user_id,
                    :action,
                    :entity_type,
                    :entity_id,
                    :description,
                    :ip_address,
                    :user_agent
                )
            ");

            $stmt->execute([
                ':municipality_id' => $municipalityId > 0
                    ? $municipalityId
                    : null,
                ':user_id' => $userId > 0
                    ? $userId
                    : null,
                ':action' => $action,
                ':entity_type' => $entityType,
                ':entity_id' => $entityId > 0
                    ? $entityId
                    : null,
                ':description' => $description,
                ':ip_address' => $_SERVER['REMOTE_ADDR'] ?? null,
                ':user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? null,
            ]);
        } catch (PDOException $e) {
            error_log(
                'TownLink audit log error: ' . $e->getMessage()
            );
        }
    }
}