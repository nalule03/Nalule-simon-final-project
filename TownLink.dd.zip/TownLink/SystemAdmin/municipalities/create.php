<?php

declare(strict_types=1);

require_once __DIR__ . '/../includes/_auth.php';

?>

<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Create Municipality | TownLink
    </title>

</head>

<body>

<header>

    <h1>
        Create Municipality
    </h1>

</header>

<nav>

    <a href="index.php">
        Municipalities
    </a>

    |

    <a href="../index.php">
        Dashboard
    </a>

</nav>

<hr>

<main>

    <form
        method="POST"
        action="store.php"
    >

        <input
            type="hidden"
            name="csrf_token"
            value="<?= e(csrfToken()) ?>"
        >

        <p>

            <label for="name">
                Municipality Name
            </label>

            <br>

            <input
                type="text"
                id="name"
                name="name"
                maxlength="150"
                required
            >

        </p>

        <p>

            <label for="code">
                Municipality Code
            </label>

            <br>

            <input
                type="text"
                id="code"
                name="code"
                maxlength="50"
                required
            >

        </p>

        <p>

            <label for="type">
                Type
            </label>

            <br>

            <select
                id="type"
                name="type"
                required
            >

                <option value="municipality">
                    Municipality
                </option>

                <option value="town">
                    Town
                </option>

                <option value="village">
                    Village
                </option>

            </select>

        </p>

        <p>

            <label for="region">
                Region
            </label>

            <br>

            <input
                type="text"
                id="region"
                name="region"
                maxlength="100"
            >

        </p>

        <p>

            <label for="address">
                Address
            </label>

            <br>

            <textarea
                id="address"
                name="address"
                rows="4"
            ></textarea>

        </p>

        <p>

            <label for="phone">
                Phone
            </label>

            <br>

            <input
                type="text"
                id="phone"
                name="phone"
                maxlength="50"
            >

        </p>

        <p>

            <label for="email">
                Email
            </label>

            <br>

            <input
                type="email"
                id="email"
                name="email"
                maxlength="150"
            >

        </p>

        <p>

            <label for="website">
                Website
            </label>

            <br>

            <input
                type="url"
                id="website"
                name="website"
                maxlength="255"
            >

        </p>

        <p>

            <label for="description">
                Description
            </label>

            <br>

            <textarea
                id="description"
                name="description"
                rows="5"
            ></textarea>

        </p>

        <button type="submit">
            Create Municipality
        </button>

        <a href="index.php">
            Cancel
        </a>

    </form>

</main>

</body>

</html>