<?php

declare(strict_types=1);

require_once __DIR__ . '/includes/_auth.php';
require_once __DIR__ . '/includes/_layout.php';

try {

    /*
    |--------------------------------------------------------------------------
    | Municipality Statistics
    |--------------------------------------------------------------------------
    */

    $stmt = $pdo->query("
        SELECT
            COUNT(*) AS total,
            SUM(status = 'active') AS active,
            SUM(status = 'inactive') AS inactive
        FROM municipalities
    ");

    $municipalityStats =
        $stmt->fetch(PDO::FETCH_ASSOC);

    /*
    |--------------------------------------------------------------------------
    | User Statistics
    |--------------------------------------------------------------------------
    */

    $stmt = $pdo->query("
        SELECT
            COUNT(*) AS total,
            SUM(role = 'system_admin') AS system_admins,
            SUM(role = 'municipality_admin') AS municipality_admins,
            SUM(role = 'department_staff') AS department_staff,
            SUM(role = 'resident') AS residents,
            SUM(status = 'active') AS active,
            SUM(status = 'inactive') AS inactive
        FROM users
    ");

    $userStats =
        $stmt->fetch(PDO::FETCH_ASSOC);

    /*
    |--------------------------------------------------------------------------
    | Recent Municipalities
    |--------------------------------------------------------------------------
    */

    $stmt = $pdo->query("
        SELECT
            m.id,
            m.name,
            m.code,
            m.type,
            m.region,
            m.status,
            m.created_at,

            (
                SELECT COUNT(*)
                FROM users u
                WHERE u.municipality_id = m.id
            ) AS user_count

        FROM municipalities m

        ORDER BY m.created_at DESC

        LIMIT 10
    ");

    $municipalities =
        $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {

    error_log(
        'SystemAdmin dashboard error: ' .
        $e->getMessage()
    );

    http_response_code(500);
    exit('Unable to load dashboard.');
}

systemAdminHeader(
    'System Administration Dashboard'
);

?>

<div class="page-header">

    <div>

        <h1>Dashboard</h1>

        <p class="muted">
            Manage TownLink municipalities and users.
        </p>

    </div>

</div>

<div class="cards">

    <div class="card">

        <div class="stat-label">
            Total Municipalities
        </div>

        <div class="stat-number">
            <?= (int) (
                $municipalityStats['total'] ?? 0
            ) ?>
        </div>

    </div>

    <div class="card">

        <div class="stat-label">
            Active Municipalities
        </div>

        <div class="stat-number">
            <?= (int) (
                $municipalityStats['active'] ?? 0
            ) ?>
        </div>

    </div>

    <div class="card">

        <div class="stat-label">
            Total Users
        </div>

        <div class="stat-number">
            <?= (int) (
                $userStats['total'] ?? 0
            ) ?>
        </div>

    </div>

    <div class="card">

        <div class="stat-label">
            Municipality Admins
        </div>

        <div class="stat-number">
            <?= (int) (
                $userStats['municipality_admins'] ?? 0
            ) ?>
        </div>

    </div>

</div>

<div class="card">

    <div class="page-header">

        <div>

            <h2>Municipalities</h2>

            <p class="muted">
                Recently created municipalities.
            </p>

        </div>

        <a
            class="button"
            href="municipalities/create.php"
        >
            Create Municipality
        </a>

    </div>

    <?php if (!$municipalities): ?>

        <p class="muted">
            No municipalities have been created yet.
        </p>

    <?php else: ?>

        <table>

            <thead>

                <tr>
                    <th>Name</th>
                    <th>Code</th>
                    <th>Type</th>
                    <th>Region</th>
                    <th>Users</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>

            </thead>

            <tbody>

            <?php foreach ($municipalities as $municipality): ?>

                <tr>

                    <td>
                        <?= e(
                            $municipality['name']
                        ) ?>
                    </td>

                    <td>
                        <?= e(
                            $municipality['code']
                        ) ?>
                    </td>

                    <td>
                        <?= e(
                            ucfirst(
                                $municipality['type']
                            )
                        ) ?>
                    </td>

                    <td>
                        <?= e(
                            $municipality['region']
                            ?? '—'
                        ) ?>
                    </td>

                    <td>
                        <?= (int) (
                            $municipality['user_count']
                        ) ?>
                    </td>

                    <td>

                        <span class="badge <?= e(
                            $municipality['status']
                        ) ?>">

                            <?= e(
                                ucfirst(
                                    $municipality['status']
                                )
                            ) ?>

                        </span>

                    </td>

                    <td>

                        <div class="actions">

                            <a
                                class="button secondary"
                                href="municipalities/view.php?id=<?= (int) $municipality['id'] ?>"
                            >
                                View
                            </a>

                            <a
                                class="button secondary"
                                href="municipalities/edit.php?id=<?= (int) $municipality['id'] ?>"
                            >
                                Edit
                            </a>

                        </div>

                    </td>

                </tr>

            <?php endforeach; ?>

            </tbody>

        </table>

    <?php endif; ?>

</div>

<div class="cards">

    <div class="card">

        <div class="stat-label">
            Active Users
        </div>

        <div class="stat-number">
            <?= (int) (
                $userStats['active'] ?? 0
            ) ?>
        </div>

    </div>

    <div class="card">

        <div class="stat-label">
            Residents
        </div>

        <div class="stat-number">
            <?= (int) (
                $userStats['residents'] ?? 0
            ) ?>
        </div>

    </div>

    <div class="card">

        <div class="stat-label">
            Department Staff
        </div>

        <div class="stat-number">
            <?= (int) (
                $userStats['department_staff'] ?? 0
            ) ?>
        </div>

    </div>

    <div class="card">

        <div class="stat-label">
            Inactive Users
        </div>

        <div class="stat-number">
            <?= (int) (
                $userStats['inactive'] ?? 0
            ) ?>
        </div>

    </div>

</div>

<?php

systemAdminFooter();