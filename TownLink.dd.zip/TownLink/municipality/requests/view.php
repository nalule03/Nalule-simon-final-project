<?php

declare(strict_types=1);

require_once __DIR__ . '/../auth.php';
require_once __DIR__ . '/../layout.php';

$id = filter_input(
    INPUT_GET,
    'id',
    FILTER_VALIDATE_INT
);

if (!$id) {

    http_response_code(400);

    exit('Invalid request.');
}

/*
|--------------------------------------------------------------------------
| Load Request
|--------------------------------------------------------------------------
*/

$sql = "
    SELECT
        sr.*,

        s.name AS service_name,
        s.instructions AS service_instructions,

        d.id AS department_id,
        d.name AS department_name,

        CONCAT(
            resident.first_name,
            ' ',
            resident.last_name
        ) AS resident_name,

        resident.email AS resident_email,
        resident.phone AS resident_phone

    FROM service_requests sr

    INNER JOIN services s
        ON s.id = sr.service_id

    INNER JOIN departments d
        ON d.id = s.department_id

    INNER JOIN users resident
        ON resident.id = sr.resident_id

    WHERE sr.id = :id
    AND sr.municipality_id = :municipality_id
";

$params = [
    ':id' => $id,
    ':municipality_id' => $municipalityId
];

/*
|--------------------------------------------------------------------------
| Department Staff Restriction
|--------------------------------------------------------------------------
*/

if (!isMunicipalityAdmin()) {

    if ($currentUser['department_id'] === null) {

        http_response_code(403);

        exit(
            'No department is assigned to your account.'
        );
    }

    $sql .= "
        AND s.department_id = :department_id
    ";

    $params[':department_id'] =
        (int) $currentUser['department_id'];
}

$sql .= "
    LIMIT 1
";

$stmt = $pdo->prepare($sql);

$stmt->execute($params);

$request = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$request) {

    http_response_code(404);

    exit('Request not found.');
}

/*
|--------------------------------------------------------------------------
| Current Assignment
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT
        ra.*,

        d.name AS department_name,

        CASE
            WHEN assigned.id IS NOT NULL
            THEN CONCAT(
                assigned.first_name,
                ' ',
                assigned.last_name
            )
            ELSE NULL
        END AS assigned_name

    FROM request_assignments ra

    INNER JOIN departments d
        ON d.id = ra.department_id

    LEFT JOIN users assigned
        ON assigned.id = ra.assigned_to

    WHERE ra.request_id = :request_id

    AND ra.unassigned_at IS NULL

    ORDER BY ra.assigned_at DESC

    LIMIT 1
");

$stmt->execute([
    ':request_id' => $id
]);

$assignment = $stmt->fetch(PDO::FETCH_ASSOC);

/*
|--------------------------------------------------------------------------
| Comments
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT
        rc.id,
        rc.comment,
        rc.is_internal,
        rc.created_at,

        CONCAT(
            u.first_name,
            ' ',
            u.last_name
        ) AS user_name,

        u.role

    FROM request_comments rc

    INNER JOIN users u
        ON u.id = rc.user_id

    WHERE rc.request_id = :request_id

    AND (
        rc.is_internal = 0
        OR :is_admin = 1
    )

    ORDER BY rc.created_at ASC
");

$stmt->execute([
    ':request_id' => $id,
    ':is_admin' =>
        isMunicipalityAdmin()
            ? 1
            : 0
]);

$comments = $stmt->fetchAll(PDO::FETCH_ASSOC);

/*
|--------------------------------------------------------------------------
| Status History
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT
        h.*,

        CASE
            WHEN u.id IS NOT NULL
            THEN CONCAT(
                u.first_name,
                ' ',
                u.last_name
            )
            ELSE 'System'
        END AS changed_by_name

    FROM request_status_history h

    LEFT JOIN users u
        ON u.id = h.changed_by

    WHERE h.request_id = :request_id

    ORDER BY h.created_at DESC
");

$stmt->execute([
    ':request_id' => $id
]);

$history = $stmt->fetchAll(PDO::FETCH_ASSOC);

/*
|--------------------------------------------------------------------------
| Departments
|--------------------------------------------------------------------------
*/

if (isMunicipalityAdmin()) {

    $stmt = $pdo->prepare("
        SELECT
            id,
            name

        FROM departments

        WHERE municipality_id = :municipality_id
        AND status = 'active'

        ORDER BY name
    ");

    $stmt->execute([
        ':municipality_id' => $municipalityId
    ]);

} else {

    $stmt = $pdo->prepare("
        SELECT
            id,
            name

        FROM departments

        WHERE id = :department_id
        AND municipality_id = :municipality_id
        AND status = 'active'

        ORDER BY name
    ");

    $stmt->execute([
        ':department_id' =>
            (int) $currentUser['department_id'],
        ':municipality_id' => $municipalityId
    ]);
}

$requestDepartments =
    $stmt->fetchAll(PDO::FETCH_ASSOC);

/*
|--------------------------------------------------------------------------
| Staff
|--------------------------------------------------------------------------
*/

if (isMunicipalityAdmin()) {

    $stmt = $pdo->prepare("
        SELECT
            id,
            first_name,
            last_name,
            department_id

        FROM users

        WHERE municipality_id = :municipality_id
        AND role = 'department_staff'
        AND status = 'active'

        ORDER BY first_name, last_name
    ");

    $stmt->execute([
        ':municipality_id' => $municipalityId
    ]);

} else {

    $stmt = $pdo->prepare("
        SELECT
            id,
            first_name,
            last_name,
            department_id

        FROM users

        WHERE municipality_id = :municipality_id
        AND department_id = :department_id
        AND role = 'department_staff'
        AND status = 'active'

        ORDER BY first_name, last_name
    ");

    $stmt->execute([
        ':municipality_id' => $municipalityId,
        ':department_id' =>
            (int) $currentUser['department_id']
    ]);
}

$staff =
    $stmt->fetchAll(PDO::FETCH_ASSOC);

/*
|--------------------------------------------------------------------------
| Header
|--------------------------------------------------------------------------
*/

municipalityHeader(
    'Request ' . $request['reference_number'],
    'requests'
);

?>

<div class="page-header">

    <div>

        <h2>
            <?= e(
                $request['reference_number']
            ) ?>
        </h2>

        <p>
            <?= e(
                $request['subject']
            ) ?>
        </p>

    </div>

    <a
        class="button secondary"
        href="index.php"
    >
        Back to Requests
    </a>

</div>


<!-- ==========================================================
     REQUEST DETAILS
=========================================================== -->

<div class="card">

    <h3>Request Details</h3>

    <div class="detail-grid">

        <div class="detail-label">
            Reference
        </div>

        <div>
            <?= e(
                $request['reference_number']
            ) ?>
        </div>


        <div class="detail-label">
            Subject
        </div>

        <div>
            <?= e(
                $request['subject']
            ) ?>
        </div>


        <div class="detail-label">
            Resident
        </div>

        <div>

            <?= e(
                $request['resident_name']
            ) ?>

            <br>

            <small class="muted">

                <?= e(
                    $request['resident_email']
                ) ?>

                <?php if (
                    !empty($request['resident_phone'])
                ): ?>

                    —
                    <?= e(
                        $request['resident_phone']
                    ) ?>

                <?php endif; ?>

            </small>

        </div>


        <div class="detail-label">
            Department
        </div>

        <div>
            <?= e(
                $request['department_name']
            ) ?>
        </div>


        <div class="detail-label">
            Service
        </div>

        <div>
            <?= e(
                $request['service_name']
            ) ?>
        </div>


        <div class="detail-label">
            Description
        </div>

        <div>
            <?= nl2br(
                e(
                    $request['description']
                )
            ) ?>
        </div>


        <div class="detail-label">
            Location
        </div>

        <div>

            <?php if (
                !empty($request['location_description'])
            ): ?>

                <?= e(
                    $request['location_description']
                ) ?>

            <?php endif; ?>


            <?php if (
                !empty($request['street_name'])
            ): ?>

                <br>

                <?= e(
                    $request['house_number'] ?? ''
                ) ?>

                <?= e(
                    $request['street_name']
                ) ?>

            <?php endif; ?>


            <?php if (
                !empty($request['area'])
            ): ?>

                <br>

                <?= e(
                    $request['area']
                ) ?>

            <?php endif; ?>

        </div>


        <div class="detail-label">
            Priority
        </div>

        <div>

            <span
                class="badge <?= e(
                    $request['priority']
                ) ?>"
            >
                <?= e(
                    ucfirst(
                        $request['priority']
                    )
                ) ?>
            </span>

        </div>


        <div class="detail-label">
            Status
        </div>

        <div>

            <span
                class="badge <?= e(
                    $request['status']
                ) ?>"
            >
                <?= e(
                    ucwords(
                        str_replace(
                            '_',
                            ' ',
                            $request['status']
                        )
                    )
                ) ?>
            </span>

        </div>


        <div class="detail-label">
            Submitted
        </div>

        <div>
            <?= e(
                $request['submitted_at']
            ) ?>
        </div>


        <?php if (
            !empty($request['resolved_at'])
        ): ?>

            <div class="detail-label">
                Resolved
            </div>

            <div>
                <?= e(
                    $request['resolved_at']
                ) ?>
            </div>

        <?php endif; ?>


        <?php if (
            !empty($request['closed_at'])
        ): ?>

            <div class="detail-label">
                Closed
            </div>

            <div>
                <?= e(
                    $request['closed_at']
                ) ?>
            </div>

        <?php endif; ?>

    </div>

</div>


<!-- ==========================================================
     CURRENT ASSIGNMENT
=========================================================== -->

<div class="card">

    <h3>Current Assignment</h3>

    <?php if (!$assignment): ?>

        <p class="muted">
            This request is not currently assigned.
        </p>

    <?php else: ?>

        <div class="detail-grid">

            <div class="detail-label">
                Department
            </div>

            <div>
                <?= e(
                    $assignment['department_name']
                ) ?>
            </div>


            <div class="detail-label">
                Assigned To
            </div>

            <div>
                <?= e(
                    $assignment['assigned_name']
                    ?? 'Department'
                ) ?>
            </div>


            <div class="detail-label">
                Assigned At
            </div>

            <div>
                <?= e(
                    $assignment['assigned_at']
                ) ?>
            </div>


            <?php if (
                !empty($assignment['notes'])
            ): ?>

                <div class="detail-label">
                    Notes
                </div>

                <div>
                    <?= nl2br(
                        e(
                            $assignment['notes']
                        )
                    ) ?>
                </div>

            <?php endif; ?>

        </div>

    <?php endif; ?>

</div>


<!-- ==========================================================
     UPDATE REQUEST
=========================================================== -->

<div class="card">

    <h3>Update Request</h3>

    <form
        method="POST"
        action="update.php"
    >

        <input
            type="hidden"
            name="csrf_token"
            value="<?= e(
                csrfToken()
            ) ?>"
        >

        <input
            type="hidden"
            name="request_id"
            value="<?= (int) $id ?>"
        >


        <div class="form-grid">


            <div>

                <label for="status">
                    Status
                </label>

                <select
                    id="status"
                    name="status"
                    required
                >

                    <?php foreach ([
                        'submitted',
                        'under_review',
                        'assigned',
                        'in_progress',
                        'pending_resident',
                        'resolved',
                        'closed',
                        'rejected',
                        'cancelled'
                    ] as $status): ?>

                        <option
                            value="<?= e(
                                $status
                            ) ?>"
                            <?= $request['status'] === $status
                                ? 'selected'
                                : '' ?>
                        >
                            <?= e(
                                ucwords(
                                    str_replace(
                                        '_',
                                        ' ',
                                        $status
                                    )
                                )
                            ) ?>
                        </option>

                    <?php endforeach; ?>

                </select>

            </div>


            <div>

                <label for="department_id">
                    Assignment Department
                </label>

                <select
                    id="department_id"
                    name="department_id"
                >

                    <option value="">
                        Keep current / no change
                    </option>

                    <?php foreach (
                        $requestDepartments
                        as $department
                    ): ?>

                        <option
                            value="<?= (int) $department['id'] ?>"
                            <?= $assignment &&
                                (int) $assignment['department_id']
                                === (int) $department['id']
                                ? 'selected'
                                : '' ?>
                        >
                            <?= e(
                                $department['name']
                            ) ?>
                        </option>

                    <?php endforeach; ?>

                </select>

            </div>


            <div>

                <label for="assigned_to">
                    Assign Staff Member
                </label>

                <select
                    id="assigned_to"
                    name="assigned_to"
                >

                    <option value="">
                        Department only
                    </option>

                    <?php foreach (
                        $staff as $member
                    ): ?>

                        <option
                            value="<?= (int) $member['id'] ?>"
                            <?= $assignment &&
                                !empty(
                                    $assignment['assigned_to']
                                ) &&
                                (int) $assignment['assigned_to']
                                === (int) $member['id']
                                ? 'selected'
                                : '' ?>
                        >
                            <?= e(
                                $member['first_name'] .
                                ' ' .
                                $member['last_name']
                            ) ?>
                        </option>

                    <?php endforeach; ?>

                </select>

            </div>


            <div class="full">

                <label for="note">
                    Internal Assignment / Status Note
                </label>

                <textarea
                    id="note"
                    name="note"
                    placeholder="Add a note about this update..."
                ></textarea>

            </div>

        </div>


        <br>

        <button
            type="submit"
            class="button"
        >
            Update Request
        </button>

    </form>

</div>


<!-- ==========================================================
     ADD COMMENT
=========================================================== -->

<div class="card">

    <h3>Add Comment</h3>

    <form
        method="POST"
        action="comment.php"
    >

        <input
            type="hidden"
            name="csrf_token"
            value="<?= e(
                csrfToken()
            ) ?>"
        >

        <input
            type="hidden"
            name="request_id"
            value="<?= (int) $id ?>"
        >

        <label for="comment">
            Comment
        </label>

        <textarea
            id="comment"
            name="comment"
            required
            placeholder="Write a response or internal note..."
        ></textarea>


        <?php if (
            isMunicipalityAdmin()
        ): ?>

            <p>

                <label>

                    <input
                        type="checkbox"
                        name="is_internal"
                        value="1"
                    >

                    Internal note
                    (not visible to resident)

                </label>

            </p>

        <?php endif; ?>


        <button
            type="submit"
            class="button"
        >
            Add Comment
        </button>

    </form>

</div>


<!-- ==========================================================
     COMMENTS
=========================================================== -->

<div class="card">

    <h3>Comments</h3>

    <?php if (!$comments): ?>

        <p class="muted">
            No comments yet.
        </p>

    <?php else: ?>

        <?php foreach (
            $comments as $comment
        ): ?>

            <div class="comment">

                <strong>
                    <?= e(
                        $comment['user_name']
                    ) ?>
                </strong>


                <?php if (
                    $comment['is_internal']
                ): ?>

                    <span class="badge pending">
                        Internal
                    </span>

                <?php endif; ?>


                <small class="muted">

                    <?= e(
                        $comment['created_at']
                    ) ?>

                </small>


                <p>

                    <?= nl2br(
                        e(
                            $comment['comment']
                        )
                    ) ?>

                </p>

            </div>

        <?php endforeach; ?>

    <?php endif; ?>

</div>


<!-- ==========================================================
     STATUS HISTORY
=========================================================== -->

<div class="card">

    <h3>Status History</h3>

    <?php if (!$history): ?>

        <p class="muted">
            No status changes recorded.
        </p>

    <?php else: ?>

        <?php foreach (
            $history as $item
        ): ?>

            <div class="history">

                <strong>

                    <?= e(
                        ucwords(
                            str_replace(
                                '_',
                                ' ',
                                $item['new_status']
                            )
                        )
                    ) ?>

                </strong>


                <?php if (
                    !empty(
                        $item['old_status']
                    )
                ): ?>

                    <span class="muted">

                        from

                        <?= e(
                            ucwords(
                                str_replace(
                                    '_',
                                    ' ',
                                    $item['old_status']
                                )
                            )
                        ) ?>

                    </span>

                <?php endif; ?>


                <br>


                <small class="muted">

                    <?= e(
                        $item['changed_by_name']
                    ) ?>

                    —

                    <?= e(
                        $item['created_at']
                    ) ?>

                </small>


                <?php if (
                    !empty(
                        $item['comment']
                    )
                ): ?>

                    <p>

                        <?= nl2br(
                            e(
                                $item['comment']
                            )
                        ) ?>

                    </p>

                <?php endif; ?>

            </div>

        <?php endforeach; ?>

    <?php endif; ?>

</div>


<?php

municipalityFooter();