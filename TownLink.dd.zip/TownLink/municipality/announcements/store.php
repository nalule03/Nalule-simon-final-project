<?php

declare(strict_types=1);

require_once __DIR__ . '/../auth.php';

if (!isMunicipalityAdmin()) {
    http_response_code(403);
    exit('Access denied.');
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: create.php');
    exit;
}

$title = trim($_POST['title'] ?? '');
$content = trim($_POST['content'] ?? '');
$status = trim($_POST['status'] ?? 'draft');

$publishAt = trim($_POST['publish_at'] ?? '');
$expiresAt = trim($_POST['expires_at'] ?? '');

$validStatuses = [
    'draft',
    'published',
    'archived'
];

if ($title === '') {
    exit('Title is required.');
}

if ($content === '') {
    exit('Content is required.');
}

if (!in_array($status, $validStatuses, true)) {
    exit('Invalid status.');
}

$publishAt = $publishAt !== ''
    ? date('Y-m-d H:i:s', strtotime($publishAt))
    : null;

$expiresAt = $expiresAt !== ''
    ? date('Y-m-d H:i:s', strtotime($expiresAt))
    : null;

$sql = "
    INSERT INTO announcements (
        municipality_id,
        title,
        content,
        publish_at,
        expires_at,
        status,
        created_by,
        created_at,
        updated_at
    )
    VALUES (
        :municipality_id,
        :title,
        :content,
        :publish_at,
        :expires_at,
        :status,
        :created_by,
        NOW(),
        NOW()
    )
";

$stmt = $pdo->prepare($sql);

$stmt->execute([
    ':municipality_id' => $municipalityId,
    ':title' => $title,
    ':content' => $content,
    ':publish_at' => $publishAt,
    ':expires_at' => $expiresAt,
    ':status' => $status,
    ':created_by' => $_SESSION['user_id']
]);

header('Location: index.php');
exit;