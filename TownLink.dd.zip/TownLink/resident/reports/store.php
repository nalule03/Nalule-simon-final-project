<?php

declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| TownLink - Resident Report Submission
|--------------------------------------------------------------------------
| Location: resident/reports/store.php
|
| Purpose:
| - Allow authenticated residents to submit community reports.
| - Verify the resident's role and municipality.
| - Validate CSRF tokens and submitted fields.
| - Save reports under the resident's own municipality.
| - Never allow residents to assign reports to another municipality.
|--------------------------------------------------------------------------
*/

require_once __DIR__ . '/_common.php';

/*
|--------------------------------------------------------------------------
| 1. AUTHENTICATION
|--------------------------------------------------------------------------
*/

report_require_login();

if (report_role() !== 'resident') {
    http_response_code(403);
    exit('Only residents can submit reports.');
}

$userId = (int) ($_SESSION['user_id'] ?? 0);

if ($userId <= 0) {
    http_response_code(401);
    exit('Please sign in again.');
}

/*
|--------------------------------------------------------------------------
| 2. CSRF VALIDATION
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: create.php');
    exit;
}

if (!report_verify_csrf()) {
    http_response_code(403);
    exit('Invalid or expired form token. Please try again.');
}

/*
|--------------------------------------------------------------------------
| 3. VERIFY RESIDENT AND MUNICIPALITY
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT municipality_id
    FROM users
    WHERE id = :user_id
      AND role = 'resident'
      AND status = 'active'
    LIMIT 1
");

$stmt->execute([
    ':user_id' => $userId,
]);

$resident = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$resident) {
    http_response_code(403);
    exit('Your resident account could not be verified.');
}

$municipalityId = (int) ($resident['municipality_id'] ?? 0);

if ($municipalityId <= 0) {
    http_response_code(403);
    exit('Your account is not assigned to a municipality.');
}

/*
|--------------------------------------------------------------------------
| 4. READ FORM FIELDS
|--------------------------------------------------------------------------
*/

$fullName = trim((string) ($_POST['full_name'] ?? ''));
$erfNumber = trim((string) ($_POST['erf_number'] ?? ''));
$category = trim((string) ($_POST['category'] ?? ''));
$streetName = trim((string) ($_POST['street_name'] ?? ''));
$location = trim((string) ($_POST['location'] ?? ''));
$description = trim((string) ($_POST['description'] ?? ''));

/*
|--------------------------------------------------------------------------
| 5. VALIDATE FORM FIELDS
|--------------------------------------------------------------------------
*/

if ($fullName === '' || mb_strlen($fullName) > 201) {
    exit('Please enter a valid full name.');
}

if ($erfNumber === '' || mb_strlen($erfNumber) > 50) {
    exit('Please enter a valid ERF or plot number.');
}

$validCategories = [
    'Roads',
    'Water',
    'Sewerage',
    'Waste',
    'Streetlights',
    'Stormwater',
    'Public Safety',
    'Public Facilities',
    'Parks',
    'Animals',
    'Electricity',
    'Other',
];

if (!in_array($category, $validCategories, true)) {
    exit('Please select a valid report category.');
}

if ($streetName === '' || mb_strlen($streetName) > 150) {
    exit('Please enter a valid street name.');
}

if (mb_strlen($location) > 255) {
    exit('The location must not exceed 255 characters.');
}

$descriptionLength = mb_strlen($description);

if ($descriptionLength < 20 || $descriptionLength > 10000) {
    exit('The description must contain between 20 and 10000 characters.');
}

/*
|--------------------------------------------------------------------------
| 6. VALIDATE OPTIONAL PHOTOGRAPHS
|--------------------------------------------------------------------------
|
| This section validates uploads only. Files are not saved yet.
| File storage requires an upload directory and corresponding database
| design, which should be confirmed before enabling photo persistence.
|--------------------------------------------------------------------------
*/

$maxFiles = 3;
$maxFileSize = 5 * 1024 * 1024;

$allowedMimeTypes = [
    'image/jpeg',
    'image/png',
    'image/webp',
];

if (isset($_FILES['photos'])) {
    $photos = $_FILES['photos'];

    if (
        !isset($photos['name'], $photos['tmp_name'],
               $photos['error'], $photos['size'])
        || !is_array($photos['name'])
        || !is_array($photos['tmp_name'])
        || !is_array($photos['error'])
        || !is_array($photos['size'])
    ) {
        exit('Invalid photo upload data.');
    }

    $photoCount = count($photos['name']);

    if ($photoCount > $maxFiles) {
        exit('You may upload a maximum of 3 photographs.');
    }

    $finfo = new finfo(FILEINFO_MIME_TYPE);

    foreach ($photos['name'] as $index => $originalName) {
        $error = $photos['error'][$index] ?? UPLOAD_ERR_NO_FILE;

        if ($error === UPLOAD_ERR_NO_FILE) {
            continue;
        }

        if ($error !== UPLOAD_ERR_OK) {
            exit('A photograph could not be uploaded. Please try again.');
        }

        $tmpName = $photos['tmp_name'][$index] ?? '';
        $fileSize = (int) ($photos['size'][$index] ?? 0);

        if (
            !is_string($tmpName)
            || !is_uploaded_file($tmpName)
            || $fileSize <= 0
            || $fileSize > $maxFileSize
        ) {
            exit('Each photograph must be no larger than 5 MB.');
        }

        $mimeType = $finfo->file($tmpName);

        if (!in_array($mimeType, $allowedMimeTypes, true)) {
            exit('Only JPG, PNG and WebP photographs are allowed.');
        }
    }
}

/*
|--------------------------------------------------------------------------
| 7. PREPARE REPORT
|--------------------------------------------------------------------------
|
| Residents submit new reports. They must not choose an administrative
| status or priority through manually crafted POST requests.
|
| The existing reports table supports:
| municipality_id, title, description, status, priority,
| created_by and resolved_at.
|--------------------------------------------------------------------------
*/

$title = $category;
$status = 'submitted';
$priority = 'medium';
$resolvedAt = null;

/*
|--------------------------------------------------------------------------
| 8. SAVE REPORT
|--------------------------------------------------------------------------
*/

try {
    $pdo->beginTransaction();

    $sql = "
        INSERT INTO reports (
            municipality_id,
            title,
            description,
            status,
            priority,
            created_by,
            resolved_at
        )
        VALUES (
            :municipality_id,
            :title,
            :description,
            :status,
            :priority,
            :created_by,
            :resolved_at
        )
    ";

    $stmt = $pdo->prepare($sql);

    $stmt->execute([
        ':municipality_id' => $municipalityId,
        ':title' => $title,
        ':description' => $description,
        ':status' => $status,
        ':priority' => $priority,
        ':created_by' => $userId,
        ':resolved_at' => $resolvedAt,
    ]);

    $reportId = (int) $pdo->lastInsertId();

    if ($reportId <= 0) {
        throw new RuntimeException('The report ID could not be generated.');
    }

    $pdo->commit();

    header('Location: view.php?id=' . $reportId);
    exit;

} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    error_log(
        'TownLink resident report submission failed: ' .
        $e->getMessage()
    );

    http_response_code(500);

    exit(
        'Your report could not be submitted. Please try again later.'
    );
}