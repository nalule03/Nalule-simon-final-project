<?php

declare(strict_types=1);

require_once __DIR__ . '/../auth.php';
require_once __DIR__ . '/../layout.php';

if (!isMunicipalityAdmin()) {
    http_response_code(403);
    exit('Access denied.');
}

$id = filter_input(
    INPUT_GET,
    'id',
    FILTER_VALIDATE_INT
);

if (!$id) {
    http_response_code(400);
    exit('Invalid announcement ID.');
}

$sql = "
    SELECT
        id,
        title,
        content,
        publish_at,
        expires_at,
        status

    FROM announcements

    WHERE
        id = :id
        AND municipality_id = :municipality_id

    LIMIT 1
";

$stmt = $pdo->prepare($sql);

$stmt->execute([
    ':id' => $id,
    ':municipality_id' => $municipalityId
]);

$announcement = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$announcement) {
    http_response_code(404);
    exit('Announcement not found.');
}

function datetimeLocalValue(?string $value): string
{
    if (!$value) {
        return '';
    }

    $timestamp = strtotime($value);

    if ($timestamp === false) {
        return '';
    }

    return date('Y-m-d\TH:i', $timestamp);
}

municipalityHeader(
    'Edit Announcement',
    'announcements'
);

?>

<div class="page-header">

    <div>

        <h2>Edit Announcement</h2>

        <p>
            Update this announcement.
        </p>

    </div>

</div>

<div class="card">

    <form
        method="POST"
        action="update.php"
    >

        <input
            type="hidden"
            name="id"
            value="<?= (int) $announcement['id'] ?>"
        >

        <div class="form-grid">

            <div>

                <label for="title">
                    Title
                </label>

                <input
                    type="text"
                    id="title"
                    name="title"
                    required
                    maxlength="255"
                    value="<?= e(
                        $announcement['title']
                    ) ?>"
                >

            </div>

            <div>

                <label for="status">
                    Status
                </label>

                <select
                    id="status"
                    name="status"
                    required
                >

                    <?php
                    $statuses = [
                        'draft',
                        'published',
                        'archived'
                    ];
                    ?>

                    <?php foreach ($statuses as $status): ?>

                        <option
                            value="<?= e($status) ?>"
                            <?= $announcement['status'] === $status
                                ? 'selected'
                                : '' ?>
                        >
                            <?= e(ucfirst($status)) ?>
                        </option>

                    <?php endforeach; ?>

                </select>

            </div>

        </div>

        <br>

        <label for="content">
            Content
        </label>

        <textarea
            id="content"
            name="content"
            rows="12"
            required
        ><?= e(
            $announcement['content']
        ) ?></textarea>

        <br><br>

        <div class="form-grid">

            <div>

                <label for="publish_at">
                    Publish Date
                </label>

                <input
                    type="datetime-local"
                    id="publish_at"
                    name="publish_at"
                    value="<?= e(
                        datetimeLocalValue(
                            $announcement['publish_at']
                        )
                    ) ?>"
                >

            </div>

            <div>

                <label for="expires_at">
                    Expiry Date
                </label>

                <input
                    type="datetime-local"
                    id="expires_at"
                    name="expires_at"
                    value="<?= e(
                        datetimeLocalValue(
                            $announcement['expires_at']
                        )
                    ) ?>"
                >

            </div>

        </div>

        <br>

        <button
            type="submit"
            class="button"
        >
            Update Announcement
        </button>

        <a
            class="button secondary"
            href="view.php?id=<?= (int) $announcement['id'] ?>"
        >
            Cancel
        </a>

    </form>

</div>

<?php

municipalityFooter();