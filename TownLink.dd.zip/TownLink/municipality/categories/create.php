<?php

declare(strict_types=1);

require_once __DIR__ . '/../auth.php';
require_once __DIR__ . '/../layout.php';

requireMunicipalityAdmin();

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    verifyCsrf();

    $name = trim($_POST['name'] ?? '');
    $description = trim($_POST['description'] ?? '');

    if ($name === '') {

        $error = 'Category name is required.';

    } else {

        try {

            $stmt = $pdo->prepare("
                SELECT id
                FROM service_categories
                WHERE municipality_id = :municipality_id
                AND name = :name
                LIMIT 1
            ");

            $stmt->execute([
                ':municipality_id' => $municipalityId,
                ':name' => $name
            ]);

            if ($stmt->fetch()) {

                $error =
                    'A category with this name already exists.';

            } else {

                $stmt = $pdo->prepare("
                    INSERT INTO service_categories
                    (
                        municipality_id,
                        name,
                        description,
                        status
                    )
                    VALUES
                    (
                        :municipality_id,
                        :name,
                        :description,
                        'active'
                    )
                ");

                $stmt->execute([
                    ':municipality_id' => $municipalityId,
                    ':name' => $name,
                    ':description' =>
                        $description !== ''
                        ? $description
                        : null
                ]);

                $categoryId =
                    (int) $pdo->lastInsertId();

                auditLog(
                    $pdo,
                    $municipalityId,
                    $userId,
                    'create',
                    'service_category',
                    $categoryId,
                    'Created service category: ' . $name
                );

                header(
                    'Location: index.php'
                );

                exit;
            }

        } catch (PDOException $e) {

            error_log(
                'Category create error: ' .
                $e->getMessage()
            );

            $error =
                'Unable to create the category.';
        }
    }
}

municipalityHeader(
    'Add Service Category',
    'categories'
);

?>

<div class="page-header">

    <div>
        <h2>Add Service Category</h2>
        <p>Create a category for municipal services.</p>
    </div>

</div>

<?php if ($error !== ''): ?>

    <div class="alert error">
        <?= e($error) ?>
    </div>

<?php endif; ?>

<div class="card">

    <form method="POST">

        <input
            type="hidden"
            name="csrf_token"
            value="<?= e(csrfToken()) ?>"
        >

        <div class="form-grid">

            <div>

                <label for="name">
                    Category Name
                </label>

                <input
                    id="name"
                    name="name"
                    maxlength="150"
                    required
                    value="<?= e(
                        $_POST['name'] ?? ''
                    ) ?>"
                >

            </div>

            <div class="full">

                <label for="description">
                    Description
                </label>

                <textarea
                    id="description"
                    name="description"
                ><?= e(
                    $_POST['description'] ?? ''
                ) ?></textarea>

            </div>

        </div>

        <br>

        <button class="button">
            Create Category
        </button>

        <a
            class="button secondary"
            href="index.php"
        >
            Cancel
        </a>

    </form>

</div>

<?php

municipalityFooter();
