<?php
require_once __DIR__ . '/_common.php';

report_require_login();

if (report_role() !== 'resident') {
    http_response_code(403);
    exit('Access denied. This page is for residents only.');
}

$userId = (int) ($_SESSION['user_id'] ?? 0);
$municipalityId = (int) ($_SESSION['municipality_id'] ?? 0);

if ($userId <= 0 || $municipalityId <= 0) {
    http_response_code(403);
    exit('Your account is not linked to a municipality.');
}

/*
|--------------------------------------------------------------------------
| Validate report ID
|--------------------------------------------------------------------------
| Expected URL: view.php?id=12
*/

$idValue = $_GET['id'] ?? null;

if (
    !is_scalar($idValue) ||
    (string) $idValue === '' ||
    !ctype_digit((string) $idValue) ||
    (int) $idValue < 1
) {
    http_response_code(400);
    exit('Invalid report ID. Return to My Reports and click View.');
}

$id = (int) $idValue;

/*
|--------------------------------------------------------------------------
| Fetch the resident's report
|--------------------------------------------------------------------------
*/

try {
    $sql = "
        SELECT r.*
        FROM reports r
        WHERE r.id = :id
          AND r.municipality_id = :municipality_id
          AND r.created_by = :user_id
        LIMIT 1
    ";

    $stmt = $pdo->prepare($sql);

    $stmt->execute([
        ':id' => $id,
        ':municipality_id' => $municipalityId,
        ':user_id' => $userId
    ]);

    $report = $stmt->fetch(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    error_log('TownLink view report error: ' . $e->getMessage());

    http_response_code(500);
    exit('A database error occurred while loading the report. Check your PHP error log.');
}

if (!$report) {
    http_response_code(404);
    exit('Report not found, or you do not have permission to view it.');
}

report_header('View My Report');

$status = (string) ($report['status'] ?? 'submitted');
$priority = (string) ($report['priority'] ?? 'medium');

$title = (string) (
    $report['title']
    ?? $report['category']
    ?? 'Community Issue'
);

$escapeField = static function (
    array $data,
    string $key,
    string $fallback = 'Not provided'
): string {
    $value = $data[$key] ?? null;

    if ($value === null || $value === '') {
        return report_escape($fallback);
    }

    return report_escape((string) $value);
};
?>

<style>
.report-view-page {
    max-width: 900px;
    margin: 0 auto;
}

.report-view-intro {
    background: #e8f5ef;
    border: 1px solid #d4e9de;
    border-radius: 16px;
    padding: 24px;
    margin: 18px 0 24px;
}

.report-view-intro h1 {
    color: #123b32;
    font-weight: 800;
}

.report-view-card {
    background: #fff;
    border: 1px solid #e1e9e5;
    border-radius: 16px;
    padding: 28px;
    margin-bottom: 24px;
    box-shadow: 0 5px 22px rgba(20,55,43,.05);
}

.report-view-grid {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 22px;
}

.report-view-label {
    display: block;
    color: #718078;
    font-size: .9rem;
    margin-bottom: 6px;
}

.report-view-value {
    color: #123b32;
    font-weight: 600;
    overflow-wrap: anywhere;
}

.report-view-description {
    white-space: pre-wrap;
    overflow-wrap: anywhere;
    line-height: 1.7;
}

.report-view-status {
    display: inline-block;
    padding: 6px 12px;
    border-radius: 20px;
    background: #e0f2fe;
    color: #075985;
    font-size: .85rem;
    font-weight: 700;
}

.report-view-status.in_progress {
    background: #fef3c7;
    color: #92400e;
}

.report-view-status.resolved {
    background: #dcfce7;
    color: #166534;
}

.report-view-status.rejected {
    background: #fee2e2;
    color: #991b1b;
}

.report-view-status.archived,
.report-view-status.draft {
    background: #f1f5f9;
    color: #475569;
}

@media (max-width: 576px) {
    .report-view-card,
    .report-view-intro {
        padding: 20px 16px;
    }

    .report-view-grid {
        grid-template-columns: 1fr;
        gap: 18px;
    }
}
</style>

<div class="report-view-page">

    <a href="index.php" class="text-decoration-none">
        <i class="bi bi-arrow-left"></i>
        Back to My Reports
    </a>

    <section class="report-view-intro">
        <h1 class="h3 mb-2">Community Report Details</h1>
        <p class="mb-0">
            View the information and progress of your community report.
        </p>
    </section>

    <section class="report-view-card">

        <div class="d-flex justify-content-between align-items-start flex-wrap gap-3">

            <div>
                <span class="report-view-label">Report number</span>
                <div class="report-view-value">
                    #<?= (int) $report['id'] ?>
                </div>
            </div>

            <div>
                <span class="report-view-status <?= report_escape($status) ?>">
                    <?= report_escape(
                        ucwords(str_replace('_', ' ', $status))
                    ) ?>
                </span>
            </div>

        </div>

        <hr class="my-4">

        <div class="report-view-grid">

            <div>
                <span class="report-view-label">Issue title / category</span>
                <div class="report-view-value">
                    <?= report_escape($title) ?>
                </div>
            </div>

            <div>
                <span class="report-view-label">Priority</span>
                <div class="report-view-value">
                    <?= report_escape(ucfirst($priority)) ?>
                </div>
            </div>

            <div>
                <span class="report-view-label">Submitted by</span>
                <div class="report-view-value">
                    <?= $escapeField($report, 'full_name', 'Resident') ?>
                </div>
            </div>

            <div>
                <span class="report-view-label">ERF / Plot number</span>
                <div class="report-view-value">
                    <?= $escapeField($report, 'erf_number') ?>
                </div>
            </div>

            <div>
                <span class="report-view-label">Street name</span>
                <div class="report-view-value">
                    <?= $escapeField($report, 'street_name') ?>
                </div>
            </div>

            <div>
                <span class="report-view-label">Location / Landmark</span>
                <div class="report-view-value">
                    <?= $escapeField($report, 'location') ?>
                </div>
            </div>

            <div>
                <span class="report-view-label">Date submitted</span>
                <div class="report-view-value">
                    <?= $escapeField($report, 'created_at') ?>
                </div>
            </div>

            <div>
                <span class="report-view-label">Last updated</span>
                <div class="report-view-value">
                    <?= $escapeField($report, 'updated_at') ?>
                </div>
            </div>

            <div>
                <span class="report-view-label">Date resolved</span>
                <div class="report-view-value">
                    <?= $escapeField($report, 'resolved_at', 'Not resolved') ?>
                </div>
            </div>

        </div>

        <hr class="my-4">

        <h2 class="h5 mb-3">Description of the issue</h2>

        <div class="report-view-description">
            <?= report_escape(
                (string) ($report['description'] ?? 'No description provided.')
            ) ?>
        </div>

        <div class="mt-4">
            <a href="index.php" class="btn btn-outline-success">
                <i class="bi bi-arrow-left"></i>
                Back to My Reports
            </a>
        </div>

    </section>

</div>

<?php report_footer(); ?>