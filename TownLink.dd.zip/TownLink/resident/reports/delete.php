<?php

declare(strict_types=1);

require_once __DIR__ . '/../_auth.php';

if (!isMunicipalityAdmin()) {
    http_response_code(403);
    exit('Access denied.');
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.php');
    exit;
}

$id = filter_input(
    INPUT_POST,
    'id',
    FILTER_VALIDATE_INT
);

if (!$id) {
    http_response_code(400);
    exit('Invalid report ID.');
}

$sql = "
    DELETE FROM reports

    WHERE
        id = :id
        AND municipality_id = :municipality_id
";

$stmt = $pdo->prepare($sql);

$stmt->execute([
    ':id' => $id,
    ':municipality_id' => $municipalityId
]);

header('Location: index.php');

exit;