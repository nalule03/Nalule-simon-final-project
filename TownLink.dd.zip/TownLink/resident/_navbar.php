<?php

declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| TownLink - Shared Resident Navbar
|--------------------------------------------------------------------------
*/

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

/*
|--------------------------------------------------------------------------
| Escape output
|--------------------------------------------------------------------------
*/

if (!function_exists('townlinkNavEscape')) {
    function townlinkNavEscape(mixed $value): string
    {
        return htmlspecialchars(
            (string) ($value ?? ''),
            ENT_QUOTES | ENT_SUBSTITUTE,
            'UTF-8'
        );
    }
}

/*
|--------------------------------------------------------------------------
| Resident information
|--------------------------------------------------------------------------
*/

$navFirstName = trim(
    (string) ($_SESSION['first_name'] ?? '')
);

$navLastName = trim(
    (string) ($_SESSION['last_name'] ?? '')
);

$navFullName = trim(
    $navFirstName . ' ' . $navLastName
);

if ($navFullName === '') {
    $navFullName = trim(
        (string) ($_SESSION['name'] ?? 'Resident')
    );
}

if ($navFullName === '') {
    $navFullName = 'Resident';
}

$navInitial = strtoupper(
    substr($navFullName, 0, 1)
);

/*
|--------------------------------------------------------------------------
| Detect current page
|--------------------------------------------------------------------------
|
| Files in resident/ use local paths.
| Files in resident/reports/ use ../ to reach resident/.
|
*/

$navCurrentPath = str_replace(
    '\\',
    '/',
    (string) ($_SERVER['PHP_SELF'] ?? '')
);

$navIsReportsPage = str_contains(
    $navCurrentPath,
    '/resident/reports/'
);

$navBase = $navIsReportsPage ? '../' : '';

$navCurrentFile = basename($navCurrentPath);

/*
|--------------------------------------------------------------------------
| Navigation URLs
|--------------------------------------------------------------------------
*/

$dashboardUrl = $navBase . 'dashboard.php';
$servicesUrl = $navBase . 'services.php';
$requestsUrl = $navBase . 'requests.php';
$reportsUrl = $navBase . 'reports/index.php';
$notificationsUrl = $navBase . 'notifications.php';
$profileUrl = $navBase . 'profile.php';

$logoutUrl = $navIsReportsPage
    ? '../../public/logout.php'
    : '../public/logout.php';

/*
|--------------------------------------------------------------------------
| Shared navigation items
|--------------------------------------------------------------------------
*/

$navLinks = [
    [
        'label' => 'Dashboard',
        'icon' => 'bi-grid-1x2',
        'href' => $dashboardUrl,
        'files' => ['dashboard.php'],
    ],
    [
        'label' => 'Services',
        'icon' => 'bi-building',
        'href' => $servicesUrl,
        'files' => ['services.php'],
    ],
    [
        'label' => 'Reports',
        'icon' => 'bi-megaphone',
        'href' => $reportsUrl,
        'files' => ['../reports/index.php'],
    ],
    [
        'label' => 'Notifications',
        'icon' => 'bi-bell',
        'href' => $notificationsUrl,
        'files' => ['notifications.php'],
    ],
    [
        'label' => 'My Profile',
        'icon' => 'bi-person-circle',
        'href' => $profileUrl,
        'files' => ['profile.php'],
    ],
];

/*
|--------------------------------------------------------------------------
| Bootstrap Icons stylesheet
|--------------------------------------------------------------------------
*/

?>

<link
    rel="stylesheet"
    href="<?= townlinkNavEscape($navBase) ?>assets/vendor/bootstrap-icons/bootstrap-icons.css"
>

        <link
    rel="stylesheet"
    href="<?= townlinkNavEscape($navBase) ?>assets/vendor/bootstrap-icons/bootstrap-icons.css"
>

<style>
    :root {
        --tl-green: #176b52;
        --tl-green-dark: #103d32;
        --tl-green-deep: #0b2d26;
        --tl-green-soft: #e8f5ef;
        --tl-nav-border: #e5eee9;
        --tl-nav-muted: #718078;
    }

    .tl-navbar,
    .tl-navbar * {
        box-sizing: border-box;
    }

    .tl-navbar {
        position: sticky;
        top: 0;
        z-index: 1030;
        width: 100%;
        background: rgba(255, 255, 255, .97);
        border-bottom: 1px solid var(--tl-nav-border);
        box-shadow: 0 5px 24px rgba(16, 61, 50, .045);
        backdrop-filter: blur(14px);
        font-family: "Segoe UI", Arial, sans-serif;
    }

    .tl-nav-container {
        max-width: 1440px;
        min-height: 76px;
        margin: 0 auto;
        padding: 0 32px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 25px;
    }

    /* Brand */

    .tl-brand {
        display: inline-flex;
        flex-shrink: 0;
        align-items: center;
        gap: 11px;
        color: var(--tl-green-dark);
        text-decoration: none;
    }

    .tl-brand:hover {
        color: var(--tl-green);
    }

    .tl-brand-mark {
        width: 43px;
        height: 43px;
        display: grid;
        place-items: center;
        border-radius: 13px;
        background: linear-gradient(
            145deg,
            #218663,
            #103d32
        );
        color: #fff;
        font-size: 23px;
        box-shadow: 0 5px 12px rgba(23, 107, 82, .18);
    }

    .tl-brand-name {
        display: block;
        font-size: 23px;
        font-weight: 850;
        letter-spacing: -.9px;
        line-height: 1.1;
    }

    .tl-brand-name span {
        color: var(--tl-green);
    }

    .tl-brand-caption {
        display: block;
        margin-top: 4px;
        color: var(--tl-nav-muted);
        font-size: 10px;
        font-weight: 700;
        letter-spacing: 1.5px;
        text-transform: uppercase;
    }

    /* Navigation links */

    .tl-nav-links {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 4px;
        margin: 0;
        padding: 0;
        list-style: none;
    }

    .tl-nav-link {
        position: relative;
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 12px 13px;
        border-radius: 10px;
        color: #52645b;
        text-decoration: none;
        font-size: 13px;
        font-weight: 700;
        white-space: nowrap;
        transition: color .2s, background .2s;
    }

    .tl-nav-link i {
        font-size: 16px;
    }

    .tl-nav-link:hover {
        background: #f0f7f3;
        color: var(--tl-green);
    }

    .tl-nav-link.is-active {
        background: var(--tl-green-soft);
        color: var(--tl-green-dark);
    }

    .tl-nav-link.is-active::after {
        position: absolute;
        right: 13px;
        bottom: -8px;
        left: 13px;
        height: 3px;
        border-radius: 3px;
        background: var(--tl-green);
        content: "";
    }

    /* Resident account */

    .tl-nav-account {
        display: flex;
        align-items: center;
        gap: 11px;
        flex-shrink: 0;
    }

    .tl-nav-avatar {
        width: 40px;
        height: 40px;
        display: grid;
        flex-shrink: 0;
        place-items: center;
        border: 2px solid #d4eee1;
        border-radius: 50%;
        background: var(--tl-green-soft);
        color: var(--tl-green-dark);
        font-size: 14px;
        font-weight: 800;
    }

    .tl-nav-user {
        max-width: 140px;
        overflow: hidden;
        color: #263c32;
        font-size: 12px;
        font-weight: 800;
        text-overflow: ellipsis;
        white-space: nowrap;
    }

    .tl-nav-role {
        display: block;
        margin-top: 3px;
        color: var(--tl-nav-muted);
        font-size: 10px;
        font-weight: 600;
    }

    /* Logout */

    .tl-logout {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 7px;
        padding: 10px 13px;
        border: 1px solid #e2ebe5;
        border-radius: 10px;
        color: #52645b;
        text-decoration: none;
        font-size: 12px;
        font-weight: 800;
        transition: .2s;
    }

    .tl-logout:hover {
        border-color: #f1c9c5;
        background: #fff3f2;
        color: #b42318;
    }

    /* Mobile menu button */

    .tl-nav-toggle {
        display: none;
        width: 43px;
        height: 43px;
        align-items: center;
        justify-content: center;
        border: 1px solid var(--tl-nav-border);
        border-radius: 11px;
        background: #fff;
        color: var(--tl-green-dark);
        font-size: 23px;
        cursor: pointer;
    }

    .tl-nav-toggle:focus-visible,
    .tl-nav-link:focus-visible,
    .tl-logout:focus-visible {
        outline: 3px solid #9acdb8;
        outline-offset: 3px;
    }

    /* Tablet */

    @media (max-width: 1150px) {
        .tl-nav-container {
            padding: 0 20px;
            gap: 12px;
        }

        .tl-nav-link {
            padding: 11px 9px;
            font-size: 12px;
        }

        .tl-nav-link i {
            display: none;
        }

        .tl-nav-user {
            display: none;
        }
    }

    /* Mobile */

    @media (max-width: 900px) {
        .tl-nav-container {
            min-height: 70px;
            flex-wrap: wrap;
            padding: 12px 18px;
        }

        .tl-nav-toggle {
            display: inline-flex;
            margin-left: auto;
        }

        .tl-nav-account {
            gap: 8px;
        }

        .tl-nav-links {
            display: none;
            order: 5;
            width: 100%;
            flex-direction: column;
            align-items: stretch;
            padding: 10px 0 4px;
            border-top: 1px solid var(--tl-nav-border);
        }

        .tl-nav-links.is-open {
            display: flex;
        }

        .tl-nav-link {
            width: 100%;
            padding: 13px 14px;
            font-size: 14px;
        }

        .tl-nav-link i {
            display: inline-block;
            width: 20px;
        }

        .tl-nav-link.is-active::after {
            top: 10px;
            right: auto;
            bottom: 10px;
            left: 0;
            width: 3px;
            height: auto;
        }

        .tl-nav-user {
            display: none;
        }
    }

    @media (max-width: 420px) {
        .tl-brand-name {
            font-size: 21px;
        }

        .tl-brand-caption {
            font-size: 9px;
        }

        .tl-brand-mark {
            width: 39px;
            height: 39px;
        }

        .tl-logout {
            padding: 9px 10px;
            font-size: 11px;
        }

        .tl-logout span {
            display: none;
        }
    }

    @media (prefers-reduced-motion: reduce) {
        .tl-navbar * {
            transition: none !important;
        }
    }
</style>

<header class="tl-navbar">
    <nav
        class="tl-nav-container"
        aria-label="Resident navigation"
    >

        <!-- Brand -->

        <a
            class="tl-brand"
            href="<?= townlinkNavEscape($dashboardUrl) ?>"
            aria-label="TownLink Resident Dashboard"
        >
            <span class="tl-brand-mark" aria-hidden="true">
                <i class="bi bi-buildings"></i>
            </span>

            <span>
                <span class="tl-brand-name">
                    Town<span>Link</span>
                </span>

                <span class="tl-brand-caption">
                    Resident Services
                </span>
            </span>
        </a>

        <!-- Mobile toggle -->

        <button
            class="tl-nav-toggle"
            type="button"
            id="tlNavToggle"
            aria-label="Toggle navigation"
            aria-controls="tlNavLinks"
            aria-expanded="false"
        >
            <i class="bi bi-list" aria-hidden="true"></i>
        </button>

        <!-- Navigation -->

        <ul class="tl-nav-links" id="tlNavLinks">

            <?php foreach ($navLinks as $link): ?>

                <?php

                $isActive = false;

                if (
                    $link['label'] === 'Reports'
                    && $navIsReportsPage
                ) {
                    $isActive = true;
                } elseif (
                    $link['label'] !== 'Reports'
                    && in_array(
                        $navCurrentFile,
                        $link['files'],
                        true
                    )
                ) {
                    $isActive = true;
                }

                ?>

                <li>
                    <a
                        class="tl-nav-link<?= $isActive ? ' is-active' : '' ?>"
                        href="<?= townlinkNavEscape($link['href']) ?>"
                        <?= $isActive ? 'aria-current="page"' : '' ?>
                    >
                        <i
                            class="bi <?= townlinkNavEscape($link['icon']) ?>"
                            aria-hidden="true"
                        ></i>

                        <?= townlinkNavEscape($link['label']) ?>
                    </a>
                </li>

            <?php endforeach; ?>

        </ul>

        <!-- Resident account and logout -->

        <div class="tl-nav-account">


            <a
                class="tl-logout"
                href="<?= townlinkNavEscape($logoutUrl) ?>"
            >
                <i class="bi bi-box-arrow-right" aria-hidden="true"></i>
                <span>Logout</span>
            </a>

        </div>

    </nav>
</header>

<script>
(function () {
    const toggle = document.getElementById('tlNavToggle');
    const links = document.getElementById('tlNavLinks');

    if (!toggle || !links) {
        return;
    }

    toggle.addEventListener('click', function () {
        const isOpen = links.classList.toggle('is-open');

        toggle.setAttribute(
            'aria-expanded',
            String(isOpen)
        );

        toggle.setAttribute(
            'aria-label',
            isOpen ? 'Close navigation' : 'Open navigation'
        );

        toggle.innerHTML = isOpen
            ? '<i class="bi bi-x-lg" aria-hidden="true"></i>'
            : '<i class="bi bi-list" aria-hidden="true"></i>';
    });
})();
</script>