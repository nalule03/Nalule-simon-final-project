<?php

declare(strict_types=1);

require_once __DIR__ . '/../auth.php';

requireMunicipalityAdmin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Method not allowed.');
}

verifyCsrf();

$id = filter_input(
    INPUT_POST,
    'id',
    FILTER_VALIDATE_INT
);

if (!$id) {
    http_response_code(400);
    exit('Invalid category.');
}

try {

    $stmt = $pdo->prepare("
        SELECT name
        FROM service_categories
        WHERE id = :id
        AND municipality_id = :municipality_id
        LIMIT 1
    ");

    $stmt->execute([
        ':id' => $id,
        ':municipality_id' => $municipalityId
    ]);

    $category =
        $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$category) {
        http_response_code(404);
        exit('Category not found.');
    }

    $stmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM services
        WHERE category_id = :id
    ");

    $stmt->execute([
        ':id' => $id
    ]);

    if ((int) $stmt->fetchColumn() > 0) {

        header(
            'Location: index.php?error=has_services'
        );

        exit;
    }

    $stmt = $pdo->prepare("
        DELETE FROM service_categories
        WHERE id = :id
        AND municipality_id = :municipality_id
    ");

    $stmt->execute([
        ':id' => $id,
        ':municipality_id' => $municipalityId
    ]);

    auditLog(
        $pdo,
        $municipalityId,
        $userId,
        'delete',
        'service_category',
        $id,
        'Deleted service category: ' .
        $category['name']
    );

    header(
        'Location: index.php'
    );

    exit;

} catch (PDOException $e) {

    error_log(
        'Category delete error: ' .
        $e->getMessage()
    );

    http_response_code(500);
    exit('Unable to delete category.');
}
