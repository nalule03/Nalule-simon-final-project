<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| TownLink - Protect Request Evidence Storage
|--------------------------------------------------------------------------
*/

http_response_code(403);
header('Content-Type: text/plain; charset=UTF-8');

exit('Access denied.');