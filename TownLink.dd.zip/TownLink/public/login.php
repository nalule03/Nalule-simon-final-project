<?php
declare(strict_types=1);

session_start();

require_once __DIR__ . '/../app/config/database.php';

$message = '';

function e($value): string
{
    return htmlspecialchars(
        (string)($value ?? ''),
        ENT_QUOTES,
        'UTF-8'
    );
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $email = trim((string)($_POST['email'] ?? ''));
    $password = (string)($_POST['password'] ?? '');

    if ($email === '' || $password === '') {

        $message = 'Please enter your email and password.';

    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

        $message = 'Please enter a valid email address.';

    } else {

        try {

            $stmt = $pdo->prepare("
                SELECT
                    id,
                    municipality_id,
                    department_id,
                    first_name,
                    last_name,
                    email,
                    password_hash,
                    role,
                    status,
                    must_change_password
                FROM users
                WHERE email = :email
                LIMIT 1
            ");

            $stmt->execute([':email' => $email]);

            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            error_log(
                'TownLink login diagnostic: ' . json_encode([
                    'user_found' => (bool) $user,
                    'role' => $user['role'] ?? null,
                    'status' => $user['status'] ?? null,
                    'hash_present' => !empty($user['password_hash']),
                    'hash_info' => !empty($user['password_hash'])
                        ? password_get_info($user['password_hash'])['algoName']
                        : null,
                ])
            );

            if (
                !$user ||
                !password_verify($password, $user['password_hash'])
            ) {

                $message = 'Invalid email or password.';

            } elseif ($user['status'] !== 'active') {

                $message = $user['status'] === 'suspended'
                    ? 'Your account has been suspended.'
                    : 'Your account is currently inactive.';

            } else {

                session_regenerate_id(true);

                $_SESSION['user_id'] = (int) $user['id'];

                $_SESSION['municipality_id'] =
                    $user['municipality_id'] !== null
                        ? (int) $user['municipality_id']
                        : null;

                $_SESSION['department_id'] =
                    $user['department_id'] !== null
                        ? (int) $user['department_id']
                        : null;

                $_SESSION['first_name'] = $user['first_name'];
                $_SESSION['last_name'] = $user['last_name'];
                $_SESSION['email'] = $user['email'];
                $_SESSION['role'] = $user['role'];

                $_SESSION['must_change_password'] =
                    (int) ($user['must_change_password'] ?? 0);

                $updateLogin = $pdo->prepare("
                    UPDATE users
                    SET last_login_at = CURRENT_TIMESTAMP
                    WHERE id = :id
                ");

                $updateLogin->execute([':id' => $user['id']]);

                try {

                    $audit = $pdo->prepare("
                        INSERT INTO audit_logs (
                            municipality_id,
                            user_id,
                            action,
                            entity_type,
                            entity_id,
                            description,
                            ip_address,
                            user_agent
                        )
                        VALUES (
                            :municipality_id,
                            :user_id,
                            'login',
                            'user',
                            :entity_id,
                            'User logged into TownLink.',
                            :ip_address,
                            :user_agent
                        )
                    ");

                    $audit->execute([
                        ':municipality_id' => $user['municipality_id'],
                        ':user_id' => $user['id'],
                        ':entity_id' => $user['id'],
                        ':ip_address' => $_SERVER['REMOTE_ADDR'] ?? null,
                        ':user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? null
                    ]);

                } catch (PDOException $auditError) {

                    error_log(
                        'TownLink login audit error: ' .
                        $auditError->getMessage()
                    );
                }

                if (
                    $user['role'] === 'municipality_admin' &&
                    (int) ($user['must_change_password'] ?? 0) === 1
                ) {
                    header('Location: ../municipality/change-password.php');
                    exit;
                }

                switch ($user['role']) {

            case 'resident':
                // Update this path if you have moved the resident dashboard.
                $destination = '../resident/dashboard.php';
                break;

            case 'municipality_admin':
            case 'department_staff':
                $destination = '../municipality/dashboard.php';
                break;

            case 'system_admin':
                $destination = '../SystemAdmin/index.php';
                break;

            default:
                session_unset();
                session_destroy();
                session_start();

                $message = 'Invalid account role. Please contact the administrator.';
                $destination = null;
                break;
        }

        if ($destination !== null) {
            header('Location: ' . $destination);
            exit;
        }

 
                switch ($user['role']) {

                    case 'resident':
                        header('Location: ../resident/');
                        exit;

                    case 'municipality_admin':
                    case 'department_staff':
                        header('Location: ../municipality/dashboard.php');
                        exit;

                    case 'system_admin':
                        header('Location: ../SystemAdmin/index.php');
                        exit;

                    default:
                        session_unset();
                        session_destroy();
                        session_start();

                        $message =
                            'Invalid account role. Please contact the administrator.';
                }
            }

        } catch (PDOException $exception) {

            error_log(
                'TownLink login error: ' . $exception->getMessage()
            );

            $message =
                'Unable to process your login right now. Please try again.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <meta
        name="description"
        content="Sign in to TownLink Namibia to access your municipal account and services."
    >

    <title>Login | TownLink Namibia</title>

    <link
        rel="stylesheet"
        href="../assets/vendor/bootstrap/css/bootstrap.min.css"
    >

    <link
        rel="stylesheet"
        href="../assets/vendor/bootstrap-icons/bootstrap-icons.css"
    >

    <style>
        :root {
            --green: #176b52;
            --green-dark: #123b32;
            --green-light: #e8f5ef;
            --text: #182b25;
            --muted: #718078;
            --border: #e1e9e5;
            --background: #f4f7f6;
        }

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: "Segoe UI", Arial, sans-serif;
            color: var(--text);
            background: var(--background);
            min-height: 100vh;
        }

        a {
            color: var(--green);
            text-decoration: none;
        }

        a:hover {
            color: var(--green-dark);
        }

        /* Navbar */

        .townlink-navbar {
            min-height: 76px;
            background: #fff;
            border-bottom: 1px solid var(--border);
            box-shadow: 0 3px 16px rgba(18, 59, 50, .045);
        }

        .brand {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            color: var(--green-dark);
            font-size: 1.4rem;
            font-weight: 800;
        }

        .brand:hover {
            color: var(--green-dark);
        }

        .brand-icon {
            width: 42px;
            height: 42px;
            display: grid;
            place-items: center;
            border-radius: 12px;
            background: var(--green-light);
            color: var(--green);
            font-size: 22px;
        }

        .brand-name span {
            color: var(--green);
        }

        .nav-home {
            color: #43534b;
            font-weight: 600;
        }

        .nav-home:hover {
            color: var(--green);
        }

        /* Login layout */

        .login-section {
            min-height: calc(100vh - 76px);
            display: flex;
            align-items: center;
            padding: 55px 0;
        }

        .login-wrapper {
            width: 100%;
            max-width: 1050px;
            margin: auto;
            overflow: hidden;
            background: #fff;
            border: 1px solid var(--border);
            border-radius: 22px;
            box-shadow: 0 12px 40px rgba(18, 59, 50, .07);
        }

        .login-row {
            min-height: 590px;
        }

        /* Picture area */

        .login-picture {
            position: relative;
            min-height: 590px;
            display: flex;
            align-items: flex-end;
            padding: 42px;
            color: #fff;
            background-color: var(--green-dark);

            /*
             * Place your image at:
             * .townlink-login.jpg./assets/images/
             */
        background-image:
        linear-gradient(
            180deg,
            rgba(18, 59, 50, .08),
            rgba(18, 59, 50, .90)
        ),
            url("community.jpg");

            background-position: center;
            background-size: cover;
            background-repeat: no-repeat;
        }

        .picture-content {
            position: relative;
            z-index: 1;
            max-width: 400px;
        }

        .picture-label {
            display: inline-block;
            padding: 7px 12px;
            margin-bottom: 16px;
            border: 1px solid rgba(255,255,255,.35);
            border-radius: 30px;
            background: rgba(255,255,255,.12);
            font-size: .82rem;
            font-weight: 600;
        }

        .picture-content h2 {
            font-size: clamp(1.8rem, 3vw, 2.5rem);
            font-weight: 800;
            line-height: 1.2;
            margin-bottom: 14px;
        }

        .picture-content p {
            margin: 0;
            color: rgba(255,255,255,.88);
            line-height: 1.8;
        }

        /* Form area */

        .login-form-area {
            display: flex;
            align-items: center;
            padding: 45px;
        }

        .login-form-inner {
            width: 100%;
            max-width: 390px;
            margin: auto;
        }

        .welcome-icon {
            width: 55px;
            height: 55px;
            display: grid;
            place-items: center;
            margin-bottom: 23px;
            border-radius: 15px;
            background: var(--green-light);
            color: var(--green);
            font-size: 25px;
        }

        .login-form-inner h1 {
            margin-bottom: 8px;
            color: var(--green-dark);
            font-size: 2rem;
            font-weight: 800;
            letter-spacing: -.6px;
        }

        .login-description {
            margin-bottom: 28px;
            color: var(--muted);
            line-height: 1.7;
        }

        .form-label {
            margin-bottom: 8px;
            font-size: .9rem;
            font-weight: 700;
        }

        .input-group {
            border: 1px solid #d5dfd9;
            border-radius: 10px;
            overflow: hidden;
            background: #fff;
        }

        .input-group:focus-within {
            border-color: var(--green);
            box-shadow: 0 0 0 3px rgba(23,107,82,.10);
        }

        .input-group-text {
            padding-left: 14px;
            padding-right: 10px;
            border: 0;
            background: #fff;
            color: var(--muted);
        }

        .input-group .form-control {
            min-height: 48px;
            border: 0;
            box-shadow: none;
            padding-left: 8px;
            font-size: .92rem;
        }

        .input-group .form-control:focus {
            box-shadow: none;
        }

        .password-toggle {
            padding: 0 15px;
            border: 0;
            background: #fff;
            color: var(--muted);
        }

        .password-toggle:hover {
            color: var(--green);
        }

        .forgot-link {
            font-size: .85rem;
            font-weight: 700;
        }

        .btn-login {
            width: 100%;
            min-height: 49px;
            display: inline-flex;
            justify-content: center;
            align-items: center;
            gap: 9px;
            border: 1px solid var(--green);
            border-radius: 10px;
            background: var(--green);
            color: #fff;
            font-weight: 700;
            transition: background .2s ease;
        }

        .btn-login:hover {
            border-color: var(--green-dark);
            background: var(--green-dark);
            color: #fff;
        }

        .register-text {
            margin-top: 24px;
            text-align: center;
            color: var(--muted);
            font-size: .9rem;
        }

        .register-text a {
            font-weight: 700;
        }

        .security-note {
            display: flex;
            align-items: flex-start;
            gap: 9px;
            margin-top: 25px;
            padding: 13px;
            border-radius: 10px;
            background: #f5f9f6;
            color: #5f7167;
            font-size: .8rem;
            line-height: 1.6;
        }

        .security-note i {
            margin-top: 2px;
            color: var(--green);
        }

        .alert {
            border: 0;
            border-radius: 10px;
            font-size: .9rem;
        }

        .footer-text {
            padding: 18px 12px;
            color: var(--muted);
            text-align: center;
            font-size: .8rem;
        }

        @media (max-width: 767.98px) {
            .login-section {
                min-height: auto;
                padding: 28px 12px;
            }

            .login-wrapper {
                max-width: 480px;
                border-radius: 16px;
            }

            .login-row {
                min-height: auto;
            }

            .login-picture {
                min-height: 220px;
                padding: 26px;
                background-position: center 40%;
            }

            .picture-content h2 {
                font-size: 1.65rem;
            }

            .picture-content p {
                font-size: .9rem;
            }

            .picture-label {
                margin-bottom: 10px;
            }

            .login-form-area {
                padding: 32px 24px;
            }

            .login-form-inner h1 {
                font-size: 1.8rem;
            }
        }

        @media (prefers-reduced-motion: reduce) {
            *,
            *::before,
            *::after {
                transition: none !important;
            }
        }
    </style>
</head>

<body>

<!-- Navigation -->

<nav class="townlink-navbar">
    <div class="container d-flex align-items-center justify-content-between py-3">

        <a class="brand" href="public/index.php">
            <span class="brand-icon">
                <i class="bi bi-buildings"></i>
            </span>

            <span class="brand-name">Town<span>Link</span></span>
        </a>

        <a href="index.php" class="nav-home">
            <i class="bi bi-arrow-left me-1"></i>
            Back to Home
        </a>

    </div>
</nav>


<!-- Login -->

<main class="login-section">

    <div class="container">

        <div class="login-wrapper">

            <div class="row g-0 login-row">

                <!-- Picture panel -->

                <div class="col-md-6">

                    <section
                        class="login-picture"
                        aria-label="TownLink community"
                    >

                        <div class="picture-content">

                            <span class="picture-label">
                                <i class="bi bi-geo-alt me-1"></i>
                                TownLink Namibia
                            </span>

                            <h2>
                                Your community.
                                Connected.
                            </h2>

                            <p>
                                Access municipal services, stay informed
                                and connect with your municipality through
                                one convenient platform.
                            </p>

                        </div>

                    </section>

                </div>


                <!-- Login form -->

                <div class="col-md-6 login-form-area">

                    <div class="login-form-inner">

                        <div class="welcome-icon">
                            <i class="bi bi-person-lock"></i>
                        </div>

                        <h1>Welcome back</h1>

                        <p class="login-description">
                            Sign in to your TownLink account to continue.
                        </p>


                        <?php if ($message !== ''): ?>

                            <div
                                class="alert alert-danger mb-4"
                                role="alert"
                            >
                                <i class="bi bi-exclamation-circle me-2"></i>
                                <?= e($message) ?>
                            </div>

                        <?php endif; ?>


                        <form method="POST" action="">

                            <div class="mb-4">

                                <label for="email" class="form-label">
                                    Email address
                                </label>

                                <div class="input-group">

                                    <span class="input-group-text">
                                        <i class="bi bi-envelope"></i>
                                    </span>

                                    <input
                                        type="email"
                                        id="email"
                                        name="email"
                                        class="form-control"
                                        placeholder="you@example.com"
                                        value="<?= e($_POST['email'] ?? '') ?>"
                                        autocomplete="email"
                                        maxlength="254"
                                        required
                                    >

                                </div>

                            </div>


                            <div class="mb-3">

                                <div class="d-flex justify-content-between align-items-center mb-2">

                                    <label for="password" class="form-label mb-0">
                                        Password
                                    </label>

                                    <a
                                        href="forgot-password.php"
                                        class="forgot-link"
                                    >
                                        Forgot password?
                                    </a>

                                </div>

                                <div class="input-group">

                                    <span class="input-group-text">
                                        <i class="bi bi-lock"></i>
                                    </span>

                                    <input
                                        type="password"
                                        id="password"
                                        name="password"
                                        class="form-control"
                                        placeholder="Enter your password"
                                        autocomplete="current-password"
                                        required
                                    >

                                    <button
                                        type="button"
                                        class="password-toggle"
                                        id="togglePassword"
                                        aria-label="Show password"
                                        aria-pressed="false"
                                    >
                                        <i class="bi bi-eye" id="passwordIcon"></i>
                                    </button>

                                </div>

                            </div>


                            <button
                                type="submit"
                                class="btn btn-login mt-3"
                            >
                                <i class="bi bi-box-arrow-in-right"></i>
                                Sign in to TownLink
                            </button>

                        </form>


                        <p class="register-text">

                            Don't have an account?

                            <a href="register.php">
                                Create an account
                            </a>

                        </p>


                        <div class="security-note">

                            <i class="bi bi-shield-lock-fill"></i>

                            <span>
                                Your account and municipal information
                                should only be accessed by you. Never
                                share your password with anyone.
                            </span>

                        </div>

                    </div>

                </div>

            </div>

        </div>

        <div class="footer-text">
            &copy; <?= date('Y') ?> TownLink Namibia. All rights reserved.
        </div>

    </div>

</main>


<script src="../assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<script>
    const togglePassword = document.getElementById('togglePassword');
    const passwordInput = document.getElementById('password');
    const passwordIcon = document.getElementById('passwordIcon');

    togglePassword.addEventListener('click', function () {

        const isHidden = passwordInput.type === 'password';

        passwordInput.type = isHidden ? 'text' : 'password';

        passwordIcon.className = isHidden
            ? 'bi bi-eye-slash'
            : 'bi bi-eye';

        togglePassword.setAttribute(
            'aria-label',
            isHidden ? 'Hide password' : 'Show password'
        );

        togglePassword.setAttribute(
            'aria-pressed',
            isHidden ? 'true' : 'false'
        );
    });
</script>

</body>
</html>