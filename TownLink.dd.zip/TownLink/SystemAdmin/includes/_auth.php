<?php

declare(strict_types=1);

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

/*
|--------------------------------------------------------------------------
| Database
|--------------------------------------------------------------------------
*/

require_once __DIR__ . '/../../app/config/database.php';
require_once __DIR__ . '/../../app/helpers/audit.php';

/*
|--------------------------------------------------------------------------
| System Admin Authentication
|--------------------------------------------------------------------------
*/

if (!isset($_SESSION['user_id'])) {

    header('Location: ../../public/login.php');

    exit;
}

$userId = (int) $_SESSION['user_id'];

$role = (string) (
    $_SESSION['role'] ?? ''
);

/*
|--------------------------------------------------------------------------
| System Admin Only
|--------------------------------------------------------------------------
*/

if ($role !== 'system_admin') {

    http_response_code(403);

    exit(
        'Access denied. System Administrator privileges are required.'
    );
}

/*
|--------------------------------------------------------------------------
| Current User
|--------------------------------------------------------------------------
*/

try {

    $stmt = $pdo->prepare("
        SELECT
            id,
            municipality_id,
            department_id,
            first_name,
            last_name,
            email,
            phone,
            role,
            status,
            must_change_password,
            created_at,
            updated_at

        FROM users

        WHERE id = :id

        LIMIT 1
    ");

    $stmt->execute([
        ':id' => $userId
    ]);

    $currentUser = $stmt->fetch(
        PDO::FETCH_ASSOC
    );

    /*
    |--------------------------------------------------------------------------
    | User Does Not Exist
    |--------------------------------------------------------------------------
    */

    if (!$currentUser) {

        session_unset();

        session_destroy();

        header(
            'Location: ../../public/login.php'
        );

        exit;
    }

    /*
    |--------------------------------------------------------------------------
    | Account Must Be Active
    |--------------------------------------------------------------------------
    */

    if (
        $currentUser['status'] !== 'active'
    ) {

        session_unset();

        session_destroy();

        header(
            'Location: ../../public/login.php'
        );

        exit;
    }

} catch (PDOException $e) {

    error_log(
        'TownLink SystemAdmin auth error: ' .
        $e->getMessage()
    );

    http_response_code(500);

    exit(
        'Unable to load administrator information.'
    );
}

/*
|--------------------------------------------------------------------------
| HTML Escape
|--------------------------------------------------------------------------
*/

function e(?string $value): string
{
    return htmlspecialchars(
        (string) $value,
        ENT_QUOTES,
        'UTF-8'
    );
}

/*
|--------------------------------------------------------------------------
| Require System Administrator
|--------------------------------------------------------------------------
*/

function requireSystemAdmin(): void
{
    if (
        ($_SESSION['role'] ?? '') !==
        'system_admin'
    ) {

        http_response_code(403);

        exit(
            'Access denied. System Administrator privileges are required.'
        );
    }
}

/*
|--------------------------------------------------------------------------
| CSRF Token
|--------------------------------------------------------------------------
*/

function csrfToken(): string
{
    if (
        empty(
            $_SESSION['csrf_token']
        )
    ) {

        $_SESSION['csrf_token'] =
            bin2hex(
                random_bytes(32)
            );
    }

    return $_SESSION['csrf_token'];
}

/*
|--------------------------------------------------------------------------
| Verify CSRF
|--------------------------------------------------------------------------
*/

function verifyCsrf(): void
{
    $token = $_POST['csrf_token'] ?? '';

    if (
        !is_string($token) ||
        !hash_equals(
            csrfToken(),
            $token
        )
    ) {

        http_response_code(419);

        exit(
            'Invalid security token. Please go back and try again.'
        );
    }
}