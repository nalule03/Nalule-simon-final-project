# TownLink

TownLink is a web-based municipal community management system.

## Technologies
- HTML
- CSS
- JavaScript
- PHP
- MySQL
- Power BI

## Main Modules
- Resident
- Municipality
- System Administration

## Local Development
1. Install XAMPP.
2. Place the project folder inside htdocs.
3. Start Apache and MySQL.
4. Import the database backup using phpMyAdmin.
5. Configure the database connection.
6. Access the application through localhost.

## Project Status
Final Year Computer Science Project.
