<?php

declare(strict_types=1);

require_once __DIR__ . '/../_auth.php';

if (!isMunicipalityAdmin()) {

    http_response_code(403);

    exit(
        'Access denied.'
    );

}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {

    header(
        'Location: index.php'
    );

    exit;

}

$name = trim(
    $_POST['name'] ?? ''
);

$code = trim(
    $_POST['code'] ?? ''
);

$type = trim(
    $_POST['type'] ?? ''
);

$region = trim(
    $_POST['region'] ?? ''
);

$district = trim(
    $_POST['district'] ?? ''
);

$status = trim(
    $_POST['status'] ?? ''
);

$address = trim(
    $_POST['address'] ?? ''
);

$phone = trim(
    $_POST['phone'] ?? ''
);

$email = trim(
    $_POST['email'] ?? ''
);

$website = trim(
    $_POST['website'] ?? ''
);

if (
    $name === ''
    || $code === ''
    || $type === ''
) {

    header(
        'Location: edit.php?error=required'
    );

    exit;

}

if (
    $email !== ''
    && !filter_var(
        $email,
        FILTER_VALIDATE_EMAIL
    )
) {

    header(
        'Location: edit.php?error=email'
    );

    exit;

}

if (
    $website !== ''
    && !filter_var(
        $website,
        FILTER_VALIDATE_URL
    )
) {

    header(
        'Location: edit.php?error=website'
    );

    exit;

}