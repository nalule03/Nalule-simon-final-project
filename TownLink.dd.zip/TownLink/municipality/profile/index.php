<?php

declare(strict_types=1);

require_once __DIR__ . '/../auth.php';
require_once __DIR__ . '/../layout.php';

municipalityHeader(
    'Municipality Profile',
    'profile'
);

?>

<div class="container-fluid">

    <div class="d-flex justify-content-between align-items-center mb-4">

        <div>

            <h2 class="mb-1">
                <?= e($currentMunicipality['name']) ?>
            </h2>

            <p class="text-muted mb-0">
                Municipality information
            </p>

        </div>

        <?php if (isMunicipalityAdmin()): ?>

            <a
                class="btn btn-primary"
                href="edit.php"
            >
                Edit Profile
            </a>

        <?php endif; ?>

    </div>


    <div class="card shadow-sm">

        <div class="card-header bg-white">

            <h5 class="mb-0">
                Municipality Details
            </h5>

        </div>

        <div class="card-body">

            <div class="row g-3">

                <div class="col-md-6">

                    <div class="fw-bold text-muted">
                        Name
                    </div>

                    <div>
                        <?= e($currentMunicipality['name']) ?>
                    </div>

                </div>


                <div class="col-md-6">

                    <div class="fw-bold text-muted">
                        Code
                    </div>

                    <div>
                        <?= e($currentMunicipality['code']) ?>
                    </div>

                </div>


                <div class="col-md-6">

                    <div class="fw-bold text-muted">
                        Type
                    </div>

                    <div>
                        <?= e($currentMunicipality['type']) ?>
                    </div>

                </div>


                <div class="col-md-6">

                    <div class="fw-bold text-muted">
                        Region
                    </div>

                    <div>
                        <?= e($currentMunicipality['region']) ?>
                    </div>

                </div>


                <div class="col-md-6">

                    <div class="fw-bold text-muted">
                        Status
                    </div>

                    <div>

                        <?php if (
                            $currentMunicipality['status'] === 'active'
                        ): ?>

                            <span class="badge text-bg-success">
                                Active
                            </span>

                        <?php else: ?>

                            <span class="badge text-bg-secondary">
                                <?= e(
                                    ucfirst(
                                        $currentMunicipality['status']
                                    )
                                ) ?>
                            </span>

                        <?php endif; ?>

                    </div>

                </div>


                <div class="col-md-6">

                    <div class="fw-bold text-muted">
                        Address
                    </div>

                    <div>
                        <?= e(
                            $currentMunicipality['address']
                            ?: 'Not provided'
                        ) ?>
                    </div>

                </div>


                <div class="col-md-6">

                    <div class="fw-bold text-muted">
                        Phone
                    </div>

                    <div>
                        <?= e(
                            $currentMunicipality['phone']
                            ?: 'Not provided'
                        ) ?>
                    </div>

                </div>


                <div class="col-md-6">

                    <div class="fw-bold text-muted">
                        Email
                    </div>

                    <div>
                        <?= e(
                            $currentMunicipality['email']
                            ?: 'Not provided'
                        ) ?>
                    </div>

                </div>


                <div class="col-md-6">

                    <div class="fw-bold text-muted">
                        Website
                    </div>

                    <div>

                        <?php if (
                            !empty(
                                $currentMunicipality['website']
                            )
                        ): ?>

                            <a
                                href="<?= e(
                                    $currentMunicipality['website']
                                ) ?>"
                                target="_blank"
                                rel="noopener noreferrer"
                            >
                                <?= e(
                                    $currentMunicipality['website']
                                ) ?>
                            </a>

                        <?php else: ?>

                            <span class="text-muted">
                                Not provided
                            </span>

                        <?php endif; ?>

                    </div>

                </div>


                <div class="col-12">

                    <div class="fw-bold text-muted">
                        Description
                    </div>

                    <div>
                        <?= nl2br(
                            e(
                                $currentMunicipality['description']
                                ?: 'No description provided.'
                            )
                        ) ?>
                    </div>

                </div>

            </div>

        </div>

    </div>

</div>

<?php

municipalityFooter();