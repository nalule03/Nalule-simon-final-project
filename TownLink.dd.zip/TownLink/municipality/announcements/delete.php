<?php

declare(strict_types=1);

require_once __DIR__ . '/../auth.php';

if (!isMunicipalityAdmin()) {
    http_response_code(403);
    exit('Access denied.');
}

$id = filter_input(
    INPUT_GET,
    'id',
    FILTER_VALIDATE_INT
);

if (!$id) {
    http_response_code(400);
    exit('Invalid announcement ID.');
}

$sql = "
    DELETE FROM announcements

    WHERE
        id = :id
        AND municipality_id = :municipality_id
";

$stmt = $pdo->prepare($sql);

$stmt->execute([
    ':id' => $id,
    ':municipality_id' => $municipalityId
]);

header('Location: index.php');
exit;