<?php

declare(strict_types=1);

require_once __DIR__ . '/../includes/_auth.php';

requireSystemAdmin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {

    header('Location: index.php');

    exit;
}

verifyCsrf();

$municipalityId = filter_input(
    INPUT_POST,
    'municipality_id',
    FILTER_VALIDATE_INT
);

$firstName = trim(
    $_POST['first_name'] ?? ''
);

$lastName = trim(
    $_POST['last_name'] ?? ''
);

$email = trim(
    $_POST['email'] ?? ''
);

$phone = trim(
    $_POST['phone'] ?? ''
);

$temporaryPassword =
    $_POST['temporary_password'] ?? '';

/*
|--------------------------------------------------------------------------
| Validation
|--------------------------------------------------------------------------
*/

$errors = [];

if (
    !$municipalityId ||
    $municipalityId <= 0
) {

    $errors[] =
        'Invalid municipality.';
}

if ($firstName === '') {

    $errors[] =
        'First name is required.';
}

if ($lastName === '') {

    $errors[] =
        'Last name is required.';
}

if (
    !filter_var(
        $email,
        FILTER_VALIDATE_EMAIL
    )
) {

    $errors[] =
        'A valid email address is required.';
}

if (
    strlen($temporaryPassword) < 8
) {

    $errors[] =
        'Temporary password must contain at least 8 characters.';
}

if ($errors) {

    echo '<h1>Unable to create administrator</h1>';

    echo '<ul>';

    foreach ($errors as $error) {

        echo '<li>' .
            e($error) .
            '</li>';
    }

    echo '</ul>';

    echo '<p>';

    echo '<a href="create-admin.php?municipality_id=' .
        (int) $municipalityId .
        '">Go Back</a>';

    echo '</p>';

    exit;
}

/*
|--------------------------------------------------------------------------
| Create Account
|--------------------------------------------------------------------------
*/

try {

    /*
    |--------------------------------------------------------------------------
    | Verify Municipality
    |--------------------------------------------------------------------------
    */

    $stmt = $pdo->prepare("
        SELECT id
        FROM municipalities
        WHERE
            id = :id
            AND status = 'active'
        LIMIT 1
    ");

    $stmt->execute([
        ':id' => $municipalityId
    ]);

    if (!$stmt->fetch()) {

        http_response_code(404);

        exit(
            'Municipality not found or inactive.'
        );
    }

    /*
    |--------------------------------------------------------------------------
    | Check Existing Email
    |--------------------------------------------------------------------------
    */

    $stmt = $pdo->prepare("
        SELECT id
        FROM users
        WHERE email = :email
        LIMIT 1
    ");

    $stmt->execute([
        ':email' => $email
    ]);

    if ($stmt->fetch()) {

        exit(
            'A user with that email address already exists.'
        );
    }

    /*
    |--------------------------------------------------------------------------
    | Hash Temporary Password
    |--------------------------------------------------------------------------
    */

    $passwordHash =
        password_hash(
            $temporaryPassword,
            PASSWORD_DEFAULT
        );

    /*
    |--------------------------------------------------------------------------
    | Insert User
    |--------------------------------------------------------------------------
    */

    $stmt = $pdo->prepare("
        INSERT INTO users
        (
            municipality_id,
            department_id,
            first_name,
            last_name,
            email,
            phone,
            password_hash,
            role,
            status,
            must_change_password
        )
        VALUES
        (
            :municipality_id,
            NULL,
            :first_name,
            :last_name,
            :email,
            :phone,
            :password_hash,
            'municipality_admin',
            'active',
            1
        )
    ");

    $stmt->execute([
        ':municipality_id' =>
            $municipalityId,

        ':first_name' =>
            $firstName,

        ':last_name' =>
            $lastName,

        ':email' =>
            $email,

        ':phone' =>
            $phone !== ''
            ? $phone
            : null,

        ':password_hash' =>
            $passwordHash
    ]);

    $userId =
        (int) $pdo->lastInsertId();

    /*
    |--------------------------------------------------------------------------
    | Audit
    |--------------------------------------------------------------------------
    */

    auditLog(
        $pdo,
        $municipalityId,
        $userId,
        'create',
        'user',
        $userId,
        'Municipality administrator account created by System Administrator.'
    );

    /*
    |--------------------------------------------------------------------------
    | Success
    |--------------------------------------------------------------------------
    */

    echo '<h1>Municipality Administrator Created</h1>';

    echo '<p>';

    echo 'The municipality administrator account has been created successfully.';

    echo '</p>';

    echo '<p>';

    echo '<strong>Email:</strong> ' .
        e($email);

    echo '</p>';

    echo '<p>';

    echo '<strong>Temporary Password:</strong> ' .
        e($temporaryPassword);

    echo '</p>';

    echo '<p>';

    echo 'The administrator must change this password after the first login.';

    echo '</p>';

    echo '<p>';

    echo '<a href="view.php?id=' .
        $municipalityId .
        '">Return to Municipality</a>';

    echo '</p>';

    exit;

} catch (PDOException $e) {

    error_log(
        'Create municipality administrator error: ' .
        $e->getMessage()
    );

    http_response_code(500);

    exit(
        'Unable to create municipality administrator.'
    );
}