<?php

declare(strict_types=1);

require_once __DIR__ . '/../auth.php';
require_once __DIR__ . '/../layout.php';

$id = filter_input(
    INPUT_GET,
    'id',
    FILTER_VALIDATE_INT
);

if (!$id) {
    http_response_code(400);
    exit('Invalid department.');
}

$stmt = $pdo->prepare("
    SELECT
        d.id,
        d.name,
        d.code,
        d.description,
        d.status,
        d.created_at,
        d.updated_at
    FROM departments d
    WHERE d.id = :id
    AND d.municipality_id = :municipality_id
    LIMIT 1
");

$stmt->execute([
    ':id' => $id,
    ':municipality_id' => $municipalityId
]);

$department =
    $stmt->fetch(PDO::FETCH_ASSOC);

if (!$department) {
    http_response_code(404);
    exit('Department not found.');
}

$stmt = $pdo->prepare("
    SELECT
        id,
        name,
        status
    FROM services
    WHERE department_id = :department_id
    AND municipality_id = :municipality_id
    ORDER BY name ASC
");

$stmt->execute([
    ':department_id' => $id,
    ':municipality_id' => $municipalityId
]);

$services =
    $stmt->fetchAll(PDO::FETCH_ASSOC);

$stmt = $pdo->prepare("
    SELECT
        id,
        first_name,
        last_name,
        email,
        role,
        status
    FROM users
    WHERE department_id = :department_id
    AND municipality_id = :municipality_id
    ORDER BY first_name, last_name
");

$stmt->execute([
    ':department_id' => $id,
    ':municipality_id' => $municipalityId
]);

$staff =
    $stmt->fetchAll(PDO::FETCH_ASSOC);

municipalityHeader(
    'Department',
    'departments'
);

?>

<div class="page-header">

    <div>
        <h2><?= e($department['name']) ?></h2>

        <p>
            Department code:
            <?= e($department['code']) ?>
        </p>
    </div>

    <div class="actions">

        <?php if (isMunicipalityAdmin()): ?>

            <a
                class="button"
                href="edit.php?id=<?= (int) $department['id'] ?>"
            >
                Edit
            </a>

        <?php endif; ?>

        <a
            class="button secondary"
            href="index.php"
        >
            Back
        </a>

    </div>

</div>

<div class="card">

    <h3>Department Information</h3>

    <div class="detail-grid">

        <div class="detail-label">Name</div>
        <div><?= e($department['name']) ?></div>

        <div class="detail-label">Code</div>
        <div><?= e($department['code']) ?></div>

        <div class="detail-label">Description</div>
        <div>
            <?= nl2br(
                e($department['description'])
            ) ?: 'No description.' ?>
        </div>

        <div class="detail-label">Status</div>
        <div>
            <span
                class="badge <?= e($department['status']) ?>"
            >
                <?= e(
                    ucfirst(
                        $department['status']
                    )
                ) ?>
            </span>
        </div>

        <div class="detail-label">Created</div>
        <div>
            <?= e($department['created_at']) ?>
        </div>

    </div>

</div>

<div class="card">

    <h3>Services</h3>

    <?php if (!$services): ?>

        <p class="muted">
            No services belong to this department yet.
        </p>

    <?php else: ?>

        <table>

            <thead>
            <tr>
                <th>Name</th>
                <th>Status</th>
            </tr>
            </thead>

            <tbody>

            <?php foreach ($services as $service): ?>

                <tr>

                    <td>
                        <a
                            href="../services/view.php?id=<?= (int) $service['id'] ?>"
                        >
                            <?= e($service['name']) ?>
                        </a>
                    </td>

                    <td>
                        <span
                            class="badge <?= e($service['status']) ?>"
                        >
                            <?= e(
                                ucfirst(
                                    $service['status']
                                )
                            ) ?>
                        </span>
                    </td>

                </tr>

            <?php endforeach; ?>

            </tbody>

        </table>

    <?php endif; ?>

</div>

<div class="card">

    <h3>Department Staff</h3>

    <?php if (!$staff): ?>

        <p class="muted">
            No staff members are assigned to this department.
        </p>

    <?php else: ?>

        <table>

            <thead>

            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Role</th>
                <th>Status</th>
            </tr>

            </thead>

            <tbody>

            <?php foreach ($staff as $member): ?>

                <tr>

                    <td>
                        <?= e(
                            $member['first_name'] .
                            ' ' .
                            $member['last_name']
                        ) ?>
                    </td>

                    <td>
                        <?= e($member['email']) ?>
                    </td>

                    <td>
                        <?= e(
                            ucwords(
                                str_replace(
                                    '_',
                                    ' ',
                                    $member['role']
                                )
                            )
                        ) ?>
                    </td>

                    <td>
                        <span
                            class="badge <?= e($member['status']) ?>"
                        >
                            <?= e(
                                ucfirst(
                                    $member['status']
                                )
                            ) ?>
                        </span>
                    </td>

                </tr>

            <?php endforeach; ?>

            </tbody>

        </table>

    <?php endif; ?>

</div>

<?php

municipalityFooter();
