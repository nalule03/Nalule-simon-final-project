<?php
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}


require_once __DIR__ . '/../app/config/database.php';

// Only authenticated users may change their passwords.
if (empty($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit;
}

if (!isset($pdo) || !$pdo instanceof PDO) {
    http_response_code(500);
    exit('Database connection is unavailable.');
}

$userId = (int) $_SESSION['user_id'];

function e($value): string
{
    return htmlspecialchars((string) ($value ?? ''), ENT_QUOTES, 'UTF-8');
}

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$message = '';
$messageType = '';

// Verify that the account still exists and is active.
$stmt = $pdo->prepare(
    'SELECT id, municipality_id, password_hash, role, status,
            must_change_password
     FROM users
     WHERE id = :id
     LIMIT 1'
);
$stmt->execute([':id' => $userId]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user || $user['status'] !== 'active') {
    session_unset();
    session_destroy();
    header('Location: ../auth/login.php');
    exit;
}

// Only municipality administrators and department staff may use
// this page. Adjust this rule if other roles need access.
if (!in_array($user['role'], ['municipality_admin', 'department_staff'], true)) {
    http_response_code(403);
    exit('You are not authorized to access this page.');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_POST['csrf_token'] ?? '';
    $current = (string) ($_POST['current_password'] ?? '');
    $new = (string) ($_POST['new_password'] ?? '');
    $confirm = (string) ($_POST['confirm_password'] ?? '');

    if (!is_string($token) ||
        !hash_equals($_SESSION['csrf_token'], $token)) {
        $message = 'Your session expired. Refresh the page and try again.';
        $messageType = 'danger';
    } elseif ($current === '' || $new === '' || $confirm === '') {
        $message = 'Please complete all password fields.';
        $messageType = 'danger';
    } elseif (!password_verify($current, $user['password_hash'])) {
        $message = 'Your current password is incorrect.';
        $messageType = 'danger';
    } elseif (strlen($new) < 12) {
        $message = 'Your new password must contain at least 12 characters.';
        $messageType = 'danger';
    } elseif (strlen($new) > 72) {
        $message = 'Your new password exceeds the supported password length.';
        $messageType = 'danger';
    } elseif ($new !== $confirm) {
        $message = 'Your new passwords do not match.';
        $messageType = 'danger';
    } elseif (password_verify($new, $user['password_hash'])) {
        $message = 'Choose a password different from your current password.';
        $messageType = 'danger';
    } else {
        try {
            $pdo->beginTransaction();

            // Lock the account row while changing its password.
            $lock = $pdo->prepare(
                'SELECT password_hash
                 FROM users
                 WHERE id = :id
                 FOR UPDATE'
            );
            $lock->execute([':id' => $userId]);
            $lockedUser = $lock->fetch(PDO::FETCH_ASSOC);

            if (
                !$lockedUser ||
                !password_verify($current, $lockedUser['password_hash'])
            ) {
                throw new RuntimeException(
                    'Your current password has changed. Please try again.'
                );
            }

            $hash = password_hash($new, PASSWORD_DEFAULT);

            $update = $pdo->prepare(
                'UPDATE users
                 SET password_hash = :hash,
                     must_change_password = 0
                 WHERE id = :id'
            );
            $update->execute([
                ':hash' => $hash,
                ':id' => $userId
            ]);

            $audit = $pdo->prepare(
                'INSERT INTO audit_logs
                    (municipality_id, user_id, action, entity_type,
                     entity_id, description, ip_address, user_agent)
                 VALUES
                    (:municipality_id, :user_id, :action, :entity_type,
                     :entity_id, :description, :ip_address, :user_agent)'
            );

            $audit->execute([
                ':municipality_id' => $user['municipality_id'],
                ':user_id' => $userId,
                ':action' => 'password_change',
                ':entity_type' => 'user',
                ':entity_id' => $userId,
                ':description' => 'User changed their password.',
                ':ip_address' => $_SERVER['REMOTE_ADDR'] ?? null,
                ':user_agent' => substr(
                    (string) ($_SERVER['HTTP_USER_AGENT'] ?? ''),
                    0,
                    5000
                )
            ]);

            $pdo->commit();

            $_SESSION['must_change_password'] = 0;
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));

            // Prevent browser resubmission and redirect to dashboard.
            $_SESSION['password_change_success'] =
                'Your password has been changed successfully.';

            header('Location: dashboard.php');
            exit;

        } catch (Throwable $exception) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }

            if ($exception instanceof RuntimeException) {
                $message = $exception->getMessage();
            } else {
                error_log(
                    'TownLink password change error: ' .
                    $exception->getMessage()
                );
                $message = 'Unable to change your password right now. Please try again.';
            }

            $messageType = 'danger';
        }
    }
}

$firstName = $_SESSION['first_name'] ?? 'User';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Change Password | TownLink Namibia</title>

    <link rel="stylesheet"
          href="../assets/vendor/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet"
          href="../assets/vendor/bootstrap-icons/bootstrap-icons.css">

    <style>
        :root {
            --green: #176b52;
            --dark: #123b32;
            --background: #f4f7f6;
            --border: #e1e9e5;
            --muted: #718078;
        }

        body {
            margin: 0;
            background: var(--background);
            color: #182b25;
            font-family: "Segoe UI", Arial, sans-serif;
            min-height: 100vh;
        }

        .navbar {
            background: #fff;
            border-bottom: 1px solid var(--border);
            padding: 18px 0;
        }

        .brand {
            color: var(--dark);
            font-weight: 800;
            font-size: 1.35rem;
            text-decoration: none;
        }

        .brand span {
            color: var(--green);
        }

        .page {
            max-width: 760px;
            margin: 45px auto;
            padding: 0 18px;
        }

        .intro {
            margin-bottom: 25px;
        }

        .eyebrow {
            color: var(--green);
            font-weight: 800;
            letter-spacing: 1.5px;
            text-transform: uppercase;
            font-size: .78rem;
        }

        h1 {
            margin: 10px 0;
            color: var(--dark);
            font-size: clamp(1.8rem, 5vw, 2.35rem);
            font-weight: 800;
        }

        .muted {
            color: var(--muted);
            line-height: 1.7;
        }

        .card {
            background: white;
            border: 1px solid var(--border);
            border-radius: 18px;
            padding: clamp(22px, 5vw, 38px);
            box-shadow: 0 12px 35px rgba(18, 59, 50, .06);
        }

        .icon-box {
            display: grid;
            place-items: center;
            width: 52px;
            height: 52px;
            border-radius: 14px;
            background: #e8f5ef;
            color: var(--green);
            font-size: 24px;
            margin-bottom: 18px;
        }

        .form-label {
            font-weight: 700;
            font-size: .9rem;
        }

        .input-group {
            border: 1px solid #d5dfd9;
            border-radius: 9px;
            overflow: hidden;
        }

        .input-group:focus-within {
            border-color: var(--green);
            box-shadow: 0 0 0 3px rgba(23, 107, 82, .1);
        }

        .input-group .form-control,
        .input-group .btn {
            min-height: 48px;
            border: 0;
            box-shadow: none;
        }

        .input-group .form-control {
            padding: 12px 14px;
        }

        .toggle-password {
            background: white;
            color: var(--green);
        }

        .guidelines {
            background: #f5f9f6;
            padding: 16px 20px;
            border-radius: 10px;
            color: #5e7167;
            font-size: .88rem;
            line-height: 1.9;
        }

        .btn-townlink {
            width: 100%;
            min-height: 49px;
            background: var(--green);
            color: white;
            font-weight: 700;
            border-radius: 10px;
            border: 1px solid var(--green);
        }

        .btn-townlink:hover {
            background: var(--dark);
            color: white;
        }

        .back-link {
            display: inline-block;
            margin-top: 20px;
            color: var(--green);
            text-decoration: none;
            font-weight: 700;
        }

        footer {
            text-align: center;
            padding: 20px;
            color: var(--muted);
            font-size: .8rem;
        }
    </style>
</head>
<body>

<nav class="navbar">
    <div class="container d-flex justify-content-between align-items-center">
        <a class="brand" href="dashboard.php">
            <i class="bi bi-buildings me-2"></i>Town<span>Link</span>
        </a>
        <span class="muted small">
            <i class="bi bi-person-circle me-1"></i>
            <?= e($firstName) ?>
        </span>
    </div>
</nav>

<main class="page">
    <div class="intro">
        <div class="eyebrow">Account security</div>
        <h1>Change your password</h1>
        <p class="muted">
            Protect your TownLink account with a strong, unique password.
        </p>
    </div>

    <section class="card">
        <div class="icon-box">
            <i class="bi bi-shield-lock"></i>
        </div>

        <h2 class="h4 fw-bold">Update password</h2>
        <p class="muted mb-4">
            Enter your current password and choose your new password.
        </p>

        <?php if ($message !== ''): ?>
            <div class="alert alert-<?= e($messageType) ?>" role="alert">
                <?= e($message) ?>
            </div>
        <?php endif; ?>

        <form method="post" action="" autocomplete="off">
            <input type="hidden" name="csrf_token"
                   value="<?= e($_SESSION['csrf_token']) ?>">

            <div class="mb-4">
                <label class="form-label" for="current_password">
                    Current password
                </label>
                <div class="input-group">
                    <input class="form-control" id="current_password"
                           name="current_password" type="password"
                           autocomplete="current-password" required>
                    <button class="btn toggle-password" type="button"
                            data-target="current_password">Show</button>
                </div>
            </div>

            <div class="mb-4">
                <label class="form-label" for="new_password">
                    New password
                </label>
                <div class="input-group">
                    <input class="form-control" id="new_password"
                           name="new_password" type="password"
                           minlength="12" maxlength="72"
                           autocomplete="new-password" required>
                    <button class="btn toggle-password" type="button"
                            data-target="new_password">Show</button>
                </div>
                <div class="form-text">
                    Use at least 12 characters.
                </div>
            </div>

            <div class="mb-4">
                <label class="form-label" for="confirm_password">
                    Confirm new password
                </label>
                <div class="input-group">
                    <input class="form-control" id="confirm_password"
                           name="confirm_password" type="password"
                           minlength="12" maxlength="72"
                           autocomplete="new-password" required>
                    <button class="btn toggle-password" type="button"
                            data-target="confirm_password">Show</button>
                </div>
            </div>

            <div class="guidelines mb-4">
                <strong>Password guidelines</strong>
                <ul class="mb-0">
                    <li>Use at least 12 characters.</li>
                    <li>Do not reuse a password from another website.</li>
                    <li>Make sure both new-password fields match.</li>
                    <li>Your current password must be correct.</li>
                </ul>
            </div>

            <button class="btn btn-townlink" type="submit">
                <i class="bi bi-check-circle me-2"></i>
                Update password
            </button>
        </form>

        <a class="back-link" href="dashboard.php">
            <i class="bi bi-arrow-left me-1"></i>
            Back to dashboard
        </a>
    </section>
</main>

<footer>
    &copy; <?= date('Y') ?> TownLink Namibia. All rights reserved.
</footer>

<script>
document.querySelectorAll('.toggle-password').forEach(function (button) {
    button.addEventListener('click', function () {
        const input = document.getElementById(button.dataset.target);
        const show = input.type === 'password';
        input.type = show ? 'text' : 'password';
        button.textContent = show ? 'Hide' : 'Show';
    });
});

const form = document.querySelector('form');
const newPassword = document.getElementById('new_password');
const confirmPassword = document.getElementById('confirm_password');

form.addEventListener('submit', function (event) {
    if (newPassword.value !== confirmPassword.value) {
        event.preventDefault();
        confirmPassword.setCustomValidity(
            'The new passwords do not match.'
        );
        confirmPassword.reportValidity();
    } else {
        confirmPassword.setCustomValidity('');
    }
});

confirmPassword.addEventListener('input', function () {
    confirmPassword.setCustomValidity('');
});
</script>

</body>
</html>
