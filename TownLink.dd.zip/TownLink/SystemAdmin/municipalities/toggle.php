<?php

declare(strict_types=1);

require_once __DIR__ . '/../includes/_auth.php';

requireSystemAdmin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {

    header('Location: index.php');

    exit;
}

verifyCsrf();

$id = filter_input(
    INPUT_POST,
    'id',
    FILTER_VALIDATE_INT
);

if (!$id || $id <= 0) {

    http_response_code(400);

    exit(
        'Invalid municipality ID.'
    );
}

try {

    $stmt = $pdo->prepare("
        SELECT status
        FROM municipalities
        WHERE id = :id
        LIMIT 1
    ");

    $stmt->execute([
        ':id' => $id
    ]);

    $municipality =
        $stmt->fetch(
            PDO::FETCH_ASSOC
        );

    if (!$municipality) {

        http_response_code(404);

        exit(
            'Municipality not found.'
        );
    }

    $newStatus =
        $municipality['status'] === 'active'
        ? 'inactive'
        : 'active';

    $stmt = $pdo->prepare("
        UPDATE municipalities

        SET status = :status

        WHERE id = :id
    ");

    $stmt->execute([
        ':status' => $newStatus,
        ':id' => $id
    ]);

    header(
        'Location: view.php?id=' .
        $id
    );

    exit;

} catch (PDOException $e) {

    error_log(
        'Toggle municipality error: ' .
        $e->getMessage()
    );

    http_response_code(500);

    exit(
        'Unable to change municipality status.'
    );
}