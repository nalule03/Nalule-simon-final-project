<?php

declare(strict_types=1);

require_once __DIR__ . '/../auth.php';
require_once __DIR__ . '/../layout.php';

$stmt = $pdo->prepare("
    SELECT
        d.id,
        d.name,
        d.code,
        d.description,
        d.status,
        d.created_at,

        (
            SELECT COUNT(*)
            FROM users u
            WHERE u.department_id = d.id
            AND u.status = 'active'
        ) AS staff_count,

        (
            SELECT COUNT(*)
            FROM services s
            WHERE s.department_id = d.id
            AND s.status = 'active'
        ) AS service_count

    FROM departments d

    WHERE d.municipality_id = :municipality_id

    ORDER BY d.name ASC
");

$stmt->execute([
    ':municipality_id' => $municipalityId
]);

$departments =
    $stmt->fetchAll(PDO::FETCH_ASSOC);

municipalityHeader(
    'Departments',
    'departments'
);

?>

<div class="page-header">

    <div>
        <h2>Departments</h2>
        <p>Manage municipal departments and their services.</p>
    </div>

    <?php if (isMunicipalityAdmin()): ?>

        <a
            class="button"
            href="create.php"
        >
            + Add Department
        </a>

    <?php endif; ?>

</div>

<div class="card">

    <?php if (!$departments): ?>

        <p class="muted">
            No departments have been created yet.
        </p>

    <?php else: ?>

        <table>

            <thead>

            <tr>
                <th>Name</th>
                <th>Code</th>
                <th>Staff</th>
                <th>Services</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>

            </thead>

            <tbody>

            <?php foreach ($departments as $department): ?>

                <tr>

                    <td>
                        <strong>
                            <?= e($department['name']) ?>
                        </strong>

                        <?php if ($department['description']): ?>

                            <br>

                            <small class="muted">
                                <?= e(
                                    $department['description']
                                ) ?>
                            </small>

                        <?php endif; ?>

                    </td>

                    <td>
                        <?= e($department['code']) ?>
                    </td>

                    <td>
                        <?= (int) $department['staff_count'] ?>
                    </td>

                    <td>
                        <?= (int) $department['service_count'] ?>
                    </td>

                    <td>
                        <span
                            class="badge <?= e($department['status']) ?>"
                        >
                            <?= e(
                                ucfirst(
                                    $department['status']
                                )
                            ) ?>
                        </span>
                    </td>

                    <td>

                        <div class="actions">

                            <a
                                class="button secondary"
                                href="view.php?id=<?= (int) $department['id'] ?>"
                            >
                                View
                            </a>

                            <?php if (isMunicipalityAdmin()): ?>

                                <a
                                    class="button"
                                    href="edit.php?id=<?= (int) $department['id'] ?>"
                                >
                                    Edit
                                </a>

                            <?php endif; ?>

                        </div>

                    </td>

                </tr>

            <?php endforeach; ?>

            </tbody>

        </table>

    <?php endif; ?>

</div>

<?php

municipalityFooter();
