<?php

declare(strict_types=1);

require_once __DIR__ . '/../auth.php';
require_once __DIR__ . '/../layout.php';

requireMunicipalityAdmin();

$id = filter_input(
    INPUT_GET,
    'id',
    FILTER_VALIDATE_INT
);

if (!$id) {
    http_response_code(400);
    exit('Invalid category.');
}

$stmt = $pdo->prepare("
    SELECT *
    FROM service_categories
    WHERE id = :id
    AND municipality_id = :municipality_id
    LIMIT 1
");

$stmt->execute([
    ':id' => $id,
    ':municipality_id' => $municipalityId
]);

$category =
    $stmt->fetch(PDO::FETCH_ASSOC);

if (!$category) {
    http_response_code(404);
    exit('Category not found.');
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    verifyCsrf();

    $name = trim($_POST['name'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $status = $_POST['status'] ?? 'active';

    if ($name === '') {

        $error = 'Category name is required.';

    } elseif (
        !in_array(
            $status,
            ['active', 'inactive'],
            true
        )
    ) {

        $error = 'Invalid status.';

    } else {

        try {

            $stmt = $pdo->prepare("
                SELECT id
                FROM service_categories
                WHERE municipality_id = :municipality_id
                AND name = :name
                AND id <> :id
                LIMIT 1
            ");

            $stmt->execute([
                ':municipality_id' => $municipalityId,
                ':name' => $name,
                ':id' => $id
            ]);

            if ($stmt->fetch()) {

                $error =
                    'Another category already uses this name.';

            } else {

                $stmt = $pdo->prepare("
                    UPDATE service_categories
                    SET
                        name = :name,
                        description = :description,
                        status = :status
                    WHERE id = :id
                    AND municipality_id = :municipality_id
                ");

                $stmt->execute([
                    ':name' => $name,
                    ':description' =>
                        $description !== ''
                        ? $description
                        : null,
                    ':status' => $status,
                    ':id' => $id,
                    ':municipality_id' => $municipalityId
                ]);

                auditLog(
                    $pdo,
                    $municipalityId,
                    $userId,
                    'update',
                    'service_category',
                    $id,
                    'Updated service category: ' . $name
                );

                header(
                    'Location: index.php'
                );

                exit;
            }

        } catch (PDOException $e) {

            error_log(
                'Category update error: ' .
                $e->getMessage()
            );

            $error =
                'Unable to update the category.';
        }
    }
}

municipalityHeader(
    'Edit Service Category',
    'categories'
);

?>

<div class="page-header">

    <div>
        <h2>Edit Service Category</h2>
    </div>

</div>

<?php if ($error !== ''): ?>

    <div class="alert error">
        <?= e($error) ?>
    </div>

<?php endif; ?>

<div class="card">

    <form method="POST">

        <input
            type="hidden"
            name="csrf_token"
            value="<?= e(csrfToken()) ?>"
        >

        <div class="form-grid">

            <div>

                <label>Name</label>

                <input
                    name="name"
                    maxlength="150"
                    required
                    value="<?= e(
                        $_POST['name']
                        ?? $category['name']
                    ) ?>"
                >

            </div>

            <div>

                <label>Status</label>

                <?php
                $status =
                    $_POST['status']
                    ?? $category['status'];
                ?>

                <select name="status">

                    <option
                        value="active"
                        <?= $status === 'active'
                            ? 'selected'
                            : '' ?>
                    >
                        Active
                    </option>

                    <option
                        value="inactive"
                        <?= $status === 'inactive'
                            ? 'selected'
                            : '' ?>
                    >
                        Inactive
                    </option>

                </select>

            </div>

            <div class="full">

                <label>Description</label>

                <textarea
                    name="description"
                ><?= e(
                    $_POST['description']
                    ?? $category['description']
                ) ?></textarea>

            </div>

        </div>

        <br>

        <button class="button">
            Save Changes
        </button>

        <a
            class="button secondary"
            href="index.php"
        >
            Cancel
        </a>

    </form>

</div>

<?php

municipalityFooter();
