<?php
declare(strict_types=1);

require_once __DIR__ . '/_common.php';

report_require_login();

if (report_role() !== 'resident') {
    http_response_code(403);
    exit('Access denied. This page is for residents only.');
}

$userId = (int) ($_SESSION['user_id'] ?? 0);
$municipalityId = (int) ($_SESSION['municipality_id'] ?? 0);

if ($userId <= 0 || $municipalityId <= 0) {
    http_response_code(403);
    exit('Your account is not linked to a municipality.');
}

$statusFilter = trim((string) ($_GET['status'] ?? ''));
$search = trim((string) ($_GET['search'] ?? ''));

$validStatuses = [
    'draft',
    'submitted',
    'in_progress',
    'resolved',
    'rejected',
    'archived'
];

$where = [
    'r.municipality_id = :municipality_id',
    'r.created_by = :user_id'
];

$params = [
    ':municipality_id' => $municipalityId,
    ':user_id' => $userId
];

if (in_array($statusFilter, $validStatuses, true)) {
    $where[] = 'r.status = :status';
    $params[':status'] = $statusFilter;
}

if ($search !== '') {
    $where[] = '(
        r.title LIKE :search_title
        OR r.description LIKE :search_description
    )';

    $params[':search_title'] = '%' . $search . '%';
    $params[':search_description'] = '%' . $search . '%';
}

$reports = [];
$errorMessage = '';

try {
    $sql = "
        SELECT
            r.id,
            r.title,
            r.description,
            r.status,
            r.priority,
            r.created_at,
            r.updated_at
        FROM reports r
        WHERE " . implode(' AND ', $where) . "
        ORDER BY r.created_at DESC
        LIMIT 100
    ";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);

    $reports = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    error_log('TownLink resident reports error: ' . $e->getMessage());
    $errorMessage = 'Your reports could not be loaded. Please try again later.';
}

report_header('My Reports');
?>

<style>
.reports-page {
    max-width: 1100px;
    margin: 0 auto;
}

.reports-intro {
    padding: 24px;
    margin: 18px 0 22px;
    background: #e8f5ef;
    border: 1px solid #d4e9de;
    border-radius: 14px;
}

.reports-intro h1 {
    color: #123b32;
    font-size: 1.8rem;
    font-weight: 800;
}

.reports-intro p {
    margin-bottom: 0;
    color: #405c50;
}

.reports-card {
    padding: 22px;
    margin-bottom: 20px;
    background: #fff;
    border: 1px solid #e1e9e5;
    border-radius: 14px;
}

.reports-filters {
    display: grid;
    grid-template-columns: minmax(0, 2fr) minmax(180px, 1fr);
    gap: 14px;
    align-items: end;
}

.reports-label {
    display: block;
    margin-bottom: 6px;
    color: #123b32;
    font-weight: 700;
}

.reports-actions {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
}

.reports-table-wrap {
    overflow-x: auto;
}

.reports-table {
    width: 100%;
    border-collapse: collapse;
}

.reports-table th,
.reports-table td {
    padding: 13px 12px;
    border-bottom: 1px solid #e1e9e5;
    text-align: left;
    vertical-align: middle;
}

.reports-table th {
    color: #405c50;
    font-size: .85rem;
}

.reports-table td {
    overflow-wrap: anywhere;
}

.report-status {
    display: inline-block;
    padding: 4px 9px;
    border-radius: 20px;
    background: #edf2f0;
    color: #344c42;
    font-size: .8rem;
    font-weight: 700;
}

.report-status.submitted {
    background: #e0f2fe;
    color: #075985;
}

.report-status.in_progress {
    background: #fef3c7;
    color: #92400e;
}

.report-status.resolved {
    background: #dcfce7;
    color: #166534;
}

.report-status.rejected {
    background: #fee2e2;
    color: #991b1b;
}

.report-status.archived,
.report-status.draft {
    background: #f1f5f9;
    color: #475569;
}

.reports-empty {
    padding: 30px 15px;
    text-align: center;
    color: #65756f;
}

@media (max-width: 650px) {
    .reports-filters {
        grid-template-columns: 1fr;
    }

    .reports-card {
        padding: 16px;
    }
}
</style>

<link rel="stylesheet" href="../assets/vendor/bootstrap-icons/bootstrap-icons.css">

<div class="reports-page">

    <section class="reports-intro">
        <h1>My Reports</h1>
        <p>
            View your submitted community reports and follow their progress.
        </p>
    </section>

    <?php if ($errorMessage !== ''): ?>

        <div class="alert alert-danger" role="alert">
            <?= report_escape($errorMessage) ?>
        </div>

    <?php else: ?>

        <section class="reports-card">
            <h2 class="h5 mb-3">Your report history</h2>

            <?php if (empty($reports)): ?>

                <div class="reports-empty">
                    <h3 class="h6">No reports found</h3>

                    <p class="mb-3">
                        You have no reports matching these filters.
                    </p>

                    <a href="create.php" class="btn btn-success">
                        Report a community issue
                    </a>
                </div>

            <?php else: ?>

                <div class="reports-table-wrap">
                    <table class="reports-table">
                        <thead>
                            <tr>
                                <th>Report ID</th>
                                <th>Issue</th>
                                <th>Status</th>
                                <th>Priority</th>
                                <th>Date submitted</th>
                                <th>Action</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php foreach ($reports as $report): ?>

                                <?php
                                $reportId = (int) $report['id'];
                                $status = (string) ($report['status'] ?? 'submitted');
                                $priority = (string) ($report['priority'] ?? 'medium');
                                ?>

                                <tr>
                                    <td>
                                        #<?= $reportId ?>
                                    </td>

                                    <td>
                                        <strong>
                                            <?= report_escape(
                                                (string) ($report['title'] ?? 'Untitled report')
                                            ) ?>
                                        </strong>
                                    </td>

                                    <td>
                                        <span class="report-status <?= report_escape($status) ?>">
                                            <?= report_escape(
                                                ucwords(str_replace('_', ' ', $status))
                                            ) ?>
                                        </span>
                                    </td>

                                    <td>
                                        <?= report_escape(ucfirst($priority)) ?>
                                    </td>

                                    <td>
                                        <?= report_escape(
                                            (string) ($report['created_at'] ?? '')
                                        ) ?>
                                    </td>

                                    <td>
                                        <a
                                            href="view.php?id=<?= $reportId ?>"
                                            class="btn btn-sm btn-outline-success"
                                            aria-label="View report <?= $reportId ?>"
                                        >
                                            <i class="bi bi-eye"></i>
                                            View
                                        </a>
                                    </td>
                                </tr>

                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

            <?php endif; ?>
        </section>

    <?php endif; ?>

    <section class="reports-card">
        <h2 class="h5 mb-3">Search and filter reports</h2>

        <form method="GET" action="index.php">

            <div class="reports-filters">

                <div>
                    <label class="reports-label" for="search">
                        Search my reports
                    </label>

                    <input
                        class="form-control"
                        type="search"
                        id="search"
                        name="search"
                        maxlength="200"
                        value="<?= report_escape($search) ?>"
                        placeholder="Search titles or descriptions"
                    >
                </div>

                <div>
                    <label class="reports-label" for="status">
                        Filter by status
                    </label>

                    <select
                        class="form-select"
                        id="status"
                        name="status"
                    >
                        <option value="">All statuses</option>

                        <?php foreach ($validStatuses as $statusOption): ?>

                            <option
                                value="<?= report_escape($statusOption) ?>"
                                <?= $statusFilter === $statusOption
                                    ? 'selected'
                                    : '' ?>
                            >
                                <?= report_escape(
                                    ucwords(str_replace('_', ' ', $statusOption))
                                ) ?>
                            </option>

                        <?php endforeach; ?>
                    </select>
                </div>

            </div>

            <div class="reports-actions mt-3">

                <button type="submit" class="btn btn-success">
                    <i class="bi bi-search"></i>
                    Search reports
                </button>

                <a href="index.php" class="btn btn-outline-secondary">
                    Reset
                </a>

                <a href="create.php" class="btn btn-outline-success">
                    <i class="bi bi-plus-circle"></i>
                    Report a new issue
                </a>

            </div>

        </form>
    </section>

</div>

<?php report_footer(); ?>