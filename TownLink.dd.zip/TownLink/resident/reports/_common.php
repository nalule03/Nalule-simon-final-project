<?php

declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| TownLink Resident Reports - Shared Functions
|--------------------------------------------------------------------------
*/

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

require_once __DIR__ . '/../../app/config/database.php';


/*
|--------------------------------------------------------------------------
| Escape output
|--------------------------------------------------------------------------
*/

function report_escape(mixed $value): string
{
    return htmlspecialchars(
        (string) $value,
        ENT_QUOTES | ENT_SUBSTITUTE,
        'UTF-8'
    );
}

/*
|--------------------------------------------------------------------------
| Authentication
|--------------------------------------------------------------------------
*/

function report_require_login(): void
{
    if (empty($_SESSION['user_id'])) {
        header('Location: ../../public/index.php');
        exit;
    }
}

/*
|--------------------------------------------------------------------------
| Current user's role
|--------------------------------------------------------------------------
*/

function report_role(): string
{
    return (string) ($_SESSION['role'] ?? '');
}

/*
|--------------------------------------------------------------------------
| CSRF protection
|--------------------------------------------------------------------------
*/

function report_csrf_token(): string
{
    if (
        empty($_SESSION['report_csrf_token'])
        || !is_string($_SESSION['report_csrf_token'])
    ) {
        $_SESSION['report_csrf_token'] = bin2hex(
            random_bytes(32)
        );
    }

    return $_SESSION['report_csrf_token'];
}

function report_verify_csrf(): bool
{
    $submittedToken = $_POST['csrf_token'] ?? '';
    $sessionToken = $_SESSION['report_csrf_token'] ?? '';

    return is_string($submittedToken)
        && is_string($sessionToken)
        && $sessionToken !== ''
        && hash_equals($sessionToken, $submittedToken);
}

/*
|--------------------------------------------------------------------------
| Resident navigation URLs
|--------------------------------------------------------------------------
*/

function report_navigation_urls(): array
{
    return [
        'dashboard'     => '../dashboard.php',
        'services'      => '../services.php',
        'requests'      => '../requests.php',
        'reports'       => 'index.php',
        'notifications' => '../notifications.php',
        'profile'       => '../profile.php',
        'logout'        => '../../public/logout.php',
    ];
}

/*
|--------------------------------------------------------------------------
| Resident display name
|--------------------------------------------------------------------------
*/

function report_resident_name(): string
{
    $firstName = trim(
        (string) ($_SESSION['first_name'] ?? '')
    );

    $lastName = trim(
        (string) ($_SESSION['last_name'] ?? '')
    );

    $name = trim($firstName . ' ' . $lastName);

    if ($name === '') {
        $name = trim(
            (string) ($_SESSION['name'] ?? '')
        );
    }

    if ($name === '') {
        $name = 'Resident';
    }

    return $name;
}

/*
|--------------------------------------------------------------------------
| Shared page header and resident navbar
|--------------------------------------------------------------------------
*/

/*
|--------------------------------------------------------------------------
| Shared page header
|--------------------------------------------------------------------------
*/

function report_header(string $title): void
{
    $safeTitle = report_escape($title);
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">

        <meta
            name="viewport"
            content="width=device-width, initial-scale=1.0"
        >

        <?php require_once __DIR__ . '/../_navbar.php'; ?>

        <title>
            <?= $safeTitle ?> | TownLink Resident Services
        </title>

        <link
            rel="stylesheet"
            href="../../assets/vendor/bootstrap/css/bootstrap.min.css"
        >

        <link
            rel="stylesheet"
            href="../../assets/vendor/bootstrap-icons/bootstrap-icons.css"
        >

        <style>
            body {
                margin: 0;
                background: #f4f7f6;
                color: #182b25;
                font-family: "Segoe UI", Arial, sans-serif;
            }

            .resident-main {
                min-height: 75vh;
                padding-top: 30px;
                padding-bottom: 55px;
            }

            .btn-townlink {
                background: #176b52;
                border-color: #176b52;
                color: #fff;
                border-radius: 9px;
                font-weight: 700;
            }

            .btn-townlink:hover,
            .btn-townlink:focus {
                background: #123b32;
                border-color: #123b32;
                color: #fff;
            }

            .form-control,
            .form-select {
                border-color: #e1e9e5;
                border-radius: 9px;
            }

            .form-control:focus,
            .form-select:focus {
                border-color: #176b52;
                box-shadow: 0 0 0 .2rem rgba(23, 107, 82, .12);
            }

            .resident-footer {
                background: #fff;
                border-top: 1px solid #e1e9e5;
            }

            @media (max-width: 576px) {
                .resident-main {
                    padding-top: 20px;
                    padding-bottom: 35px;
                }
            }
        </style>
    </head>

    <body>

    <main class="container resident-main">
    <?php
}


/*
|--------------------------------------------------------------------------
| Shared page footer
|--------------------------------------------------------------------------
*/

function report_footer(): void
{
    ?>

    </main>

    <footer class="resident-footer py-3">
        <div class="container text-center text-secondary small">
            &copy; <?= date('Y') ?> TownLink Namibia.
            Connecting residents with their municipalities.
        </div>
    </footer>

    <script src="../../assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    </body>
    </html>

    <?php
}