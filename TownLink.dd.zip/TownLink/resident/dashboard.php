<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| TownLink - Resident Dashboard
|--------------------------------------------------------------------------
*/

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

/*
|--------------------------------------------------------------------------
| Authentication
|--------------------------------------------------------------------------
*/

if (
    !isset($_SESSION['user_id']) ||
    ($_SESSION['role'] ?? '') !== 'resident'
) {
    header('Location: ../public/login.php');
    exit;
}

/*
|--------------------------------------------------------------------------
| Database connection
|--------------------------------------------------------------------------
|
| Update this path only if your connection file is stored elsewhere.
| The file must create a PDO connection named $pdo.
|
*/

require_once __DIR__ . '/../app/config/database.php';

if (!isset($pdo) || !$pdo instanceof PDO) {
    http_response_code(500);
    exit('Database connection is not available.');
}

/*
|--------------------------------------------------------------------------
| Helpers
|--------------------------------------------------------------------------
*/

if (!function_exists('residentDashboardEscape')) {
    function residentDashboardEscape(mixed $value): string
    {
        return htmlspecialchars(
            (string) ($value ?? ''),
            ENT_QUOTES | ENT_SUBSTITUTE,
            'UTF-8'
        );
    }
}

$userId = (int) $_SESSION['user_id'];
$municipalityId = isset($_SESSION['municipality_id'])
    ? (int) $_SESSION['municipality_id']
    : 0;

$firstName = trim((string) ($_SESSION['first_name'] ?? ''));
$lastName = trim((string) ($_SESSION['last_name'] ?? ''));

$fullName = trim($firstName . ' ' . $lastName);

if ($fullName === '') {
    $fullName = trim((string) ($_SESSION['name'] ?? 'Resident'));
}

if ($fullName === '') {
    $fullName = 'Resident';
}

/*
|--------------------------------------------------------------------------
| Dashboard data
|--------------------------------------------------------------------------
*/

$stats = [
    'total' => 0,
    'submitted' => 0,
    'in_progress' => 0,
    'resolved' => 0,
];

$recentRequests = [];
$recentNotifications = [];
$unreadNotifications = 0;
$municipalityName = 'Your Municipality';
$dashboardError = '';

try {
    /*
    |--------------------------------------------------------------------------
    | Get resident's municipality
    |--------------------------------------------------------------------------
    */

    $stmt = $pdo->prepare(
        'SELECT m.name
         FROM users u
         LEFT JOIN municipalities m ON m.id = u.municipality_id
         WHERE u.id = :user_id
         LIMIT 1'
    );

    $stmt->execute(['user_id' => $userId]);
    $userRecord = $stmt->fetch();

    if ($userRecord && !empty($userRecord['name'])) {
        $municipalityName = $userRecord['name'];
    }

    /*
    |--------------------------------------------------------------------------
    | Count only this resident's requests
    |--------------------------------------------------------------------------
    */

    $stmt = $pdo->prepare(
        "SELECT
            COUNT(*) AS total,
            COALESCE(SUM(status = 'submitted'), 0) AS submitted,
            COALESCE(SUM(status IN (
                'under_review',
                'assigned',
                'in_progress',
                'pending_resident'
            )), 0) AS in_progress,
            COALESCE(SUM(status IN ('resolved', 'closed')), 0) AS resolved
         FROM service_requests
         WHERE resident_id = :user_id"
    );

    $stmt->execute(['user_id' => $userId]);
    $counts = $stmt->fetch() ?: [];

    foreach ($stats as $key => $value) {
        $stats[$key] = (int) ($counts[$key] ?? 0);
    }

    /*
    |--------------------------------------------------------------------------
    | Recent service requests
    |--------------------------------------------------------------------------
    */

    $stmt = $pdo->prepare(
        "SELECT
            sr.id,
            sr.reference_number,
            sr.subject,
            sr.status,
            sr.priority,
            sr.submitted_at,
            s.name AS service_name
         FROM service_requests sr
         LEFT JOIN services s ON s.id = sr.service_id
         WHERE sr.resident_id = :user_id
         ORDER BY sr.submitted_at DESC, sr.id DESC
         LIMIT 5"
    );

    $stmt->execute(['user_id' => $userId]);
    $recentRequests = $stmt->fetchAll();

    /*
    |--------------------------------------------------------------------------
    | Unread notifications
    |--------------------------------------------------------------------------
    */

    $stmt = $pdo->prepare(
        'SELECT COUNT(*)
         FROM notifications
         WHERE user_id = :user_id
           AND is_read = 0'
    );

    $stmt->execute(['user_id' => $userId]);
    $unreadNotifications = (int) $stmt->fetchColumn();

    /*
    |--------------------------------------------------------------------------
    | Recent notifications
    |--------------------------------------------------------------------------
    */

    $stmt = $pdo->prepare(
        'SELECT id, title, message, type, is_read, created_at
         FROM notifications
         WHERE user_id = :user_id
         ORDER BY created_at DESC, id DESC
         LIMIT 4'
    );

    $stmt->execute(['user_id' => $userId]);
    $recentNotifications = $stmt->fetchAll();

} catch (PDOException $e) {
    error_log('TownLink resident dashboard error: ' . $e->getMessage());
    $dashboardError = 'Some dashboard information could not be loaded. Please refresh the page.';
}

/*
|--------------------------------------------------------------------------
| Presentation helpers
|--------------------------------------------------------------------------
*/

function residentDashboardStatus(string $status): string
{
    return match ($status) {
        'submitted' => 'Submitted',
        'under_review' => 'Under review',
        'assigned' => 'Assigned',
        'in_progress' => 'In progress',
        'pending_resident' => 'Awaiting you',
        'resolved' => 'Resolved',
        'closed' => 'Closed',
        'rejected' => 'Rejected',
        'cancelled' => 'Cancelled',
        default => ucfirst(str_replace('_', ' ', $status)),
    };
}

function residentDashboardStatusClass(string $status): string
{
    return match ($status) {
        'resolved', 'closed' => 'status-success',
        'in_progress', 'assigned' => 'status-progress',
        'submitted', 'under_review' => 'status-pending',
        'pending_resident' => 'status-warning',
        'rejected', 'cancelled' => 'status-danger',
        default => 'status-neutral',
    };
}

function residentDashboardDate(?string $date): string
{
    if (!$date) {
        return '—';
    }

    $timestamp = strtotime($date);

    return $timestamp === false
        ? '—'
        : date('d M Y', $timestamp);
}

$greeting = 'Welcome back';

$hour = (int) date('G');

if ($hour < 12) {
    $greeting = 'Good morning';
} elseif ($hour < 17) {
    $greeting = 'Good afternoon';
} else {
    $greeting = 'Good evening';
}

$pageTitle = 'Resident Dashboard';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title><?= residentDashboardEscape($pageTitle) ?> | TownLink</title>

    <link rel="stylesheet" href="../assets/vendor/bootstrap-icons/bootstrap-icons.css">

    <style>
        :root {
            --green: #176b52;
            --green-dark: #103d32;
            --green-light: #e8f5ef;
            --page: #f5f8f6;
            --text: #24372e;
            --muted: #748279;
            --border: #e5ece7;
            --white: #fff;
        }

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            background: var(--page);
            color: var(--text);
            font-family: "Segoe UI", Arial, sans-serif;
            font-size: 14px;
        }

        a {
            color: inherit;
        }

        .dashboard {
            width: min(1440px, 100%);
            margin: 0 auto;
            padding: 34px 32px 48px;
        }

        .welcome {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 24px;
            margin-bottom: 28px;
        }

        .eyebrow {
            color: var(--green);
            font-size: 11px;
            font-weight: 800;
            letter-spacing: 1.7px;
            text-transform: uppercase;
        }

        .welcome h1 {
            margin: 9px 0 8px;
            color: var(--green-dark);
            font-size: clamp(25px, 3vw, 34px);
            font-weight: 800;
            letter-spacing: -1px;
        }

        .welcome p {
            margin: 0;
            color: var(--muted);
            line-height: 1.7;
        }

        .welcome-date {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 13px 16px;
            border: 1px solid var(--border);
            border-radius: 12px;
            background: var(--white);
            color: #516258;
            white-space: nowrap;
        }

        .welcome-date i {
            color: var(--green);
            font-size: 19px;
        }

        .error-message {
            margin-bottom: 22px;
            padding: 14px 16px;
            border: 1px solid #f0d1ad;
            border-radius: 12px;
            background: #fff8ef;
            color: #89531c;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, minmax(0, 1fr));
            gap: 18px;
            margin-bottom: 28px;
        }

        .stat-card {
            min-width: 0;
            padding: 22px;
            border: 1px solid var(--border);
            border-radius: 17px;
            background: var(--white);
            box-shadow: 0 5px 20px rgba(16, 61, 50, .025);
        }

        .stat-top {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
        }

        .stat-label {
            color: var(--muted);
            font-size: 13px;
            font-weight: 650;
        }

        .stat-icon {
            width: 43px;
            height: 43px;
            display: grid;
            place-items: center;
            border-radius: 13px;
            font-size: 20px;
        }

        .icon-green {
            background: #e8f5ef;
            color: #176b52;
        }

        .icon-blue {
            background: #eaf1ff;
            color: #3565b5;
        }

        .icon-orange {
            background: #fff2e5;
            color: #b96919;
        }

        .icon-purple {
            background: #f0eaff;
            color: #7954bd;
        }

        .stat-number {
            margin: 17px 0 7px;
            color: var(--green-dark);
            font-size: 34px;
            font-weight: 850;
            letter-spacing: -1px;
            line-height: 1;
        }

        .stat-description {
            color: var(--muted);
            font-size: 12px;
        }

        .quick-actions {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 14px;
            margin-bottom: 30px;
        }

        .action-card {
            display: flex;
            align-items: center;
            gap: 15px;
            min-width: 0;
            padding: 19px;
            border: 1px solid var(--border);
            border-radius: 15px;
            background: var(--white);
            text-decoration: none;
            transition: transform .2s, border-color .2s, box-shadow .2s;
        }

        .action-card:hover {
            transform: translateY(-2px);
            border-color: #b8d9c8;
            box-shadow: 0 9px 25px rgba(16, 61, 50, .06);
        }

        .action-icon {
            width: 46px;
            height: 46px;
            display: grid;
            flex-shrink: 0;
            place-items: center;
            border-radius: 13px;
            background: var(--green-light);
            color: var(--green);
            font-size: 21px;
        }

        .action-content {
            flex: 1;
            min-width: 0;
        }

        .action-content strong {
            display: block;
            margin-bottom: 5px;
            color: var(--green-dark);
            font-size: 14px;
        }

        .action-content span {
            display: block;
            color: var(--muted);
            font-size: 12px;
            line-height: 1.5;
        }

        .action-arrow {
            color: #8c9b91;
            font-size: 18px;
        }

        .content-grid {
            display: grid;
            grid-template-columns: minmax(0, 1.65fr) minmax(280px, 1fr);
            align-items: start;
            gap: 22px;
        }

        .panel {
            min-width: 0;
            overflow: hidden;
            border: 1px solid var(--border);
            border-radius: 17px;
            background: var(--white);
        }

        .panel-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 14px;
            padding: 22px 23px;
            border-bottom: 1px solid var(--border);
        }

        .panel-title {
            margin: 0;
            color: var(--green-dark);
            font-size: 17px;
            font-weight: 800;
        }

        .panel-subtitle {
            margin: 6px 0 0;
            color: var(--muted);
            font-size: 12px;
        }

        .text-link {
            display: inline-flex;
            align-items: center;
            gap: 7px;
            color: var(--green);
            font-size: 12px;
            font-weight: 800;
            text-decoration: none;
            white-space: nowrap;
        }

        .text-link:hover {
            color: var(--green-dark);
        }

        .request-list {
            padding: 0 22px;
        }

        .request-item {
            display: grid;
            grid-template-columns: minmax(0, 1fr) auto;
            gap: 14px;
            align-items: center;
            padding: 20px 0;
            border-bottom: 1px solid #edf1ee;
        }

        .request-item:last-child {
            border-bottom: 0;
        }

        .request-reference {
            margin-bottom: 7px;
            color: var(--green);
            font-size: 11px;
            font-weight: 800;
            letter-spacing: .3px;
        }

        .request-title {
            margin: 0 0 7px;
            color: var(--text);
            font-size: 14px;
            font-weight: 750;
            overflow-wrap: anywhere;
        }

        .request-meta {
            display: flex;
            flex-wrap: wrap;
            gap: 7px 13px;
            color: var(--muted);
            font-size: 11px;
        }

        .request-meta i {
            margin-right: 4px;
        }

        .status {
            display: inline-flex;
            justify-content: center;
            align-items: center;
            padding: 7px 10px;
            border-radius: 20px;
            font-size: 10px;
            font-weight: 800;
            text-align: center;
            white-space: nowrap;
        }

        .status-success {
            background: #e5f6ec;
            color: #167348;
        }

        .status-progress {
            background: #e8f0ff;
            color: #315eae;
        }

        .status-pending {
            background: #fff2df;
            color: #9b6119;
        }

        .status-warning {
            background: #fff0d5;
            color: #8a5814;
        }

        .status-danger {
            background: #fdebea;
            color: #b42318;
        }

        .status-neutral {
            background: #edf0ee;
            color: #536258;
        }

        .notification-list {
            padding: 4px 22px 10px;
        }

        .notification-item {
            display: flex;
            gap: 12px;
            padding: 18px 0;
            border-bottom: 1px solid #edf1ee;
        }

        .notification-item:last-child {
            border-bottom: 0;
        }

        .notification-icon {
            width: 37px;
            height: 37px;
            display: grid;
            flex-shrink: 0;
            place-items: center;
            border-radius: 11px;
            background: var(--green-light);
            color: var(--green);
            font-size: 17px;
        }

        .notification-body {
            flex: 1;
            min-width: 0;
        }

        .notification-title {
            margin: 1px 0 6px;
            color: var(--text);
            font-size: 13px;
            font-weight: 800;
            overflow-wrap: anywhere;
        }

        .notification-message {
            margin: 0;
            color: var(--muted);
            font-size: 12px;
            line-height: 1.65;
            overflow-wrap: anywhere;
        }

        .notification-date {
            margin-top: 8px;
            color: #98a39b;
            font-size: 10px;
        }

        .unread-dot {
            width: 8px;
            height: 8px;
            margin-top: 6px;
            flex-shrink: 0;
            border-radius: 50%;
            background: #21966c;
        }

        .empty-state {
            padding: 38px 18px;
            color: var(--muted);
            text-align: center;
        }

        .empty-state i {
            display: block;
            margin-bottom: 13px;
            color: #a8c9b8;
            font-size: 34px;
        }

        .empty-state strong {
            display: block;
            margin-bottom: 8px;
            color: var(--green-dark);
            font-size: 14px;
        }

        .empty-state p {
            margin: 0 0 16px;
            font-size: 12px;
            line-height: 1.6;
        }

        .primary-link {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            padding: 11px 15px;
            border-radius: 9px;
            background: var(--green);
            color: #fff;
            font-size: 12px;
            font-weight: 800;
            text-decoration: none;
        }

        .primary-link:hover {
            background: var(--green-dark);
            color: #fff;
        }

        .notification-footer {
            padding: 15px 22px;
            border-top: 1px solid var(--border);
        }

        .dashboard-footer {
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 12px;
            margin-top: 26px;
            color: #87948b;
            font-size: 11px;
        }

        @media (max-width: 1100px) {
            .dashboard {
                padding-right: 22px;
                padding-left: 22px;
            }

            .stats-grid {
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }

            .content-grid {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 650px) {
            .dashboard {
                padding: 24px 15px 35px;
            }

            .welcome {
                align-items: flex-start;
                flex-direction: column;
                gap: 15px;
            }

            .welcome-date {
                padding: 10px 12px;
                font-size: 12px;
            }

            .stats-grid {
                gap: 11px;
                margin-bottom: 20px;
            }

            .stat-card {
                padding: 16px;
                border-radius: 14px;
            }

            .stat-label {
                font-size: 11px;
            }

            .stat-icon {
                width: 35px;
                height: 35px;
                font-size: 17px;
            }

            .stat-number {
                font-size: 29px;
            }

            .stat-description {
                font-size: 11px;
                line-height: 1.5;
            }

            .quick-actions {
                grid-template-columns: 1fr;
                gap: 10px;
                margin-bottom: 22px;
            }

            .action-card {
                padding: 15px;
            }

            .panel-header {
                padding: 18px 16px;
            }

            .panel-title {
                font-size: 15px;
            }

            .request-list {
                padding: 0 15px;
            }

            .request-item {
                grid-template-columns: 1fr;
                gap: 11px;
                padding: 17px 0;
            }

            .request-item > div:last-child {
                justify-self: start;
            }

            .notification-list {
                padding-right: 15px;
                padding-left: 15px;
            }

            .dashboard-footer {
                flex-direction: column;
            }
        }

        @media (max-width: 360px) {
            .stats-grid {
                grid-template-columns: 1fr;
            }
        }

        @media (prefers-reduced-motion: reduce) {
            *,
            *::before,
            *::after {
                transition: none !important;
                scroll-behavior: auto !important;
            }
        }
    </style>
</head>

<body>

    <?php require __DIR__ . '/_navbar.php'; ?>

    <main class="dashboard">

        <section class="welcome">
            <div>
                <div class="eyebrow">Resident portal</div>

                <h1>
                    <?= residentDashboardEscape($greeting) ?>,
                    <?= residentDashboardEscape($firstName !== '' ? $firstName : $fullName) ?>!
                </h1>

                <p>
                    Welcome to TownLink. Manage your municipal services
                    and keep track of your requests in one place.
                </p>

                <p style="margin-top: 7px;">
                    <i class="bi bi-geo-alt" aria-hidden="true"></i>
                    <?= residentDashboardEscape($municipalityName) ?>
                </p>
            </div>

            <div class="welcome-date">
                <i class="bi bi-calendar3" aria-hidden="true"></i>
                <span><?= date('l, d F Y') ?></span>
            </div>
        </section>

        <?php if ($dashboardError !== ''): ?>
            <div class="error-message" role="alert">
                <i class="bi bi-exclamation-triangle" aria-hidden="true"></i>
                <?= residentDashboardEscape($dashboardError) ?>
            </div>
        <?php endif; ?>

        <!-- Statistics -->

        <section class="stats-grid" aria-label="Request statistics">

            <article class="stat-card">
                <div class="stat-top">
                    <span class="stat-label">Total requests</span>
                    <span class="stat-icon icon-green">
                        <i class="bi bi-clipboard-data" aria-hidden="true"></i>
                    </span>
                </div>

                <div class="stat-number"><?= $stats['total'] ?></div>
                <div class="stat-description">All your service requests</div>
            </article>

            <article class="stat-card">
                <div class="stat-top">
                    <span class="stat-label">Submitted</span>
                    <span class="stat-icon icon-orange">
                        <i class="bi bi-send" aria-hidden="true"></i>
                    </span>
                </div>

                <div class="stat-number"><?= $stats['submitted'] ?></div>
                <div class="stat-description">Awaiting initial review</div>
            </article>

            <article class="stat-card">
                <div class="stat-top">
                    <span class="stat-label">In progress</span>
                    <span class="stat-icon icon-blue">
                        <i class="bi bi-arrow-repeat" aria-hidden="true"></i>
                    </span>
                </div>

                <div class="stat-number"><?= $stats['in_progress'] ?></div>
                <div class="stat-description">Being handled by the municipality</div>
            </article>

            <article class="stat-card">
                <div class="stat-top">
                    <span class="stat-label">Resolved</span>
                    <span class="stat-icon icon-purple">
                        <i class="bi bi-check2-circle" aria-hidden="true"></i>
                    </span>
                </div>

                <div class="stat-number"><?= $stats['resolved'] ?></div>
                <div class="stat-description">Resolved or closed requests</div>
            </article>

        </section>

        <!-- Quick actions -->

        <section class="quick-actions" aria-label="Quick actions">

            <a class="action-card" href="services.php">
                <span class="action-icon">
                    <i class="bi bi-building-add" aria-hidden="true"></i>
                </span>

                <span class="action-content">
                    <strong>Browse services</strong>
                    <span>Explore services offered by your municipality.</span>
                </span>

                <i class="bi bi-chevron-right action-arrow" aria-hidden="true"></i>
            </a>

            <a class="action-card" href="requests.php">
                <span class="action-icon">
                    <i class="bi bi-clipboard-check" aria-hidden="true"></i>
                </span>

                <span class="action-content">
                    <strong>My requests</strong>
                    <span>Review your requests and check their status.</span>
                </span>

                <i class="bi bi-chevron-right action-arrow" aria-hidden="true"></i>
            </a>

            <a class="action-card" href="notifications.php">
                <span class="action-icon">
                    <i class="bi bi-bell" aria-hidden="true"></i>
                </span>

                <span class="action-content">
                    <strong>Notifications</strong>
                    <span>
                        <?= $unreadNotifications ?>
                        unread notification<?= $unreadNotifications === 1 ? '' : 's' ?>.
                    </span>
                </span>

                <i class="bi bi-chevron-right action-arrow" aria-hidden="true"></i>
            </a>

        </section>

        <!-- Recent requests and notifications -->

        <section class="content-grid">

            <article class="panel">

                <header class="panel-header">
                    <div>
                        <h2 class="panel-title">Recent requests</h2>
                        <p class="panel-subtitle">Your latest municipal service activity</p>
                    </div>

                    <a class="text-link" href="requests.php">
                        View all <i class="bi bi-arrow-right" aria-hidden="true"></i>
                    </a>
                </header>

                <?php if (empty($recentRequests)): ?>

                    <div class="empty-state">
                        <i class="bi bi-clipboard2" aria-hidden="true"></i>
                        <strong>No requests yet</strong>
                        <p>
                            When you submit a municipal service request,
                            it will appear here.
                        </p>

                        <a class="primary-link" href="services.php">
                            <i class="bi bi-search" aria-hidden="true"></i>
                            Explore services
                        </a>
                    </div>

                <?php else: ?>

                    <div class="request-list">

                        <?php foreach ($recentRequests as $request): ?>

                            <?php
                            $status = (string) ($request['status'] ?? '');
                            $subject = trim((string) ($request['subject'] ?? ''));
                            ?>

                            <div class="request-item">

                                <div>
                                    <div class="request-reference">
                                        <?= residentDashboardEscape($request['reference_number']) ?>
                                    </div>

                                    <h3 class="request-title">
                                        <?= residentDashboardEscape($subject !== '' ? $subject : ($request['service_name'] ?? 'Service request')) ?>
                                    </h3>

                                    <div class="request-meta">
                                        <span>
                                            <i class="bi bi-building" aria-hidden="true"></i>
                                            <?= residentDashboardEscape($request['service_name'] ?? 'Municipal service') ?>
                                        </span>

                                        <span>
                                            <i class="bi bi-calendar3" aria-hidden="true"></i>
                                            <?= residentDashboardDate($request['submitted_at'] ?? null) ?>
                                        </span>
                                    </div>
                                </div>

                                <div>
                                    <span class="status <?= residentDashboardEscape(residentDashboardStatusClass($status)) ?>">
                                        <?= residentDashboardEscape(residentDashboardStatus($status)) ?>
                                    </span>
                                </div>

                            </div>

                        <?php endforeach; ?>

                    </div>

                <?php endif; ?>

            </article>

            <article class="panel">

                <header class="panel-header">
                    <div>
                        <h2 class="panel-title">Recent notifications</h2>
                        <p class="panel-subtitle">
                            Updates about your account and requests
                        </p>
                    </div>

                    <a class="text-link" href="notifications.php" aria-label="View all notifications">
                        <i class="bi bi-arrow-up-right" aria-hidden="true"></i>
                    </a>
                </header>

                <?php if (empty($recentNotifications)): ?>

                    <div class="empty-state">
                        <i class="bi bi-bell" aria-hidden="true"></i>
                        <strong>You're all caught up</strong>
                        <p>
                            New notifications will appear here when
                            there are updates.
                        </p>
                    </div>

                <?php else: ?>

                    <div class="notification-list">

                        <?php foreach ($recentNotifications as $notification): ?>

                            <div class="notification-item">

                                <span class="notification-icon">
                                    <i class="bi bi-bell" aria-hidden="true"></i>
                                </span>

                                <div class="notification-body">
                                    <h3 class="notification-title">
                                        <?= residentDashboardEscape($notification['title']) ?>
                                    </h3>

                                    <p class="notification-message">
                                        <?= residentDashboardEscape($notification['message']) ?>
                                    </p>

                                    <div class="notification-date">
                                        <?= residentDashboardDate($notification['created_at'] ?? null) ?>
                                    </div>
                                </div>

                                <?php if ((int) $notification['is_read'] === 0): ?>
                                    <span class="unread-dot" title="Unread notification"></span>
                                <?php endif; ?>

                            </div>

                        <?php endforeach; ?>

                    </div>

                    <div class="notification-footer">
                        <a class="text-link" href="notifications.php">
                            Open notifications
                            <i class="bi bi-arrow-right" aria-hidden="true"></i>
                        </a>
                    </div>

                <?php endif; ?>

            </article>

        </section>

        <footer class="dashboard-footer">
            <span>© <?= date('Y') ?> TownLink Resident Portal</span>
            <span>Connecting residents with municipal services.</span>
        </footer>

    </main>

</body>
</html>