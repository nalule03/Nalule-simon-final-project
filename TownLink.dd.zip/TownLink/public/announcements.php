<?php
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

require_once __DIR__ . '/../app/config/database.php';

/*
|--------------------------------------------------------------------------
| Check PDO connection
|--------------------------------------------------------------------------
*/
if (!isset($pdo) || !($pdo instanceof PDO)) {
    http_response_code(500);
    exit('TownLink database connection is unavailable.');
}

/*
|--------------------------------------------------------------------------
| Escape output
|--------------------------------------------------------------------------
*/
function e($value): string
{
    return htmlspecialchars(
        (string)($value ?? ''),
        ENT_QUOTES,
        'UTF-8'
    );
}

/*
|--------------------------------------------------------------------------
| Search and filter values
|--------------------------------------------------------------------------
*/
$search = trim((string)($_GET['q'] ?? ''));
$category = trim((string)($_GET['category'] ?? ''));

/*
|--------------------------------------------------------------------------
| Allowed announcement categories
|--------------------------------------------------------------------------
*/
$allowedCategories = [
    'Job opportunity',
    'Meeting',
    'Event',
    'Public notice',
    'Community programme',
    'General announcement',
    'Other'
];

/*
|--------------------------------------------------------------------------
| Validate selected category
|--------------------------------------------------------------------------
*/
$selectedCategory = in_array(
    $category,
    $allowedCategories,
    true
) ? $category : '';

/*
|--------------------------------------------------------------------------
| Build announcement query
|--------------------------------------------------------------------------
*/
$sql = "
    SELECT
        a.id,
        a.title,
        a.description,
        a.category,
        a.published_at,
        a.created_at,
        m.name AS municipality_name
    FROM announcements AS a
    INNER JOIN municipalities AS m
        ON m.id = a.municipality_id
    WHERE a.status = 'published'
      AND (
          a.expires_at IS NULL
          OR a.expires_at >= CURDATE()
      )
";

$params = [];

/*
|--------------------------------------------------------------------------
| Search filter
|--------------------------------------------------------------------------
*/
if ($search !== '') {
    $sql .= "
        AND (
            a.title LIKE :search_title
            OR a.description LIKE :search_description
            OR m.name LIKE :search_municipality
        )
    ";

    $searchTerm = '%' . $search . '%';

    $params[':search_title'] = $searchTerm;
    $params[':search_description'] = $searchTerm;
    $params[':search_municipality'] = $searchTerm;
}

/*
|--------------------------------------------------------------------------
| Category filter
|--------------------------------------------------------------------------
*/
if ($selectedCategory !== '') {
    $sql .= " AND a.category = :category";

    $params[':category'] = $selectedCategory;
}

/*
|--------------------------------------------------------------------------
| Sorting and result limit
|--------------------------------------------------------------------------
*/
$sql .= "
    ORDER BY COALESCE(a.published_at, a.created_at) DESC
    LIMIT 100
";

/*
|--------------------------------------------------------------------------
| Execute PDO query
|--------------------------------------------------------------------------
*/
try {
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);

    $announcements = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $exception) {
    error_log(
        'Announcement query failed: ' .
        $exception->getMessage()
    );

    http_response_code(500);
    exit('Unable to load announcements.');
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Announcements | TownLink</title>

    <meta
        name="description"
        content="Browse public announcements, job opportunities, meetings, events and municipal updates on TownLink."
    >

    <style>
        :root {
            --primary: #155eef;
            --primary-dark: #1248bd;
            --text: #172033;
            --muted: #667085;
            --border: #e4e7ec;
            --surface: #ffffff;
            --background: #f7f9fc;
        }

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, Helvetica, sans-serif;
            color: var(--text);
            background: var(--background);
            line-height: 1.6;
        }

        a {
            color: var(--primary);
        }

        .site-header {
            background: var(--surface);
            border-bottom: 1px solid var(--border);
        }

        .nav,
        .container {
            width: min(1120px, 92%);
            margin: 0 auto;
        }

        .nav {
            min-height: 68px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 16px;
        }

        .brand {
            font-size: 1.35rem;
            font-weight: 800;
            color: var(--text);
            text-decoration: none;
        }

        .nav-link {
            text-decoration: none;
            font-weight: 600;
        }

        .nav-link:hover {
            color: var(--primary-dark);
        }

        .hero {
            padding: 44px 0 24px;
        }

        .eyebrow {
            color: var(--primary);
            font-size: 0.8rem;
            font-weight: 800;
            text-transform: uppercase;
            letter-spacing: 0.08em;
        }

        h1 {
            margin: 8px 0;
            font-size: clamp(2rem, 5vw, 2.8rem);
            line-height: 1.15;
        }

        .intro {
            color: var(--muted);
            max-width: 680px;
            margin-bottom: 0;
        }

        .filters {
            display: grid;
            grid-template-columns:
                minmax(0, 1fr)
                minmax(190px, 0.45fr)
                auto;
            gap: 12px;
            padding: 18px;
            margin: 20px 0 28px;
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: 14px;
        }

        input,
        select,
        button {
            width: 100%;
            min-height: 46px;
            padding: 10px 12px;
            border: 1px solid #d0d5dd;
            border-radius: 8px;
            font: inherit;
            background: #ffffff;
        }

        input:focus,
        select:focus,
        button:focus {
            outline: 3px solid rgba(21, 94, 239, 0.15);
            outline-offset: 1px;
        }

        button {
            color: #ffffff;
            background: var(--primary);
            border-color: var(--primary);
            font-weight: 700;
            cursor: pointer;
        }

        button:hover {
            background: var(--primary-dark);
            border-color: var(--primary-dark);
        }

        .results-heading {
            display: flex;
            justify-content: space-between;
            align-items: baseline;
            gap: 12px;
            margin-bottom: 16px;
        }

        .results-heading h2 {
            margin: 0;
        }

        .muted {
            color: var(--muted);
        }

        .announcement-list {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 18px;
            padding-bottom: 48px;
        }

        .announcement {
            display: flex;
            flex-direction: column;
            align-items: flex-start;
            padding: 22px;
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: 14px;
            min-width: 0;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }

        .announcement:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 24px rgba(16, 24, 40, 0.08);
        }

        .category {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 999px;
            background: #eff4ff;
            color: #1849a9;
            font-size: 0.8rem;
            font-weight: 700;
        }

        .announcement h3 {
            margin: 14px 0 8px;
            font-size: 1.2rem;
            line-height: 1.35;
            overflow-wrap: anywhere;
        }

        .announcement h3 a {
            color: var(--text);
            text-decoration: none;
        }

        .announcement h3 a:hover {
            color: var(--primary);
        }

        .publisher {
            display: flex;
            align-items: flex-start;
            gap: 8px;
            margin: 0 0 12px;
            font-size: 0.92rem;
            font-weight: 700;
        }

        .publisher-icon {
            color: var(--primary);
            font-size: 1rem;
        }

        .description {
            color: #475467;
            overflow-wrap: anywhere;
            white-space: normal;
        }

        .date {
            margin-top: auto;
            padding-top: 16px;
            color: var(--muted);
            font-size: 0.85rem;
        }

        .read-more {
            display: inline-block;
            margin-top: 12px;
            font-weight: 700;
            text-decoration: none;
        }

        .read-more:hover {
            text-decoration: underline;
        }

        .empty {
            grid-column: 1 / -1;
            padding: 32px;
            text-align: center;
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: 14px;
        }

        .empty h3 {
            margin-top: 0;
        }

        footer {
            padding: 24px 0;
            background: var(--surface);
            border-top: 1px solid var(--border);
            color: var(--muted);
            font-size: 0.9rem;
        }

        @media (max-width: 700px) {
            .filters {
                grid-template-columns: 1fr;
            }

            .announcement-list {
                grid-template-columns: 1fr;
            }

            .hero {
                padding-top: 30px;
            }

            .results-heading {
                align-items: flex-start;
                flex-direction: column;
            }

            .nav {
                min-height: 60px;
            }

            .announcement {
                padding: 18px;
            }
        }
    </style>
</head>

<body>

    <header class="site-header">
        <nav class="nav" aria-label="Main navigation">
            <a class="brand" href="index.php">
                TownLink
            </a>

            <a class="nav-link" href="index.php">
                Home
            </a>
        </nav>
    </header>

    <main class="container">

        <section class="hero">
            <div class="eyebrow">
                Your community, informed
            </div>

            <h1>Municipal Announcements</h1>

            <p class="intro">
                Discover job opportunities, public meetings,
                community events, service notices and updates
                published by municipalities.
            </p>
        </section>

        <form
            class="filters"
            method="get"
            action="announcements.php"
        >
            <input
                type="search"
                name="q"
                value="<?= e($search) ?>"
                placeholder="Search announcements or municipalities"
                aria-label="Search announcements"
            >

            <select
                name="category"
                aria-label="Filter by category"
            >
                <option value="">All categories</option>

                <?php foreach ($allowedCategories as $item): ?>
                    <option
                        value="<?= e($item) ?>"
                        <?= $selectedCategory === $item
                            ? 'selected'
                            : ''
                        ?>
                    >
                        <?= e($item) ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <button type="submit">Search</button>
        </form>

        <div class="results-heading">
            <h2>Latest updates</h2>

            <span class="muted">
                <?= count($announcements) ?> shown
            </span>
        </div>

        <section
            class="announcement-list"
            aria-label="Published announcements"
        >

            <?php if (!$announcements): ?>

                <div class="empty">
                    <h3>No announcements found</h3>

                    <p class="muted">
                        Try another search term or choose
                        a different category.
                    </p>
                </div>

            <?php else: ?>

                <?php foreach ($announcements as $announcement): ?>

                    <?php
                    /*
                    |--------------------------------------------------------------------------
                    | Determine display date
                    |--------------------------------------------------------------------------
                    */
                    $dateValue = $announcement['published_at']
                        ?: $announcement['created_at'];

                    $timestamp = $dateValue
                        ? strtotime((string)$dateValue)
                        : false;

                    $displayDate = $timestamp !== false
                        ? date('j M Y', $timestamp)
                        : 'Date unavailable';

                    /*
                    |--------------------------------------------------------------------------
                    | Prepare description summary
                    |--------------------------------------------------------------------------
                    */
                    $plainDescription = trim(
                        strip_tags(
                            (string)($announcement['description'] ?? '')
                        )
                    );

                    if (
                        function_exists('mb_strlen')
                        && mb_strlen($plainDescription) > 180
                    ) {
                        $summary = mb_substr(
                            $plainDescription,
                            0,
                            180
                        ) . '…';

                    } elseif (strlen($plainDescription) > 180) {
                        $summary = substr(
                            $plainDescription,
                            0,
                            180
                        ) . '…';

                    } else {
                        $summary = $plainDescription;
                    }

                    $announcementId = (int)$announcement['id'];
                    ?>

                    <article class="announcement">

                        <span class="category">
                            <?= e(
                                $announcement['category']
                                ?: 'Announcement'
                            ) ?>
                        </span>

                        <h3>
                            <a href="announcement-details.php?id=<?= $announcementId ?>">
                                <?= e($announcement['title']) ?>
                            </a>
                        </h3>

                        <p class="publisher">
                            <span
                                class="publisher-icon"
                                aria-hidden="true"
                            >▣</span>

                            <span>
                                Published by:
                                <?= e($announcement['municipality_name']) ?>
                            </span>
                        </p>

                        <div class="description">
                            <?= e($summary) ?>
                        </div>

                        <div class="date">
                            Published: <?= e($displayDate) ?>
                        </div>

                        <a
                            class="read-more"
                            href="announcement-details.php?id=<?= $announcementId ?>"
                        >
                            Read full announcement →
                        </a>

                    </article>

                <?php endforeach; ?>

            <?php endif; ?>

        </section>

    </main>

    <footer>
        <div class="container">
            TownLink — Municipal information and community updates.
        </div>
    </footer>

</body>
</html>