<?php

declare(strict_types=1);

require_once __DIR__ . '/../auth.php';
require_once __DIR__ . '/../layout.php';

$stmt = $pdo->prepare("
    SELECT
        s.id,
        s.name,
        s.description,
        s.estimated_days,
        s.status,
        s.created_at,
        d.name AS department_name,
        d.code AS department_code,
        c.name AS category_name

    FROM services s

    INNER JOIN departments d
        ON d.id = s.department_id

    LEFT JOIN service_categories c
        ON c.id = s.category_id

    WHERE s.municipality_id = :municipality_id

    ORDER BY s.name ASC
");

$stmt->execute([
    ':municipality_id' => $municipalityId
]);

$services =
    $stmt->fetchAll(PDO::FETCH_ASSOC);

municipalityHeader(
    'Services',
    'services'
);

?>

<div class="page-header">

    <div>
        <h2>Municipal Services</h2>
        <p>Manage services residents can request.</p>
    </div>

    <?php if (isMunicipalityAdmin()): ?>

        <a
            class="button"
            href="create.php"
        >
            + Add Service
        </a>

    <?php endif; ?>

</div>

<div class="card">

    <?php if (!$services): ?>

        <p class="muted">
            No services have been created yet.
        </p>

    <?php else: ?>

        <table>

            <thead>

            <tr>
                <th>Service</th>
                <th>Department</th>
                <th>Category</th>
                <th>Estimated Days</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>

            </thead>

            <tbody>

            <?php foreach ($services as $service): ?>

                <tr>

                    <td>
                        <strong>
                            <?= e($service['name']) ?>
                        </strong>

                        <br>

                        <small class="muted">
                            <?= e(
                                $service['description']
                            ) ?>
                        </small>
                    </td>

                    <td>
                        <?= e(
                            $service['department_name']
                        ) ?>
                    </td>

                    <td>
                        <?= e(
                            $service['category_name']
                        ) ?: 'Uncategorised' ?>
                    </td>

                    <td>
                        <?php if (
                            $service['estimated_days'] !== null
                        ): ?>

                            <?= (int) $service['estimated_days'] ?>
                            days

                        <?php else: ?>

                            Not specified

                        <?php endif; ?>
                    </td>

                    <td>

                        <span
                            class="badge <?= e($service['status']) ?>"
                        >
                            <?= e(
                                ucfirst(
                                    $service['status']
                                )
                            ) ?>
                        </span>

                    </td>

                    <td>

                        <div class="actions">

                            <a
                                class="button secondary"
                                href="view.php?id=<?= (int) $service['id'] ?>"
                            >
                                View
                            </a>

                            <?php if (isMunicipalityAdmin()): ?>

                                <a
                                    class="button"
                                    href="edit.php?id=<?= (int) $service['id'] ?>"
                                >
                                    Edit
                                </a>

                            <?php endif; ?>

                        </div>

                    </td>

                </tr>

            <?php endforeach; ?>

            </tbody>

        </table>

    <?php endif; ?>

</div>

<?php

municipalityFooter();
