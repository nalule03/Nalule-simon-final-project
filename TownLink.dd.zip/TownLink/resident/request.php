<?php
declare(strict_types=1);

/*

|--------------------------------------------------------------------------

| TownLink - Resident Service Request

|--------------------------------------------------------------------------

*/

session_start();

require_once __DIR__ . '/../app/config/database.php';

if (!isset($pdo) || !($pdo instanceof PDO)) {

    http_response_code(500);

    exit('Database connection is unavailable.');

}

/*

|--------------------------------------------------------------------------

| Authentication

|--------------------------------------------------------------------------
 
*/

if (empty($_SESSION['user_id'])) {

    header('Location: ../public/login.php');

    exit;

}

if (($_SESSION['role'] ?? '') !== 'resident') {

    http_response_code(403);

    exit('Access denied.');

}

$userId = (int) $_SESSION['user_id'];

$firstName = (string) ($_SESSION['first_name'] ?? 'Resident');

function requestEscape(mixed $value): string

{

    return htmlspecialchars(

        (string) ($value ?? ''),

        ENT_QUOTES | ENT_SUBSTITUTE,

        'UTF-8'

    );

}

/*

|--------------------------------------------------------------------------

| CSRF Protection

|--------------------------------------------------------------------------

*/

if (empty($_SESSION['csrf_token'])) {

    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));

}

$csrfToken = (string) $_SESSION['csrf_token'];

/*

|--------------------------------------------------------------------------

| Form Values

|--------------------------------------------------------------------------

*/

$method = $_SERVER['REQUEST_METHOD'];

$serviceId = filter_var(

    $method === 'POST'

        ? ($_POST['service_id'] ?? null)

        : ($_GET['service_id'] ?? null),

    FILTER_VALIDATE_INT

);

$serviceId = (

    $serviceId !== false &&

    $serviceId !== null &&

    $serviceId > 0

) ? (int) $serviceId : 0;

$subject = trim((string) ($_POST['subject'] ?? ''));

$description = trim((string) ($_POST['description'] ?? ''));

$priority = (string) ($_POST['priority'] ?? 'normal');

$locationDescription = trim(

    (string) ($_POST['location_description'] ?? '')

);

$erfNumber = trim((string) ($_POST['erf_number'] ?? ''));

$streetName = trim((string) ($_POST['street_name'] ?? ''));

$houseNumber = trim((string) ($_POST['house_number'] ?? ''));

$area = trim((string) ($_POST['area'] ?? ''));

$landmark = trim((string) ($_POST['landmark'] ?? ''));

$allowedPriorities = ['low', 'normal', 'high', 'urgent'];

$errors = [];

$success = false;

$referenceNumber = '';

$errorMessage = '';

$service = null;

$services = [];

$municipalityId = 0;

/*

|--------------------------------------------------------------------------

| Verify Resident and Load Municipal Services

|--------------------------------------------------------------------------

*/

try {

    $stmt = $pdo->prepare("

        SELECT id, first_name, municipality_id, role, status

        FROM users

        WHERE id = :user_id

          AND role = 'resident'

        LIMIT 1

    ");

    $stmt->execute([':user_id' => $userId]);

    $resident = $stmt->fetch(PDO::FETCH_ASSOC);

    if (

        !$resident ||

        $resident['status'] !== 'active' ||

        (int) $resident['municipality_id'] <= 0

    ) {

        http_response_code(403);

        exit('Your account is inactive or is not linked to a municipality.');

    }

    // Use the municipality stored in the verified database record.

    $municipalityId = (int) $resident['municipality_id'];

    $firstName = (string) ($resident['first_name'] ?? 'Resident');

    // Always load active services belonging to this municipality.

    $stmt = $pdo->prepare("

        SELECT

            id,

            municipality_id,

            name,

            description,

            instructions,

            estimated_days,

            department_id

        FROM services

        WHERE municipality_id = :municipality_id

          AND status = 'active'

        ORDER BY name ASC

    ");

    $stmt->execute([

        ':municipality_id' => $municipalityId

    ]);

    $services = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Load the selected service, if one was requested.

    if ($serviceId > 0) {

        $stmt = $pdo->prepare("

            SELECT

                id,

                municipality_id,

                name,

                description,

                instructions,

                estimated_days,

                department_id

            FROM services

            WHERE id = :service_id

              AND municipality_id = :municipality_id

              AND status = 'active'

            LIMIT 1

        ");

        $stmt->execute([

            ':service_id' => $serviceId,

            ':municipality_id' => $municipalityId

        ]);

        $service = $stmt->fetch(PDO::FETCH_ASSOC) ?: null;

        if (!$service) {

            $errorMessage =

                'The selected service is unavailable. Please choose an available service.';

        }

    } elseif ($method === 'POST') {

        $errorMessage = 'Please select a valid municipal service.';

    }

} catch (PDOException $e) {

    error_log('TownLink service request loading error: ' . $e->getMessage());

    http_response_code(500);

    exit('Unable to load municipal services. Please try again later.');

}

/*

|--------------------------------------------------------------------------

| Process Request Submission

|--------------------------------------------------------------------------

*/

if ($method === 'POST' && $service !== null) {

    $submittedToken = (string) ($_POST['csrf_token'] ?? '');

    if (

        $submittedToken === '' ||

        !hash_equals($csrfToken, $submittedToken)

    ) {

        $errors[] = 'Your session token has expired. Refresh the page and try again.';

    }

    if ($subject === '') {

        $errors[] = 'Please enter a request subject.';

    } elseif (mb_strlen($subject) > 255) {

        $errors[] = 'The subject cannot exceed 255 characters.';

    }

    if ($description === '') {

        $errors[] = 'Please describe the issue or service you need.';

    } elseif (mb_strlen($description) > 10000) {

        $errors[] = 'The description cannot exceed 10,000 characters.';

    }

    if (!in_array($priority, $allowedPriorities, true)) {

        $errors[] = 'Please select a valid priority.';

    }

    $locationValues = [

        'Location description' => [$locationDescription, 255],

        'ERF number' => [$erfNumber, 100],

        'Street name' => [$streetName, 255],

        'House or plot number' => [$houseNumber, 100],

        'Area' => [$area, 150],

        'Landmark' => [$landmark, 255],

    ];

    foreach ($locationValues as $label => [$value, $limit]) {

        if (mb_strlen($value) > $limit) {

            $errors[] = $label . " cannot exceed {$limit} characters.";

        }

    }

    if (!$errors) {

        try {

            $pdo->beginTransaction();

            // Verify that the selected service is still available.

            $stmt = $pdo->prepare("

                SELECT id

                FROM services

                WHERE id = :service_id

                  AND municipality_id = :municipality_id

                  AND status = 'active'

                LIMIT 1

            ");

            $stmt->execute([

                ':service_id' => $serviceId,

                ':municipality_id' => $municipalityId

            ]);

            if (!$stmt->fetchColumn()) {

                throw new RuntimeException(

                    'This service is no longer available. Please select another service.'

                );

            }

            // Generate a cryptographically random request reference.

            $referenceNumber = 'TL-' . date('Ymd') . '-'

                . strtoupper(bin2hex(random_bytes(8)));

            // Insert the new service request.

            $stmt = $pdo->prepare("

                INSERT INTO service_requests (

                    municipality_id,

                    resident_id,

                    service_id,

                    reference_number,

                    subject,

                    description,

                    location_description,

                    erf_number,

                    street_name,

                    house_number,

                    area,

                    landmark,

                    priority,

                    status

                ) VALUES (

                    :municipality_id,

                    :resident_id,

                    :service_id,

                    :reference_number,

                    :subject,

                    :description,

                    :location_description,

                    :erf_number,

                    :street_name,

                    :house_number,

                    :area,

                    :landmark,

                    :priority,

                    'submitted'

                )

            ");

            $stmt->execute([

                ':municipality_id' => $municipalityId,

                ':resident_id' => $userId,

                ':service_id' => $serviceId,

                ':reference_number' => $referenceNumber,

                ':subject' => $subject,

                ':description' => $description,

                ':location_description' =>

                    $locationDescription !== '' ? $locationDescription : null,

                ':erf_number' =>

                    $erfNumber !== '' ? $erfNumber : null,

                ':street_name' =>

                    $streetName !== '' ? $streetName : null,

                ':house_number' =>

                    $houseNumber !== '' ? $houseNumber : null,

                ':area' => $area !== '' ? $area : null,

                ':landmark' => $landmark !== '' ? $landmark : null,

                ':priority' => $priority

            ]);

            $pdo->commit();

            // Rotate the token after a successful submission.

            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));

            $csrfToken = (string) $_SESSION['csrf_token'];

            $success = true;

            // Clear the form after successful submission.

            $subject = '';

            $description = '';

            $priority = 'normal';

            $locationDescription = '';

            $erfNumber = '';

            $streetName = '';

            $houseNumber = '';

            $area = '';

            $landmark = '';

        } catch (Throwable $e) {

            if ($pdo->inTransaction()) {

                $pdo->rollBack();

            }

            error_log('TownLink request submission error: ' . $e->getMessage());

            $errors[] = $e instanceof RuntimeException

                ? $e->getMessage()

                : 'Your request could not be submitted. Please try again.';

        }

    }

}

?>

<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Service Requests | TownLink</title>

    <style>

        * {

            box-sizing: border-box;

        }

        body {

            margin: 0;

            font-family: Arial, Helvetica, sans-serif;

            background: #f4f7f6;

            color: #172b26;

            line-height: 1.6;

        }

        a {

            color: #176b57;

        }

        .topbar {

            background: #fff;

            border-bottom: 1px solid #dfe8e4;

        }

        .topbar-inner {

            max-width: 1100px;

            margin: auto;

            padding: 16px 22px;

            display: flex;

            justify-content: space-between;

            align-items: center;

            gap: 15px;

            flex-wrap: wrap;

        }

        .brand {

            margin: 0;

            color: #176b57;

            font-size: 25px;

            font-weight: 800;

        }

        .nav {

            display: flex;

            gap: 17px;

            flex-wrap: wrap;

        }

        .nav a {

            text-decoration: none;

            font-size: 14px;

            font-weight: 600;

        }

        .container {

            max-width: 1000px;

            margin: auto;

            padding: 30px 20px 50px;

        }

        .heading {

            margin-bottom: 25px;

        }

        .heading h1 {

            margin: 0 0 6px;

            font-size: clamp(25px, 4vw, 33px);

        }

        .muted {

            color: #65756f;

        }

        .panel {

            background: #fff;

            border: 1px solid #dfe8e4;

            border-radius: 12px;

            padding: 24px;

            margin-bottom: 22px;

            box-shadow: 0 3px 12px rgb(20 50 40 / 4%);

        }

        .service-grid {

            display: grid;

            grid-template-columns: repeat(2, minmax(0, 1fr));

            gap: 18px;

        }

        .service-card {

            background: #fff;

            border: 1px solid #dfe8e4;

            border-radius: 12px;

            padding: 22px;

            display: flex;

            flex-direction: column;

            align-items: flex-start;

        }

        .service-card h2 {

            margin: 0 0 8px;

            font-size: 20px;

        }

        .service-card p {

            color: #65756f;

            margin: 0 0 15px;

        }

        .service-card .button {

            margin-top: auto;

        }

        .service-summary {

            border-left: 4px solid #176b57;

        }

        .field {

            margin-bottom: 18px;

        }

        .field label {

            display: block;

            font-weight: 700;

            margin-bottom: 6px;

            font-size: 14px;

        }

        .field input,

        .field textarea,

        .field select {

            width: 100%;

            padding: 12px;

            border: 1px solid #b9c9c1;

            border-radius: 8px;

            background: #fff;

            color: #172b26;

            font: inherit;

        }

        .field input:focus,

        .field textarea:focus,

        .field select:focus {

            outline: 2px solid #176b57;

            outline-offset: 1px;

        }

        .field textarea {

            min-height: 135px;

            resize: vertical;

        }

        .field small {

            display: block;

            margin-top: 5px;

            color: #65756f;

        }

        .field-grid {

            display: grid;

            grid-template-columns: repeat(2, minmax(0, 1fr));

            gap: 0 16px;

        }

        .full-width {

            grid-column: 1 / -1;

        }

        .button {

            display: inline-flex;

            justify-content: center;

            align-items: center;

            min-height: 44px;

            padding: 11px 18px;

            border: none;

            border-radius: 8px;

            background: #176b57;

            color: #fff;

            text-decoration: none;

            font-size: 14px;

            font-weight: 700;

            cursor: pointer;

        }

        .button:hover {

            background: #105343;

        }

        .button-secondary {

            background: #e8efeb;

            color: #234b3f;

        }

        .button-secondary:hover {

            background: #d6e3dc;

        }

        .form-actions {

            display: flex;

            gap: 12px;

            flex-wrap: wrap;

            margin-top: 20px;

        }

        .alert {

            padding: 16px 18px;

            margin-bottom: 20px;

            border-radius: 9px;

        }

        .alert-error {

            color: #8c2222;

            background: #fff0f0;

            border: 1px solid #f0caca;

        }

        .alert-success {

            color: #145b40;

            background: #e8f8ef;

            border: 1px solid #b9e5ca;

        }

        .reference {

            display: inline-block;

            margin: 8px 0;

            padding: 10px 14px;

            background: #fff;

            border: 1px solid #b9e5ca;

            border-radius: 7px;

            font-size: 18px;

            font-weight: 800;

            overflow-wrap: anywhere;

        }

        .required {

            color: #b42318;

        }

        @media (max-width: 650px) {

            .container {

                padding: 22px 14px 35px;

            }

            .panel,

            .service-card {

                padding: 17px;

            }

            .service-grid,

            .field-grid {

                grid-template-columns: 1fr;

            }

            .full-width {

                grid-column: auto;

            }

            .form-actions .button {

                width: 100%;

            }

        }

    </style>

</head>

<body>

<main class="container">

    <div class="heading">

        <h1>Submit a Service Request</h1>

        <p class="muted">

            Welcome, <?= requestEscape($firstName) ?>.

            Choose a municipal service or follow the progress of a request

            you have already submitted.

        </p>

    </div>

    <?php if ($success): ?>

        <section class="alert alert-success" role="status">

            <h2>Request submitted successfully!</h2>

            <p>Your request has been saved in TownLink.</p>

            <p>Your reference number is:</p>

            <div class="reference" id="requestReference"><?= requestEscape($referenceNumber) ?></div>

            <p>

                Keep this number for your records and when following up.

            </p>

            <div class="form-actions">

                <button

                    type="button"

                    class="button"

                    id="copyReference"

                >

                    Copy Reference Number

                </button>

                <a class="button" href="requests.php">

                    View My Requests

                </a>

                <a class="button button-secondary" href="request.php">

                    Submit Another Request

                </a>

            </div>

            <p id="copyMessage" aria-live="polite"></p>

        </section>

    <?php elseif ($service === null): ?>

        <?php if ($errorMessage !== ''): ?>

            <div class="alert alert-error" role="alert">

                <?= requestEscape($errorMessage) ?>

            </div>

        <?php endif; ?>

        <section class="panel">

            <h2>Available Municipal Services</h2>

            <p class="muted">

                Select the service that best matches your issue or request.

            </p>

        </section>

        <?php if (count($services) > 0): ?>

            <div class="service-grid">

                <?php foreach ($services as $availableService): ?>

                    <article class="service-card">

                        <h2><?= requestEscape($availableService['name']) ?></h2>

                        <p>

                            <?= requestEscape(

                                $availableService['description']

                                ?: 'Municipal service'

                            ) ?>

                        </p>

                        <?php if ($availableService['estimated_days'] !== null): ?>

                            <p>

                                <strong>Estimated processing:</strong>

                                <?= (int) $availableService['estimated_days'] ?>

                                day(s)

                            </p>

                        <?php endif; ?>

                        <a

                            class="button"

                            href="request.php?service_id=<?= (int) $availableService['id'] ?>"

                        >

                            Select This Service

                        </a>

                    </article>

                <?php endforeach; ?>

            </div>

        <?php else: ?>

            <section class="panel">

                <h2>No services available yet</h2>

                <p class="muted">

                    Your municipality has no active services available

                    through TownLink at the moment. Please try again later

                    or contact your municipality.

                </p>

                <a class="button" href="dashboard.php">Return to Dashboard</a>

            </section>

        <?php endif; ?>

    <?php else: ?>

        <?php if ($errors): ?>

            <div class="alert alert-error" role="alert">

                <strong>Please correct the following:</strong>

                <ul>

                    <?php foreach ($errors as $error): ?>

                        <li><?= requestEscape($error) ?></li>

                    <?php endforeach; ?>

                </ul>

            </div>

        <?php endif; ?>

        <section class="panel service-summary">

            <h2><?= requestEscape($service['name']) ?></h2>

            <p class="muted">

                <?= requestEscape(

                    $service['description'] ?: 'Municipal service'

                ) ?>

            </p>

            <?php if ($service['estimated_days'] !== null): ?>

                <p>

                    <strong>Estimated processing:</strong>

                    <?= (int) $service['estimated_days'] ?> day(s)

                </p>

            <?php endif; ?>

            <?php if (!empty($service['instructions'])): ?>

                <details>

                    <summary>Instructions for this service</summary>

                    <p><?= nl2br(requestEscape($service['instructions'])) ?></p>

                </details>

            <?php endif; ?>

        </section>

        <form
            method="POST"
            enctype="multipart/form-data"
            class="panel"
            id="requestForm"
        >
            <input

                type="hidden"

                name="csrf_token"

                value="<?= requestEscape($csrfToken) ?>"

            >

            <input

                type="hidden"

                name="service_id"

                value="<?= (int) $service['id'] ?>"

            >

            <h2>Request Details</h2>

            <div class="field">

                <label for="subject">

                    Request subject <span class="required">*</span>

                </label>

                <input

                    type="text"

                    id="subject"

                    name="subject"

                    maxlength="255"

                    value="<?= requestEscape($subject) ?>"

                    placeholder="For example, damaged streetlight"

                    required

                >

            </div>

            <div class="field">

                <label for="description">

                    Description <span class="required">*</span>

                </label>

                <textarea

                    id="description"

                    name="description"

                    maxlength="10000"

                    required

                    placeholder="Explain the issue, where it happened, and what assistance you need."

                ><?= requestEscape($description) ?></textarea>

            </div>

            <div class="field">

                <label for="priority">Priority</label>

                <select id="priority" name="priority">

                    <option value="low" <?= $priority === 'low' ? 'selected' : '' ?>>Low</option>

                    <option value="normal" <?= $priority === 'normal' ? 'selected' : '' ?>>Normal</option>

                    <option value="high" <?= $priority === 'high' ? 'selected' : '' ?>>High</option>

                    <option value="urgent" <?= $priority === 'urgent' ? 'selected' : '' ?>>Urgent</option>

                </select>

                <small>

                    Select urgent only for issues requiring immediate

                    municipal attention.

                </small>

            </div>

            <h2>Location Details</h2>

            <p class="muted">

                Provide the location where the service is needed, if applicable.

            </p>

            <div class="field-grid">

                <div class="field">

                    <label for="street_name">Street name</label>

                    <input

                        type="text"

                        id="street_name"

                        name="street_name"

                        maxlength="255"

                        value="<?= requestEscape($streetName) ?>"

                    >

                </div>

                <div class="field">

                    <label for="house_number">House / Plot number</label>

                    <input

                        type="text"

                        id="house_number"

                        name="house_number"

                        maxlength="100"

                        value="<?= requestEscape($houseNumber) ?>"

                    >

                </div>

                <div class="field">

                    <label for="area">Area / Neighbourhood</label>

                    <input

                        type="text"

                        id="area"

                        name="area"

                        maxlength="150"

                        value="<?= requestEscape($area) ?>"

                    >

                </div>

                <div class="field">

                    <label for="erf_number">ERF number</label>

                    <input

                        type="text"

                        id="erf_number"

                        name="erf_number"

                        maxlength="100"

                        value="<?= requestEscape($erfNumber) ?>"

                    >

                </div>

                <div class="field full-width">

                    <label for="landmark">Nearby landmark</label>

                    <input

                        type="text"

                        id="landmark"

                        name="landmark"

                        maxlength="255"

                        value="<?= requestEscape($landmark) ?>"

                        placeholder="For example, near a school or clinic"

                    >

                </div>

                <div class="field full-width">

                    <label for="location_description">

                        Additional location details

                    </label>

                    <input

                        type="text"

                        id="location_description"

                        name="location_description"

                        maxlength="255"

                        value="<?= requestEscape($locationDescription) ?>"

                        placeholder="Other information to help locate the issue"

                    >

                </div>

            </div>
            <!-- Evidence Upload -->
            <div class="field">
                <label for="evidence_images">
                    Upload Pictures as Evidence (Optional)
                </label>

                <input
                    type="file"
                    id="evidence_images"
                    name="evidence_images[]"
                    accept="image/jpeg,image/png,image/webp"
                    multiple
                >

                <small>
                    Upload photos showing the issue. Accepted formats:
                    JPG, PNG, and WebP. Maximum 5 MB per image.
                    You can select multiple pictures.
                </small>

                <div id="imagePreview"
                    style="display:flex; flex-wrap:wrap; gap:12px; margin-top:12px;">
                </div>
            </div>

            <div class="form-actions">

                <button type="submit" class="button" id="submitButton">

                    Submit Request

                </button>

                <a href="request.php" class="button button-secondary">

                    Choose Another Service

                </a>

                <a href="services.php" class="button button-secondary">

                    Browse Services

                </a>

            </div>

        </form>

    <?php endif; ?>

</main>

<script>

(function () {

    'use strict';

    const form = document.getElementById('requestForm');

    const submitButton = document.getElementById('submitButton');

    if (form && submitButton) {

        form.addEventListener('submit', function (event) {

            if (!form.reportValidity()) {

                event.preventDefault();

                return;

            }

            submitButton.disabled = true;

            submitButton.textContent = 'Submitting...';

        });

    }

    const copyButton = document.getElementById('copyReference');

    const reference = document.getElementById('requestReference');

    const copyMessage = document.getElementById('copyMessage');

    if (copyButton && reference && copyMessage) {

        copyButton.addEventListener('click', async function () {

            try {

                await navigator.clipboard.writeText(

                    reference.textContent.trim()

                );

                copyMessage.textContent = 'Reference number copied.';

            } catch (error) {

                copyMessage.textContent =

                    'Please select and copy the reference number manually.';

            }

        });

    }
    const evidenceInput = document.getElementById('evidence_images');
    const imagePreview = document.getElementById('imagePreview');

    if (evidenceInput && imagePreview) {
        evidenceInput.addEventListener('change', function () {
            imagePreview.replaceChildren();

            const files = Array.from(this.files || []);
            const maxSize = 5 * 1024 * 1024;
            const allowedTypes = [
                'image/jpeg',
                'image/png',
                'image/webp'
            ];

            for (const file of files) {
                if (!allowedTypes.includes(file.type)) {
                    alert(file.name + ': Please select a JPG, PNG, or WebP image.');
                    this.value = '';
                    imagePreview.replaceChildren();
                    return;
                }

                if (file.size > maxSize) {
                    alert(file.name + ': The image must not exceed 5 MB.');
                    this.value = '';
                    imagePreview.replaceChildren();
                    return;
                }
            }

            files.forEach(function (file) {
                const reader = new FileReader();

                reader.onload = function (event) {
                    const image = document.createElement('img');
                    image.src = event.target.result;
                    image.alt = 'Evidence preview: ' + file.name;
                    image.style.width = '120px';
                    image.style.height = '100px';
                    image.style.objectFit = 'cover';
                    image.style.borderRadius = '8px';
                    image.style.border = '1px solid #dfe8e4';

                    imagePreview.appendChild(image);
                };

                reader.readAsDataURL(file);
            });
        });
    }
})();

</script>

</body>

</html>
