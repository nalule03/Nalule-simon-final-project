<?php
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

require_once __DIR__ . '/../app/config/database.php';
if (!isset($pdo) || !($pdo instanceof PDO)) {
    http_response_code(500);
    exit('TownLink database connection is unavailable.');
}

$dsn = "mysql:host=$host;dbname=$db;charset=utf8mb4";

function e($value): string
{
    return htmlspecialchars(
        (string)($value ?? ''),
        ENT_QUOTES,
        'UTF-8'
    );
}

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if (!$id || $id < 1) {
    http_response_code(404);
    exit('Announcement not found.');
}

$sql = "
    SELECT
        a.id,
        a.title,
        a.description,
        a.category,
        a.published_at,
        a.created_at,
        m.name AS municipality_name
    FROM announcements AS a
    INNER JOIN municipalities AS m
        ON m.id = a.municipality_id
    WHERE a.id = ?
      AND a.status = 'published'
      AND (a.expires_at IS NULL OR a.expires_at >= CURDATE())
    LIMIT 1
";

$stmt = $pdo->prepare($sql);
$stmt->execute();

if (!$stmt) {
    http_response_code(500);
    exit('Unable to load this announcement.');
}

$stmt = $pdo->prepare($sql);
$stmt->execute([$id]);

$announcement = $stmt->fetch(PDO::FETCH_ASSOC);

$stmt->closeCursor();

if (!$announcement) {
    http_response_code(404);
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Announcement Not Found | TownLink</title>
    </head>
    <body>
        <main>
            <h1>Announcement not found</h1>
            <p>This announcement may have been removed, expired,
               or is not currently published.</p>
            <a href="announcements.php">Browse announcements</a>
        </main>
    </body>
    </html>
    <?php
    exit;
}

$dateValue = $announcement['published_at']
    ?: $announcement['created_at'];

$timestamp = $dateValue ? strtotime($dateValue) : false;
$displayDate = $timestamp
    ? date('j F Y', $timestamp)
    : 'Date unavailable';

$description = trim((string)$announcement['description']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?= e($announcement['title']) ?> | TownLink</title>

    <meta
        name="description"
        content="<?= e(
            function_exists('mb_substr')
                ? mb_substr(strip_tags($description), 0, 155)
                : substr(strip_tags($description), 0, 155)
        ) ?>"
    >

    <style>
        * { box-sizing: border-box; }

        body {
            margin: 0;
            font-family: Arial, Helvetica, sans-serif;
            color: #172033;
            background: #f7f9fc;
            line-height: 1.7;
        }

        a { color: #155eef; }

        .header {
            background: #fff;
            border-bottom: 1px solid #e4e7ec;
        }

        .nav, .container {
            width: min(900px, 92%);
            margin: auto;
        }

        .nav {
            min-height: 68px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 16px;
        }

        .brand {
            color: #172033;
            font-size: 1.35rem;
            font-weight: 800;
            text-decoration: none;
        }

        .nav a:last-child {
            font-weight: 600;
            text-decoration: none;
        }

        .container { padding: 32px 0 54px; }

        .back {
            display: inline-block;
            margin-bottom: 22px;
            text-decoration: none;
            font-weight: 600;
        }

        .article {
            background: #fff;
            border: 1px solid #e4e7ec;
            border-radius: 16px;
            padding: clamp(22px, 5vw, 44px);
        }

        .category {
            display: inline-block;
            padding: 4px 11px;
            border-radius: 999px;
            background: #eff4ff;
            color: #1849a9;
            font-size: .83rem;
            font-weight: 700;
        }

        h1 {
            margin: 18px 0;
            font-size: clamp(1.8rem, 5vw, 2.7rem);
            line-height: 1.2;
            overflow-wrap: anywhere;
        }

        .publisher {
            display: flex;
            align-items: flex-start;
            gap: 12px;
            padding: 16px;
            margin: 24px 0;
            background: #f7f9fc;
            border: 1px solid #e4e7ec;
            border-radius: 10px;
        }

        .publisher-icon {
            font-size: 1.5rem;
            color: #155eef;
        }

        .publisher p { margin: 0; }

        .muted {
            color: #667085;
            font-size: .9rem;
        }

        .description {
            overflow-wrap: anywhere;
            white-space: pre-wrap;
        }

        footer {
            padding: 24px 0;
            border-top: 1px solid #e4e7ec;
            background: #fff;
            color: #667085;
            font-size: .9rem;
        }
    </style>
</head>
<body>

<header class="header">
    <nav class="nav" aria-label="Main navigation">
        <a class="brand" href="index.php">TownLink</a>
        <a href="announcements.php">All announcements</a>
    </nav>
</header>

<main class="container">
    <a class="back" href="announcements.php">
        ← Back to announcements
    </a>

    <article class="article">
        <span class="category">
            <?= e($announcement['category'] ?: 'Announcement') ?>
        </span>

        <h1><?= e($announcement['title']) ?></h1>

        <section class="publisher" aria-label="Publishing municipality">
            <span class="publisher-icon" aria-hidden="true">▣</span>
            <div>
                <p class="muted">OFFICIAL PUBLISHER</p>
                <p>
                    <strong>
                        <?= e($announcement['municipality_name']) ?>
                    </strong>
                </p>
                <p class="muted">
                    Published on <?= e($displayDate) ?>
                </p>
            </div>
        </section>

        <div class="description"><?= e($description) ?></div>
    </article>
</main>

<footer>
    <div class="container">
        TownLink — Municipal information and community updates.
    </div>
</footer>

</body>
</html>