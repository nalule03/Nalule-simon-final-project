<?php

declare(strict_types=1);

require_once __DIR__ . '/../auth.php';
require_once __DIR__ . '/../layout.php';

requireMunicipalityAdmin();

$error = '';

$name = '';
$code = '';
$description = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    verifyCsrf();

    $name = trim((string) ($_POST['name'] ?? ''));
    $code = strtoupper(trim((string) ($_POST['code'] ?? '')));
    $description = trim((string) ($_POST['description'] ?? ''));

    if ($name === '') {

        $error = 'Department name is required.';

    } elseif (mb_strlen($name) > 150) {

        $error = 'Department name cannot exceed 150 characters.';

    } elseif ($code === '') {

        $error = 'Department code is required.';

    } elseif (strlen($code) > 50) {

        $error = 'Department code cannot exceed 50 characters.';

    } elseif (!preg_match('/^[A-Z0-9_-]+$/', $code)) {

        $error = 'Use only letters, numbers, hyphens, and underscores in the department code.';

    } else {

        try {

            $stmt = $pdo->prepare("
                SELECT id
                FROM departments
                WHERE municipality_id = :municipality_id
                  AND code = :code
                LIMIT 1
            ");

            $stmt->execute([
                ':municipality_id' => $municipalityId,
                ':code' => $code
            ]);

            if ($stmt->fetch()) {

                $error = 'A department with this code already exists.';

            } else {

                $stmt = $pdo->prepare("
                    INSERT INTO departments (
                        municipality_id,
                        name,
                        code,
                        description,
                        status
                    )
                    VALUES (
                        :municipality_id,
                        :name,
                        :code,
                        :description,
                        'active'
                    )
                ");

                $stmt->execute([
                    ':municipality_id' => $municipalityId,
                    ':name' => $name,
                    ':code' => $code,
                    ':description' => $description !== ''
                        ? $description
                        : null
                ]);

                $departmentId = (int) $pdo->lastInsertId();

                auditLog(
                    $pdo,
                    $municipalityId,
                    $userId,
                    'create',
                    'department',
                    $departmentId,
                    'Created department: ' . $name
                );

                header('Location: view.php?id=' . $departmentId);
                exit;
            }

        } catch (PDOException $e) {

            error_log('Department create error: ' . $e->getMessage());

            $error = 'Unable to create the department. Please try again.';
        }
    }
}

municipalityHeader('Add Department', 'departments');

?>

<style>
/* =========================================================
   TownLink Department Creation Page
   ========================================================= */

:root {
    --dept-primary: #176b52;
    --dept-primary-dark: #124b3a;
    --dept-primary-light: #e8f5ef;
    --dept-bg: #f5f8f7;
    --dept-card: #ffffff;
    --dept-text: #172b24;
    --dept-muted: #718078;
    --dept-border: #e2eae5;
    --dept-danger: #b42318;
    --dept-radius: 16px;
    --dept-shadow: 0 5px 20px rgba(16, 48, 36, .055);
}

.dept-page {
    width: 100%;
    max-width: 1200px;
    margin: 0 auto;
    padding: 28px 0 44px;
    color: var(--dept-text);
}

.dept-page *,
.dept-page *::before,
.dept-page *::after {
    box-sizing: border-box;
}

.dept-heading {
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 18px;
    margin-bottom: 26px;
}

.dept-heading h2 {
    margin: 0 0 6px;
    font-size: clamp(24px, 3vw, 31px);
    font-weight: 800;
    letter-spacing: -.7px;
}

.dept-heading p {
    margin: 0;
    color: var(--dept-muted);
    font-size: 14px;
}

.dept-eyebrow {
    display: inline-block;
    margin-bottom: 8px;
    color: var(--dept-primary);
    font-size: 11px;
    font-weight: 800;
    letter-spacing: 1.5px;
    text-transform: uppercase;
}

.dept-button {
    display: inline-flex;
    justify-content: center;
    align-items: center;
    gap: 8px;
    min-height: 43px;
    padding: 10px 16px;
    border: 1px solid transparent;
    border-radius: 10px;
    background: var(--dept-primary);
    color: #fff !important;
    font: inherit;
    font-size: 13px;
    font-weight: 700;
    text-decoration: none !important;
    cursor: pointer;
    transition: background .18s, transform .18s;
}

.dept-button:hover {
    background: var(--dept-primary-dark);
    transform: translateY(-1px);
}

.dept-button-secondary {
    background: #fff;
    color: var(--dept-text) !important;
    border-color: var(--dept-border);
}

.dept-button-secondary:hover {
    background: #f2f7f4;
}

.dept-button-danger {
    background: #fff;
    color: var(--dept-danger) !important;
    border-color: #f2c9c6;
}

.dept-button-danger:hover {
    background: #fff1f0;
}

.dept-button-small {
    min-height: 34px;
    padding: 7px 11px;
    font-size: 12px;
    border-radius: 8px;
}

.dept-card {
    margin-bottom: 22px;
    padding: 24px;
    background: var(--dept-card);
    border: 1px solid var(--dept-border);
    border-radius: var(--dept-radius);
    box-shadow: var(--dept-shadow);
}

.dept-card-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    gap: 15px;
    flex-wrap: wrap;
    padding-bottom: 18px;
    margin-bottom: 20px;
    border-bottom: 1px solid var(--dept-border);
}

.dept-card-header h3 {
    margin: 0 0 5px;
    font-size: 17px;
}

.dept-card-header p {
    margin: 0;
    color: var(--dept-muted);
    font-size: 13px;
}

.dept-stats {
    display: grid;
    grid-template-columns: repeat(3, minmax(0, 1fr));
    gap: 16px;
    margin-bottom: 22px;
}

.dept-stat {
    padding: 20px;
    background: #fff;
    border: 1px solid var(--dept-border);
    border-radius: 14px;
}

.dept-stat-label {
    display: block;
    margin-bottom: 7px;
    color: var(--dept-muted);
    font-size: 12px;
    font-weight: 600;
}

.dept-stat-number {
    font-size: 27px;
    font-weight: 800;
    line-height: 1.2;
}

.dept-table-wrap {
    overflow-x: auto;
    border: 1px solid var(--dept-border);
    border-radius: 12px;
}

.dept-table {
    width: 100%;
    border-collapse: collapse;
    background: #fff;
}

.dept-table th {
    padding: 15px 17px;
    background: #f6f9f7;
    color: #5f7068;
    text-align: left;
    text-transform: uppercase;
    letter-spacing: .5px;
    font-size: 10px;
    font-weight: 800;
    white-space: nowrap;
}

.dept-table td {
    padding: 17px;
    border-top: 1px solid #edf1ee;
    vertical-align: middle;
    font-size: 13px;
}

.dept-table tbody tr {
    transition: background .15s;
}

.dept-table tbody tr:hover {
    background: #f9fcfa;
}

.dept-name {
    display: block;
    margin-bottom: 4px;
    color: var(--dept-text);
    font-size: 14px;
    font-weight: 800;
}

.dept-description {
    display: block;
    max-width: 310px;
    color: var(--dept-muted);
    font-size: 12px;
    line-height: 1.5;
    overflow-wrap: anywhere;
}

.dept-code {
    display: inline-block;
    padding: 5px 8px;
    border: 1px solid #e2eae5;
    border-radius: 6px;
    background: #f5f8f6;
    color: #46584f;
    font-family: Consolas, monospace;
    font-size: 11px;
    font-weight: 700;
    overflow-wrap: anywhere;
}

.dept-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 5px 10px;
    border-radius: 30px;
    font-size: 11px;
    font-weight: 800;
    white-space: nowrap;
}

.dept-badge::before {
    content: "";
    width: 6px;
    height: 6px;
    display: inline-block;
    border-radius: 50%;
    background: currentColor;
}

.dept-badge-active {
    background: #e6f7ed;
    color: #167044;
}

.dept-badge-inactive {
    background: #fff0e8;
    color: #a64b16;
}

.dept-actions {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    gap: 7px;
}

.dept-form-grid {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 22px;
}

.dept-field {
    min-width: 0;
}

.dept-field-full {
    grid-column: 1 / -1;
}

.dept-field label {
    display: block;
    margin-bottom: 8px;
    color: #263c32;
    font-size: 13px;
    font-weight: 700;
}

.dept-required {
    color: #b42318;
}

.dept-field input,
.dept-field textarea,
.dept-field select {
    display: block;
    width: 100%;
    min-height: 46px;
    padding: 11px 13px;
    border: 1px solid #d5e0d9;
    border-radius: 9px;
    background: #fff;
    color: var(--dept-text);
    font: inherit;
    font-size: 13px;
    transition: border-color .18s, box-shadow .18s;
}

.dept-field textarea {
    min-height: 125px;
    resize: vertical;
    line-height: 1.6;
}

.dept-field input:focus,
.dept-field textarea:focus,
.dept-field select:focus {
    outline: none;
    border-color: var(--dept-primary);
    box-shadow: 0 0 0 3px rgba(23, 107, 82, .12);
}

.dept-help {
    display: block;
    margin-top: 6px;
    color: var(--dept-muted);
    font-size: 11px;
    line-height: 1.5;
}

.dept-form-actions {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    gap: 10px;
    padding-top: 22px;
    margin-top: 24px;
    border-top: 1px solid var(--dept-border);
}

.dept-alert {
    padding: 14px 16px;
    margin-bottom: 20px;
    border: 1px solid;
    border-radius: 10px;
    font-size: 13px;
    line-height: 1.6;
}

.dept-alert-error {
    color: #9b2420;
    background: #fff2f0;
    border-color: #f5c6c2;
}

.dept-alert-success {
    color: #176b40;
    background: #eaf8ef;
    border-color: #b7e4c7;
}

.dept-detail-grid {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 20px;
}

.dept-detail {
    min-width: 0;
}

.dept-detail-label {
    display: block;
    margin-bottom: 6px;
    color: var(--dept-muted);
    font-size: 11px;
    font-weight: 800;
    letter-spacing: .6px;
    text-transform: uppercase;
}

.dept-detail-value {
    color: var(--dept-text);
    font-size: 14px;
    font-weight: 600;
    overflow-wrap: anywhere;
}

.dept-detail-full {
    grid-column: 1 / -1;
}

.dept-empty {
    padding: 35px 18px;
    text-align: center;
    color: var(--dept-muted);
}

.dept-empty strong {
    display: block;
    margin-bottom: 6px;
    color: var(--dept-text);
    font-size: 15px;
}

@media (max-width: 760px) {
    .dept-page {
        padding: 22px 0 32px;
    }

    .dept-card {
        padding: 17px;
    }

    .dept-stats {
        grid-template-columns: 1fr;
        gap: 10px;
    }

    .dept-stat {
        padding: 15px;
    }

    .dept-stat-number {
        font-size: 23px;
    }

    .dept-form-grid,
    .dept-detail-grid {
        grid-template-columns: 1fr;
        gap: 18px;
    }

    .dept-field-full,
    .dept-detail-full {
        grid-column: auto;
    }

    .dept-heading {
        align-items: flex-start;
    }

    .dept-heading .dept-button {
        width: 100%;
    }

    .dept-table th,
    .dept-table td {
        padding: 12px;
    }

    .dept-actions {
        min-width: 140px;
    }
}

@media (prefers-reduced-motion: reduce) {
    .department-btn,
    .department-input,
    .department-textarea {
        transition: none;
    }
}
</style>

<main class="department-page">

    <nav class="department-breadcrumb" aria-label="Breadcrumb">
        <a href="index.php">Departments</a>
        <span aria-hidden="true">/</span>
        <span aria-current="page">Add Department</span>
    </nav>

    <section class="department-hero">

        <div class="department-hero-content">

            <div class="department-eyebrow">
                <span aria-hidden="true">●</span>
                MUNICIPAL ADMINISTRATION
            </div>

            <h2>Create a Department</h2>

            <p>
                Organise municipal operations by creating a department.
                Add its name, assign a unique department code, and provide
                a description to help staff and residents understand its role.
            </p>

        </div>

        <div class="department-hero-icon" aria-hidden="true">
            ▤
        </div>

    </section>

    <?php if ($error !== ''): ?>

        <div class="department-alert" role="alert">

            <span class="department-alert-icon" aria-hidden="true">
                ⚠
            </span>

            <div>
                <strong>Department could not be created</strong><br>
                <?= e($error) ?>
            </div>

        </div>

    <?php endif; ?>

    <section class="department-form-card">

        <div class="department-card-heading">

            <div class="department-card-heading-icon" aria-hidden="true">
                ✎
            </div>

            <div>
                <h3>Department Information</h3>

                <p>
                    Complete the details below. Fields marked
                    <span class="department-required">*</span>
                    are required.
                </p>
            </div>

        </div>

        <form method="POST" action="" autocomplete="off">

            <input
                type="hidden"
                name="csrf_token"
                value="<?= e(csrfToken()) ?>"
            >

            <div class="department-form-body">

                <div class="department-form-grid">

                    <div class="department-field">

                        <label for="name">
                            Department Name
                            <span class="department-required">*</span>
                        </label>

                        <input
                            class="department-input"
                            type="text"
                            id="name"
                            name="name"
                            maxlength="150"
                            required
                            autofocus
                            placeholder="e.g. Water and Sanitation"
                            value="<?= e($name) ?>"
                        >

                        <small class="department-help">
                            Enter the official name of the municipal department.
                        </small>

                    </div>

                    <div class="department-field">

                        <label for="code">
                            Department Code
                            <span class="department-required">*</span>
                        </label>

                        <input
                            class="department-input"
                            type="text"
                            id="code"
                            name="code"
                            maxlength="50"
                            pattern="[A-Za-z0-9_-]+"
                            title="Use only letters, numbers, hyphens, and underscores."
                            required
                            placeholder="e.g. WATER"
                            value="<?= e($code) ?>"
                            autocapitalize="characters"
                        >

                        <small class="department-help">
                            Use a unique identifier, such as WATER, ROADS,
                            or TL-BUSINESS-4. Codes must be unique within your municipality.
                        </small>

                    </div>

                    <div class="department-field full-width">

                        <label for="description">
                            Department Description
                            <span style="color:#849188;font-weight:400;">
                                (Optional)
                            </span>
                        </label>

                        <textarea
                            class="department-textarea"
                            id="description"
                            name="description"
                            placeholder="Describe the department's responsibilities, services, and main functions..."
                        ><?= e($description) ?></textarea>

                        <div class="department-char-count">
                            <span>
                                Keep the description clear and informative.
                            </span>

                            <span id="description-count">
                                <?= function_exists('mb_strlen')
                                    ? mb_strlen($description)
                                    : strlen($description) ?> characters
                            </span>
                        </div>

                    </div>

                </div>

            </div>

            <div class="department-form-footer">

                <div class="department-footer-note">
                    <span aria-hidden="true">🔒</span>
                    Only authorised municipal administrators can create departments.
                </div>

                <div class="department-form-actions">

                    <a
                        class="department-btn department-btn-secondary"
                        href="index.php"
                    >
                        Cancel
                    </a>

                    <button
                        class="department-btn department-btn-primary"
                        type="submit"
                    >
                        <span aria-hidden="true">＋</span>
                        Create Department
                    </button>

                </div>

            </div>

        </form>

    </section>

    <aside class="department-tip">

        <span class="department-tip-icon" aria-hidden="true">💡</span>

        <div>
            <h4>Helpful tip</h4>

            <p>
                Choose a short, recognisable department code that your
                municipality can use consistently. For example,
                ROADS for Roads and Infrastructure or WATER for
                Water and Sanitation. The department will be created
                with an active status.
            </p>
        </div>

    </aside>

</main>

<script>
(function () {
    const description = document.getElementById('description');
    const counter = document.getElementById('description-count');

    if (!description || !counter) {
        return;
    }

    function updateDescriptionCount() {
        counter.textContent =
            description.value.length + ' characters';
    }

    description.addEventListener('input', updateDescriptionCount);
    updateDescriptionCount();
})();
</script>

<?php

municipalityFooter();