<?php

declare(strict_types=1);

require_once __DIR__ . '/../_auth.php';

if (!isMunicipalityAdmin()) {
    http_response_code(403);
    exit('Access denied.');
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.php');
    exit;
}

$id = filter_input(
    INPUT_POST,
    'id',
    FILTER_VALIDATE_INT
);

if (!$id) {
    http_response_code(400);
    exit('Invalid report ID.');
}

$title = trim($_POST['title'] ?? '');
$description = trim($_POST['description'] ?? '');
$status = trim($_POST['status'] ?? 'draft');
$priority = trim($_POST['priority'] ?? 'medium');

$validStatuses = [
    'draft',
    'submitted',
    'in_progress',
    'resolved',
    'rejected',
    'archived'
];

$validPriorities = [
    'low',
    'medium',
    'high',
    'urgent'
];

if ($title === '') {
    exit('Title is required.');
}

if ($description === '') {
    exit('Description is required.');
}

if (!in_array($status, $validStatuses, true)) {
    exit('Invalid status.');
}

if (!in_array($priority, $validPriorities, true)) {
    exit('Invalid priority.');
}

$checkSql = "
    SELECT
        id,
        resolved_at

    FROM reports

    WHERE
        id = :id
        AND municipality_id = :municipality_id

    LIMIT 1
";

$checkStmt = $pdo->prepare($checkSql);

$checkStmt->execute([
    ':id' => $id,
    ':municipality_id' => $municipalityId
]);

$existing = $checkStmt->fetch(PDO::FETCH_ASSOC);

if (!$existing) {
    http_response_code(404);
    exit('Report not found.');
}

$resolvedAt = $existing['resolved_at'];

if ($status === 'resolved') {

    if (empty($resolvedAt)) {
        $resolvedAt = date('Y-m-d H:i:s');
    }

} else {

    $resolvedAt = null;

}

$sql = "
    UPDATE reports

    SET
        title = :title,
        description = :description,
        status = :status,
        priority = :priority,
        resolved_at = :resolved_at,
        updated_at = NOW()

    WHERE
        id = :id
        AND municipality_id = :municipality_id
";

$stmt = $pdo->prepare($sql);

$stmt->execute([
    ':title' => $title,
    ':description' => $description,
    ':status' => $status,
    ':priority' => $priority,
    ':resolved_at' => $resolvedAt,
    ':id' => $id,
    ':municipality_id' => $municipalityId
]);

header(
    'Location: view.php?id=' . $id
);

exit;