<?php

declare(strict_types=1);

function systemAdminHeader(
    string $title = 'System Administration'
): void {
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link
    rel="stylesheet"
    href="/TownLink/assets/vendor/bootstrap/css/bootstrap.min.css"
>

<link
    rel="stylesheet"
    href="/TownLink/assets/vendor/bootstrap-icons/bootstrap-icons.css"
>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title><?= e($title) ?> - TownLink</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, Helvetica, sans-serif;
            background: #f4f6f9;
            color: #1f2937;
        }

        .topbar {
            background: #111827;
            color: white;
            padding: 16px 24px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 15px;
        }

        .brand {
            font-size: 20px;
            font-weight: bold;
        }

        .admin-name {
            font-size: 14px;
            color: #d1d5db;
            text-align: right;
        }

        .layout {
            display: flex;
            min-height: calc(100vh - 60px);
        }

        .sidebar {
            flex: 0 0 240px;
            width: 240px;
            background: #1f2937;
            color: white;
            padding: 20px 0;
        }

        .sidebar a {
            display: block;
            padding: 12px 20px;
            color: #d1d5db;
            text-decoration: none;
            transition: background 0.2s ease;
        }

        .sidebar a:hover,
        .sidebar a:focus {
            background: #374151;
            color: white;
        }

        .sidebar .section {
            padding: 16px 20px 8px;
            font-size: 11px;
            text-transform: uppercase;
            color: #9ca3af;
            font-weight: bold;
        }

        .content {
            flex: 1;
            min-width: 0;
            padding: 30px;
            max-width: 1400px;
        }

        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 15px;
            flex-wrap: wrap;
            margin-bottom: 25px;
        }

        .page-header h1,
        .page-header h2 {
            margin: 0 0 5px;
        }

        .muted {
            color: #6b7280;
        }

        .cards {
            display: grid;
            grid-template-columns:
                repeat(auto-fit, minmax(210px, 1fr));
            gap: 20px;
            margin-bottom: 25px;
        }

        .card {
            background: white;
            border-radius: 8px;
            padding: 22px;
            box-shadow: 0 1px 3px rgba(0, 0, 0, .08);
            margin-bottom: 20px;
        }

        .stat-number {
            font-size: 32px;
            font-weight: bold;
            margin: 8px 0;
        }

        .stat-label {
            color: #6b7280;
            font-size: 14px;
        }

        .table-responsive {
            width: 100%;
            overflow-x: auto;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
        }

        th,
        td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #e5e7eb;
        }

        th {
            background: #f9fafb;
            font-size: 13px;
        }

        .button {
            display: inline-block;
            border: 0;
            border-radius: 6px;
            background: #2563eb;
            color: white;
            padding: 9px 14px;
            text-decoration: none;
            cursor: pointer;
            font-size: 14px;
        }

        .button:hover {
            background: #1d4ed8;
            color: white;
        }

        .button.secondary {
            background: #6b7280;
        }

        .button.danger {
            background: #dc2626;
        }

        .button.success {
            background: #16a34a;
        }

        input,
        select,
        textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #d1d5db;
            border-radius: 6px;
            font: inherit;
        }

        textarea {
            min-height: 120px;
            resize: vertical;
        }

        label {
            display: block;
            margin-bottom: 6px;
            font-weight: 600;
        }

        .form-group {
            margin-bottom: 18px;
        }

        .form-grid {
            display: grid;
            grid-template-columns:
                repeat(2, minmax(0, 1fr));
            gap: 20px;
        }

        .badge {
            display: inline-block;
            padding: 4px 9px;
            border-radius: 999px;
            font-size: 12px;
            font-weight: bold;
        }

        .badge.active {
            background: #dcfce7;
            color: #166534;
        }

        .badge.inactive {
            background: #fee2e2;
            color: #991b1b;
        }

        .badge.system_admin {
            background: #dbeafe;
            color: #1e40af;
        }

        .badge.municipality_admin {
            background: #ede9fe;
            color: #5b21b6;
        }

        .badge.department_staff {
            background: #fef3c7;
            color: #92400e;
        }

        .badge.resident {
            background: #e0f2fe;
            color: #075985;
        }

        .actions {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
        }

        @media (max-width: 800px) {
            .layout {
                flex-direction: column;
            }

            .sidebar {
                flex: 0 0 auto;
                width: 100%;
                padding: 10px 0;
            }

            .sidebar a {
                padding: 10px 20px;
            }

            .content {
                padding: 20px;
                max-width: 100%;
            }

            .form-grid {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 480px) {
            .topbar {
                padding: 14px 16px;
                align-items: flex-start;
                flex-direction: column;
            }

            .brand {
                font-size: 18px;
            }

            .admin-name {
                text-align: left;
            }

            .content {
                padding: 15px;
            }

            .cards {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>

<body>

<header class="topbar">
    <div class="brand">
        TownLink System Administration
    </div>

    <div class="admin-name">
        <?= e(
            trim(
                ($currentUser['first_name'] ?? '') . ' ' .
                ($currentUser['last_name'] ?? '')
            )
        ) ?>
    </div>
</header>

<div class="layout">

    <aside class="sidebar">
        <div class="section">Main</div>

        <a href="/TownLink/SystemAdmin/index.php">
            Dashboard
        </a>

        <div class="section">Management</div>

        <a href="/TownLink/SystemAdmin/audit-logs.php">
            Security &amp; Audit Logs
        </a>

        <a href="/TownLink/SystemAdmin/municipalities/index.php">
            Municipalities
        </a>

        <a href="/TownLink/SystemAdmin/users/index.php">
            Users
        </a>

        <a href="/TownLink/SystemAdmin/users/municipality_admin/create.php">
            Create Municipality Admin
        </a>

        <div class="section">Account</div>

        <a href="/TownLink/SystemAdmin/profile/index.php">
            My Profile
        </a>

        <a href="/TownLink/SystemAdmin/profile/change-password.php">
            Change Password
        </a>

        <a href="/TownLink/public/logout.php">
            Logout
        </a>
    </aside>

    <main class="content">
<?php
}

function systemAdminFooter(): void
{
?>
    </main>
</div>
<script src="/TownLink/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php
}