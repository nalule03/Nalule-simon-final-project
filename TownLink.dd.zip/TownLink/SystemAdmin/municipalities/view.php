<?php

declare(strict_types=1);

require_once __DIR__ . '/../includes/_auth.php';

$id = filter_input(
    INPUT_GET,
    'id',
    FILTER_VALIDATE_INT
);

if (!$id || $id <= 0) {

    http_response_code(400);

    exit(
        'Invalid municipality ID.'
    );
}

try {

    $stmt = $pdo->prepare("
        SELECT
            id,
            name,
            code,
            type,
            region,
            description,
            address,
            phone,
            email,
            website,
            logo,
            status,
            created_at,
            updated_at
        FROM municipalities
        WHERE id = :id
        LIMIT 1
    ");

    $stmt->execute([
        ':id' => $id
    ]);

    $municipality =
        $stmt->fetch(
            PDO::FETCH_ASSOC
        );

    if (!$municipality) {

        http_response_code(404);

        exit(
            'Municipality not found.'
        );
    }

    /*
    |--------------------------------------------------------------------------
    | Municipality Admins
    |--------------------------------------------------------------------------
    */

    $stmt = $pdo->prepare("
        SELECT
            id,
            first_name,
            last_name,
            email,
            phone,
            status,
            must_change_password,
            last_login_at,
            created_at
        FROM users
        WHERE
            municipality_id = :municipality_id
            AND role = 'municipality_admin'
        ORDER BY first_name, last_name
    ");

    $stmt->execute([
        ':municipality_id' => $id
    ]);

    $admins =
        $stmt->fetchAll(
            PDO::FETCH_ASSOC
        );

} catch (PDOException $e) {

    error_log(
        'View municipality error: ' .
        $e->getMessage()
    );

    http_response_code(500);

    exit(
        'Unable to load municipality.'
    );
}

?>

<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        <?= e($municipality['name']) ?>
        | TownLink
    </title>

</head>

<body>

<header>

    <h1>
        <?= e($municipality['name']) ?>
    </h1>

</header>

<nav>

    <a href="index.php">
        Municipalities
    </a>

    |

    <a href="edit.php?id=<?= $id ?>">
        Edit
    </a>

    |

    <a href="create-admin.php?municipality_id=<?= $id ?>">
        Create Municipality Admin
    </a>

</nav>

<hr>

<main>

    <h2>
        Municipality Information
    </h2>

    <dl>

        <dt>
            Name
        </dt>

        <dd>
            <?= e($municipality['name']) ?>
        </dd>


        <dt>
            Code
        </dt>

        <dd>
            <?= e($municipality['code']) ?>
        </dd>


        <dt>
            Type
        </dt>

        <dd>
            <?= e(
                ucfirst(
                    $municipality['type']
                )
            ) ?>
        </dd>


        <dt>
            Region
        </dt>

        <dd>
            <?= e(
                $municipality['region']
            ) ?>
        </dd>


        <dt>
            Address
        </dt>

        <dd>
            <?= nl2br(
                e(
                    $municipality['address']
                )
            ) ?>
        </dd>


        <dt>
            Phone
        </dt>

        <dd>
            <?= e(
                $municipality['phone']
            ) ?>
        </dd>


        <dt>
            Email
        </dt>

        <dd>
            <?= e(
                $municipality['email']
            ) ?>
        </dd>


        <dt>
            Website
        </dt>

        <dd>

            <?php if (
                $municipality['website']
            ): ?>

                <a
                    href="<?= e($municipality['website']) ?>"
                    target="_blank"
                    rel="noopener"
                >
                    <?= e(
                        $municipality['website']
                    ) ?>
                </a>

            <?php endif; ?>

        </dd>


        <dt>
            Status
        </dt>

        <dd>
            <?= e(
                ucfirst(
                    $municipality['status']
                )
            ) ?>
        </dd>


        <dt>
            Created
        </dt>

        <dd>
            <?= e(
                $municipality['created_at']
            ) ?>
        </dd>


        <dt>
            Updated
        </dt>

        <dd>
            <?= e(
                $municipality['updated_at']
            ) ?>
        </dd>

    </dl>

    <h3>
        Description
    </h3>

    <p>
        <?= nl2br(
            e(
                $municipality['description']
            )
        ) ?>
    </p>

    <hr>

    <h2>
        Municipality Administrators
    </h2>

    <?php if (!$admins): ?>

        <p>
            No municipality administrators have been created.
        </p>

    <?php else: ?>

        <table
            border="1"
            cellpadding="8"
        >

            <thead>

                <tr>

                    <th>
                        Name
                    </th>

                    <th>
                        Email
                    </th>

                    <th>
                        Phone
                    </th>

                    <th>
                        Status
                    </th>

                    <th>
                        Password Status
                    </th>

                    <th>
                        Last Login
                    </th>

                </tr>

            </thead>

            <tbody>

            <?php foreach (
                $admins
                as $admin
            ): ?>

                <tr>

                    <td>

                        <?= e(
                            $admin['first_name'] .
                            ' ' .
                            $admin['last_name']
                        ) ?>

                    </td>

                    <td>

                        <?= e(
                            $admin['email']
                        ) ?>

                    </td>

                    <td>

                        <?= e(
                            $admin['phone']
                        ) ?>

                    </td>

                    <td>

                        <?= e(
                            ucfirst(
                                $admin['status']
                            )
                        ) ?>

                    </td>

                    <td>

                        <?php if (
                            (int)
                            $admin['must_change_password']
                            === 1
                        ): ?>

                            Temporary password

                        <?php else: ?>

                            Password changed

                        <?php endif; ?>

                    </td>

                    <td>

                        <?= e(
                            $admin['last_login_at']
                            ?? 'Never'
                        ) ?>

                    </td>

                </tr>

            <?php endforeach; ?>

            </tbody>

        </table>

    <?php endif; ?>

</main>

</body>

</html>